# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_comments (0 records)
#

#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2687 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_options (248 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://9zero7films.dev', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', '9ZERO7 Films', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', 'Young Documentary Filmmakers Workshop', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'jlcolema@me.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '9', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'closed', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'closed', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'posts_per_page', '9', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'comment_moderation', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'moderation_notify', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'permalink_structure', '/%year%/%monthnum%/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (35, 'active_plugins', 'a:8:{i:0;s:33:"admin-menu-editor/menu-editor.php";i:1;s:34:"advanced-custom-fields-pro/acf.php";i:2;s:35:"backupwordpress/backupwordpress.php";i:3;s:36:"contact-form-7/wp-contact-form-7.php";i:4;s:37:"custom-content-type-manager/index.php";i:5;s:45:"enable-media-replace/enable-media-replace.php";i:7;s:37:"post-types-order/post-types-order.php";i:8;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'home', 'http://9zero7films.dev', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (41, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'recently_edited', '', 'no') ; 
INSERT INTO `wp_options` VALUES (44, 'template', '9zero7films', 'yes') ; 
INSERT INTO `wp_options` VALUES (45, 'stylesheet', '9zero7films', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (48, 'comment_registration', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'db_version', '33055', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'uploads_use_yearmonth_folders', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'blog_public', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'show_avatars', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'image_default_link_type', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'close_comments_for_old_posts', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'page_comments', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (83, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `wp_options` VALUES (86, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'page_for_posts', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'page_on_front', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'initial_db_version', '26691', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-primary";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, 'cron', 'a:7:{i:1442354400;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"f9d69dbb1e64004f37b7dbb0a8de7dbc";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:10:"1441997204";}s:8:"interval";i:86400;}}}i:1442385567;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1442385600;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1442386860;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1442397584;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1442786400;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (102, '_transient_random_seed', '6671fb26b00c17f4ffbb636631986437', 'yes') ; 
INSERT INTO `wp_options` VALUES (103, 'auth_key', '.7:7kX$$llEri<_]J+`?uRwvE^0,]^| I#?p(%{^v7VhJ;ej&3*]rpbeFj2Q#z<Z', 'yes') ; 
INSERT INTO `wp_options` VALUES (104, 'auth_salt', ':V7$S<aWN?&wCo%ls4kSQ4s,>*kngmE_7NYZ`eaYq`~A<f<hX`xI[:Vdu?H^,%/I', 'yes') ; 
INSERT INTO `wp_options` VALUES (105, 'logged_in_key', '0NX$Z7Q[FEl!(xc,eh.M~o#I7cgWLb>`b=ot+5) 7d*]DS;s%)85,G0((5?.U%B?', 'yes') ; 
INSERT INTO `wp_options` VALUES (106, 'logged_in_salt', '1VkKc-D&#Ua%~y;>Mq_UU+xI@A[.%OmFA;F{DMp<:gD$<1]MoGPZ3#nZ6av&gx@-', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, 'nonce_key', '_>,QV/B(xNu(~RRo5Ar2piH{c}jA|L#8vti{F.RAj#~TqPF385~Rq&4r5sVGNKJQ', 'yes') ; 
INSERT INTO `wp_options` VALUES (108, 'nonce_salt', '&#f,se1m<wdd];r|PM5Un8A>/|?k!Ah?J 1*+oH I_f)V]p~J:I4#I17w3^=^,Lr', 'yes') ; 
INSERT INTO `wp_options` VALUES (135, '_transient_twentyfourteen_category_count', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (139, 'current_theme', 'Project Name', 'yes') ; 
INSERT INTO `wp_options` VALUES (140, 'theme_mods_project', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1441591006;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (141, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (144, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1389949999;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (145, 'optionsframework', 'a:2:{s:2:"id";s:24:"optionsframework_project";s:12:"knownoptions";a:1:{i:0;s:24:"optionsframework_project";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (146, 'optionsframework_project', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (147, 'recently_activated', 'a:3:{s:37:"mailchimp-for-wp/mailchimp-for-wp.php";i:1442023975;s:21:"placeIMG/placeIMG.php";i:1441942844;s:29:"gravityforms/gravityforms.php";i:1441601541;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (152, 'cctm_data', 'a:10:{s:5:"flash";a:0:{}s:5:"locks";a:0:{}s:14:"post_type_defs";a:4:{s:11:"testimonial";a:39:{s:24:"cctm_hierarchical_custom";s:0:"";s:33:"cctm_hierarchical_includes_drafts";s:0:"";s:28:"cctm_hierarchical_post_types";a:0:{}s:27:"cctm_custom_columns_enabled";i:0;s:21:"cctm_enable_right_now";i:0;s:8:"supports";a:1:{i:0;s:5:"title";}s:10:"taxonomies";a:0:{}s:23:"original_post_type_name";s:0:"";s:9:"post_type";s:11:"testimonial";s:6:"labels";a:11:{s:9:"menu_name";s:12:"Testimonials";s:13:"singular_name";s:11:"Testimonial";s:7:"add_new";s:7:"Add New";s:12:"add_new_item";s:19:"Add New Testimonial";s:9:"edit_item";s:16:"Edit Testimonial";s:8:"new_item";s:15:"New Testimonial";s:9:"view_item";s:16:"View Testimonial";s:12:"search_items";s:19:"Search Testimonials";s:9:"not_found";s:21:"No Testimonials Found";s:18:"not_found_in_trash";s:30:"No Testimonials Found in Trash";s:17:"parent_item_colon";s:11:"Parent Page";}s:11:"description";s:0:"";s:21:"use_default_menu_icon";b:1;s:5:"label";s:12:"Testimonials";s:17:"cctm_show_in_menu";s:1:"1";s:24:"cctm_show_in_menu_custom";s:0:"";s:17:"show_in_admin_bar";b:1;s:13:"menu_position";N;s:18:"rewrite_with_front";b:1;s:16:"permalink_action";s:6:"Custom";s:12:"rewrite_slug";s:12:"testimonials";s:9:"query_var";b:0;s:6:"public";b:1;s:7:"show_ui";b:1;s:18:"publicly_queryable";b:1;s:17:"include_in_search";b:1;s:14:"include_in_rss";b:1;s:15:"capability_type";s:4:"post";s:12:"capabilities";s:0:"";s:20:"register_meta_box_cb";s:0:"";s:10:"can_export";b:1;s:14:"custom_orderby";s:0:"";s:12:"custom_order";s:3:"ASC";s:17:"show_in_nav_menus";b:0;s:12:"hierarchical";b:0;s:12:"map_meta_cap";b:0;s:11:"has_archive";b:0;s:12:"show_in_menu";s:0:"";s:7:"rewrite";a:2:{s:4:"slug";s:12:"testimonials";s:10:"with_front";b:1;}s:9:"is_active";i:1;}s:5:"class";a:39:{s:24:"cctm_hierarchical_custom";s:0:"";s:33:"cctm_hierarchical_includes_drafts";s:0:"";s:28:"cctm_hierarchical_post_types";a:0:{}s:27:"cctm_custom_columns_enabled";i:0;s:21:"cctm_enable_right_now";i:0;s:8:"supports";a:1:{i:0;s:5:"title";}s:10:"taxonomies";a:0:{}s:23:"original_post_type_name";s:0:"";s:9:"post_type";s:5:"class";s:6:"labels";a:11:{s:9:"menu_name";s:7:"Classes";s:13:"singular_name";s:5:"Class";s:7:"add_new";s:7:"Add New";s:12:"add_new_item";s:13:"Add New Class";s:9:"edit_item";s:10:"Edit Class";s:8:"new_item";s:9:"New Class";s:9:"view_item";s:10:"View Class";s:12:"search_items";s:14:"Search Classes";s:9:"not_found";s:16:"No Classes Found";s:18:"not_found_in_trash";s:25:"No Classes Found in Trash";s:17:"parent_item_colon";s:11:"Parent Page";}s:11:"description";s:0:"";s:21:"use_default_menu_icon";b:1;s:5:"label";s:7:"Classes";s:17:"cctm_show_in_menu";s:1:"1";s:24:"cctm_show_in_menu_custom";s:0:"";s:17:"show_in_admin_bar";b:1;s:13:"menu_position";N;s:18:"rewrite_with_front";b:1;s:16:"permalink_action";s:6:"Custom";s:12:"rewrite_slug";s:7:"classes";s:9:"query_var";b:0;s:6:"public";b:1;s:7:"show_ui";b:1;s:18:"publicly_queryable";b:1;s:17:"include_in_search";b:1;s:14:"include_in_rss";b:1;s:15:"capability_type";s:4:"post";s:12:"capabilities";s:0:"";s:20:"register_meta_box_cb";s:0:"";s:10:"can_export";b:1;s:14:"custom_orderby";s:0:"";s:12:"custom_order";s:3:"ASC";s:17:"show_in_nav_menus";b:0;s:12:"hierarchical";b:0;s:12:"map_meta_cap";b:0;s:11:"has_archive";b:0;s:12:"show_in_menu";s:0:"";s:7:"rewrite";a:2:{s:4:"slug";s:7:"classes";s:10:"with_front";b:1;}s:9:"is_active";i:1;}s:3:"faq";a:39:{s:24:"cctm_hierarchical_custom";s:0:"";s:33:"cctm_hierarchical_includes_drafts";s:0:"";s:28:"cctm_hierarchical_post_types";a:0:{}s:27:"cctm_custom_columns_enabled";i:0;s:21:"cctm_enable_right_now";i:0;s:8:"supports";a:1:{i:0;s:5:"title";}s:10:"taxonomies";a:0:{}s:23:"original_post_type_name";s:0:"";s:9:"post_type";s:3:"faq";s:6:"labels";a:11:{s:9:"menu_name";s:4:"FAQs";s:13:"singular_name";s:3:"FAQ";s:7:"add_new";s:7:"Add New";s:12:"add_new_item";s:11:"Add New FAQ";s:9:"edit_item";s:8:"Edit FAQ";s:8:"new_item";s:7:"New FAQ";s:9:"view_item";s:8:"View FAQ";s:12:"search_items";s:11:"Search FAQs";s:9:"not_found";s:13:"No FAQs Found";s:18:"not_found_in_trash";s:22:"No FAQs Found in Trash";s:17:"parent_item_colon";s:11:"Parent Page";}s:11:"description";s:0:"";s:21:"use_default_menu_icon";b:1;s:5:"label";s:4:"FAQs";s:17:"cctm_show_in_menu";s:1:"1";s:24:"cctm_show_in_menu_custom";s:0:"";s:17:"show_in_admin_bar";b:1;s:13:"menu_position";N;s:18:"rewrite_with_front";b:1;s:16:"permalink_action";s:6:"Custom";s:12:"rewrite_slug";s:4:"faqs";s:9:"query_var";b:0;s:6:"public";b:1;s:7:"show_ui";b:1;s:18:"publicly_queryable";b:1;s:17:"include_in_search";b:1;s:14:"include_in_rss";b:1;s:15:"capability_type";s:4:"post";s:12:"capabilities";s:0:"";s:20:"register_meta_box_cb";s:0:"";s:10:"can_export";b:1;s:14:"custom_orderby";s:0:"";s:12:"custom_order";s:3:"ASC";s:17:"show_in_nav_menus";b:0;s:12:"hierarchical";b:0;s:12:"map_meta_cap";b:0;s:11:"has_archive";b:0;s:12:"show_in_menu";s:0:"";s:7:"rewrite";a:2:{s:4:"slug";s:4:"faqs";s:10:"with_front";b:1;}s:9:"is_active";i:1;}s:7:"sponsor";a:39:{s:24:"cctm_hierarchical_custom";s:0:"";s:33:"cctm_hierarchical_includes_drafts";s:0:"";s:28:"cctm_hierarchical_post_types";a:0:{}s:27:"cctm_custom_columns_enabled";i:0;s:21:"cctm_enable_right_now";i:0;s:8:"supports";a:1:{i:0;s:5:"title";}s:10:"taxonomies";a:0:{}s:23:"original_post_type_name";s:0:"";s:9:"post_type";s:7:"sponsor";s:6:"labels";a:11:{s:9:"menu_name";s:8:"Sponsors";s:13:"singular_name";s:7:"Sponsor";s:7:"add_new";s:7:"Add New";s:12:"add_new_item";s:15:"Add New Sponsor";s:9:"edit_item";s:12:"Edit Sponsor";s:8:"new_item";s:11:"New Sponsor";s:9:"view_item";s:12:"View Sponsor";s:12:"search_items";s:15:"Search Sponsors";s:9:"not_found";s:17:"No Sponsors Found";s:18:"not_found_in_trash";s:26:"No Sponsors Found in Trash";s:17:"parent_item_colon";s:11:"Parent Page";}s:11:"description";s:0:"";s:21:"use_default_menu_icon";b:1;s:5:"label";s:8:"Sponsors";s:17:"cctm_show_in_menu";s:1:"1";s:24:"cctm_show_in_menu_custom";s:0:"";s:17:"show_in_admin_bar";b:1;s:13:"menu_position";N;s:18:"rewrite_with_front";b:1;s:16:"permalink_action";s:6:"Custom";s:12:"rewrite_slug";s:8:"sponsors";s:9:"query_var";b:0;s:6:"public";b:1;s:7:"show_ui";b:1;s:18:"publicly_queryable";b:1;s:17:"include_in_search";b:1;s:14:"include_in_rss";b:1;s:15:"capability_type";s:4:"post";s:12:"capabilities";s:0:"";s:20:"register_meta_box_cb";s:0:"";s:10:"can_export";b:1;s:14:"custom_orderby";s:0:"";s:12:"custom_order";s:3:"ASC";s:17:"show_in_nav_menus";b:0;s:12:"hierarchical";b:0;s:12:"map_meta_cap";b:0;s:11:"has_archive";b:0;s:12:"show_in_menu";s:0:"";s:7:"rewrite";a:2:{s:4:"slug";s:8:"sponsors";s:10:"with_front";b:1;}s:9:"is_active";i:1;}}s:17:"custom_field_defs";a:0:{}s:27:"cctm_installation_timestamp";i:1389951478;s:11:"export_info";a:5:{s:5:"title";s:9:"CCTM Site";s:6:"author";s:21:"joshua@bloomdesign.co";s:3:"url";s:20:"http://wordpress.dev";s:12:"template_url";s:0:"";s:11:"description";s:67:"This site was created in part using the Custom Content Type Manager";}s:21:"cctm_update_timestamp";i:1389951478;s:12:"cctm_version";s:10:"0.9.8.6-pl";s:8:"settings";a:17:{s:12:"delete_posts";i:0;s:20:"delete_custom_fields";i:0;s:17:"add_custom_fields";i:0;s:23:"show_custom_fields_menu";i:0;s:18:"show_settings_menu";i:0;s:23:"show_foreign_post_types";i:0;s:22:"cache_thumbnail_images";i:0;s:17:"save_empty_fields";i:1;s:22:"summarizeposts_tinymce";i:0;s:21:"custom_fields_tinymce";i:0;s:21:"flush_permalink_rules";i:1;s:17:"pages_in_rss_feed";i:0;s:16:"enable_right_now";i:0;s:10:"hide_posts";i:0;s:10:"hide_pages";i:0;s:10:"hide_links";i:0;s:13:"hide_comments";i:0;}s:5:"cache";a:1:{s:14:"helper_classes";a:1:{s:6:"fields";a:15:{s:8:"checkbox";s:107:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/checkbox.php";s:13:"colorselector";s:112:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/colorselector.php";s:4:"date";s:103:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/date.php";s:9:"directory";s:108:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/directory.php";s:8:"dropdown";s:107:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/dropdown.php";s:6:"hidden";s:105:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/hidden.php";s:5:"image";s:104:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/image.php";s:5:"media";s:104:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/media.php";s:11:"multiselect";s:110:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/multiselect.php";s:8:"relation";s:107:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/relation.php";s:12:"relationmeta";s:111:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/relationmeta.php";s:4:"text";s:103:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/text.php";s:8:"textarea";s:107:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/textarea.php";s:4:"user";s:103:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/user.php";s:7:"wysiwyg";s:106:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/plugins/custom-content-type-manager/fields/wysiwyg.php";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (160, 'acf_version', '5.3.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (211, 'rg_form_version', '1.8.22', 'yes') ; 
INSERT INTO `wp_options` VALUES (235, 'cpto_options', 'a:5:{s:23:"show_reorder_interfaces";a:6:{s:4:"post";s:4:"hide";s:10:"attachment";s:4:"hide";s:11:"testimonial";s:4:"hide";s:5:"class";s:4:"hide";s:3:"faq";s:4:"show";s:7:"sponsor";s:4:"hide";}s:8:"autosort";s:0:"";s:9:"adminsort";i:1;s:10:"capability";s:13:"switch_themes";s:21:"navigation_sort_apply";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (239, 'CPT_configured', 'TRUE', 'yes') ; 
INSERT INTO `wp_options` VALUES (277, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (375, 'rg_gforms_disable_css', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (376, 'rg_gforms_enable_html5', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (377, 'gform_enable_noconflict', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (378, 'rg_gforms_enable_akismet', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (379, 'rg_gforms_captcha_public_key', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (380, 'rg_gforms_captcha_private_key', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (381, 'rg_gforms_currency', 'USD', 'yes') ; 
INSERT INTO `wp_options` VALUES (382, 'rg_gforms_message', '<!--GFM-->', 'yes') ; 
INSERT INTO `wp_options` VALUES (692, 'gf_dismissed_upgrades', 'a:6:{i:0;s:5:"1.7.9";i:1;s:6:"1.8.18";i:2;s:7:"1.9.1.2";i:3;s:5:"1.9.9";i:4;s:8:"1.9.10.2";i:5;s:6:"1.9.13";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (871, 'rg_gforms_key', '0e930f317b4ea80f8a7595c60ca44bc1', 'yes') ; 
INSERT INTO `wp_options` VALUES (877, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (1104, 'hmbkp_schedule_default-1', 'a:8:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:11:"max_backups";i:1;s:19:"HMBKP_Email_Service";a:1:{s:5:"email";s:0:"";}s:19:"schedule_start_time";i:1442181600;s:14:"duration_total";i:3131;s:16:"backup_run_count";i:27;s:5:"email";a:1:{s:5:"email";s:0:"";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1105, 'hmbkp_schedule_default-2', 'a:4:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:8:"manually";s:11:"max_backups";i:3;s:19:"HMBKP_Email_Service";a:1:{s:5:"email";s:0:"";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1106, 'hmbkp_plugin_version', '3.2.7', 'yes') ; 
INSERT INTO `wp_options` VALUES (1110, '_transient_timeout_hmbkp_schedule_default-1_database_filesize', '2785194652', 'no') ; 
INSERT INTO `wp_options` VALUES (1112, '_transient_hmbkp_schedule_default-1_database_filesize', '1441792', 'no') ; 
INSERT INTO `wp_options` VALUES (1273, 'auto_core_update_notified', 'a:4:{s:4:"type";s:6:"manual";s:5:"email";s:15:"jlcolema@me.com";s:7:"version";s:5:"4.2.2";s:9:"timestamp";i:1432902935;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1362, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (1410, 'ws_menu_editor', 'a:16:{s:22:"hide_advanced_settings";b:1;s:16:"show_extra_icons";b:0;s:11:"custom_menu";a:2:{s:4:"tree";a:26:{s:9:"index.php";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:10:">index.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:2:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:19:"index.php>index.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:4:"Home";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"index.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:9:"index.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:19:"index.php>index.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"index.php";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:25:"index.php>update-core.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:96:"Updates <span class=\'update-plugins count-0\' title=\'\'><span class=\'update-count\'>0</span></span>";s:12:"access_level";s:11:"update_core";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"update-core.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:9:"index.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:25:"index.php>update-core.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:15:"update-core.php";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Dashboard";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"index.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:0:"";s:9:"css_class";s:43:"menu-top menu-top-first menu-icon-dashboard";s:8:"hookname";s:14:"menu-dashboard";s:8:"icon_url";s:19:"dashicons-dashboard";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:10:">index.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"index.php";}}s:11:"separator_3";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:12:">separator_3";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"separator_3";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:0:"";s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:12:">separator_3";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";}}s:23:"edit.php?post_type=page";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:24:">edit.php?post_type=page";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:2:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:47:"edit.php?post_type=page>edit.php?post_type=page";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"All Pages";s:12:"access_level";s:10:"edit_pages";s:16:"extra_capability";s:0:"";s:4:"file";s:23:"edit.php?post_type=page";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:23:"edit.php?post_type=page";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:47:"edit.php?post_type=page>edit.php?post_type=page";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:23:"edit.php?post_type=page";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:51:"edit.php?post_type=page>post-new.php?post_type=page";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Add New";s:12:"access_level";s:10:"edit_pages";s:16:"extra_capability";s:0:"";s:4:"file";s:27:"post-new.php?post_type=page";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:23:"edit.php?post_type=page";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:51:"edit.php?post_type=page>post-new.php?post_type=page";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:27:"post-new.php?post_type=page";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:5:"Pages";s:12:"access_level";s:10:"edit_pages";s:16:"extra_capability";s:0:"";s:4:"file";s:23:"edit.php?post_type=page";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:0:"";s:9:"css_class";s:23:"menu-top menu-icon-page";s:8:"hookname";s:10:"menu-pages";s:8:"icon_url";s:20:"dashicons-admin-page";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:24:">edit.php?post_type=page";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:23:"edit.php?post_type=page";}}s:8:"edit.php";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:9:">edit.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:4:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:17:"edit.php>edit.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"All Posts";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:8:"edit.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:17:"edit.php>edit.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:8:"edit.php";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:21:"edit.php>post-new.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Add New";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"post-new.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:21:"edit.php>post-new.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:12:"post-new.php";}}i:2;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:40:"edit.php>edit-tags.php?taxonomy=category";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Categories";s:12:"access_level";s:17:"manage_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"edit-tags.php?taxonomy=category";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:40:"edit.php>edit-tags.php?taxonomy=category";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:31:"edit-tags.php?taxonomy=category";}}i:3;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:40:"edit.php>edit-tags.php?taxonomy=post_tag";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:4:"Tags";s:12:"access_level";s:17:"manage_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"edit-tags.php?taxonomy=post_tag";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:40:"edit.php>edit-tags.php?taxonomy=post_tag";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:31:"edit-tags.php?taxonomy=post_tag";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:5:"Posts";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:8:"edit.php";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:0:"";s:9:"css_class";s:37:"open-if-no-js menu-top menu-icon-post";s:8:"hookname";s:10:"menu-posts";s:8:"icon_url";s:20:"dashicons-admin-post";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:9:">edit.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:8:"edit.php";}}s:15:"separator_XvgrC";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:16:">separator_XvgrC";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"separator_XvgrC";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:0:"";s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:15:"separator_XvgrC";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:0:"";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";}}s:24:"edit.php?post_type=class";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:25:">edit.php?post_type=class";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:2:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:49:"edit.php?post_type=class>edit.php?post_type=class";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Classes";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:24:"edit.php?post_type=class";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:24:"edit.php?post_type=class";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:49:"edit.php?post_type=class>edit.php?post_type=class";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:24:"edit.php?post_type=class";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:53:"edit.php?post_type=class>post-new.php?post_type=class";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Add New";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:28:"post-new.php?post_type=class";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:24:"edit.php?post_type=class";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:53:"edit.php?post_type=class>post-new.php?post_type=class";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:28:"post-new.php?post_type=class";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Classes";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:24:"edit.php?post_type=class";s:12:"page_heading";s:0:"";s:8:"position";i:5;s:6:"parent";s:0:"";s:9:"css_class";s:23:"menu-top menu-icon-post";s:8:"hookname";s:16:"menu-posts-class";s:8:"icon_url";s:20:"dashicons-admin-post";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:25:">edit.php?post_type=class";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:24:"edit.php?post_type=class";}}s:22:"edit.php?post_type=faq";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:23:">edit.php?post_type=faq";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:2:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:45:"edit.php?post_type=faq>edit.php?post_type=faq";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:4:"FAQs";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:22:"edit.php?post_type=faq";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:22:"edit.php?post_type=faq";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:45:"edit.php?post_type=faq>edit.php?post_type=faq";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:22:"edit.php?post_type=faq";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:49:"edit.php?post_type=faq>post-new.php?post_type=faq";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Add New";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:26:"post-new.php?post_type=faq";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:22:"edit.php?post_type=faq";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:49:"edit.php?post_type=faq>post-new.php?post_type=faq";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:26:"post-new.php?post_type=faq";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:4:"FAQs";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:22:"edit.php?post_type=faq";s:12:"page_heading";s:0:"";s:8:"position";i:6;s:6:"parent";s:0:"";s:9:"css_class";s:23:"menu-top menu-icon-post";s:8:"hookname";s:14:"menu-posts-faq";s:8:"icon_url";s:20:"dashicons-admin-post";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:23:">edit.php?post_type=faq";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:22:"edit.php?post_type=faq";}}s:26:"edit.php?post_type=sponsor";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:7;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:27:">edit.php?post_type=sponsor";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:2:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:53:"edit.php?post_type=sponsor>edit.php?post_type=sponsor";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Sponsors";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:26:"edit.php?post_type=sponsor";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:26:"edit.php?post_type=sponsor";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:53:"edit.php?post_type=sponsor>edit.php?post_type=sponsor";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:26:"edit.php?post_type=sponsor";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:57:"edit.php?post_type=sponsor>post-new.php?post_type=sponsor";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Add New";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:30:"post-new.php?post_type=sponsor";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:26:"edit.php?post_type=sponsor";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:57:"edit.php?post_type=sponsor>post-new.php?post_type=sponsor";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:30:"post-new.php?post_type=sponsor";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Sponsors";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:26:"edit.php?post_type=sponsor";s:12:"page_heading";s:0:"";s:8:"position";i:7;s:6:"parent";s:0:"";s:9:"css_class";s:23:"menu-top menu-icon-post";s:8:"hookname";s:18:"menu-posts-sponsor";s:8:"icon_url";s:20:"dashicons-admin-post";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:27:">edit.php?post_type=sponsor";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:26:"edit.php?post_type=sponsor";}}s:30:"edit.php?post_type=testimonial";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:8;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:31:">edit.php?post_type=testimonial";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:2:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:61:"edit.php?post_type=testimonial>edit.php?post_type=testimonial";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:12:"Testimonials";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:30:"edit.php?post_type=testimonial";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:30:"edit.php?post_type=testimonial";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:61:"edit.php?post_type=testimonial>edit.php?post_type=testimonial";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:30:"edit.php?post_type=testimonial";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:65:"edit.php?post_type=testimonial>post-new.php?post_type=testimonial";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Add New";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:34:"post-new.php?post_type=testimonial";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:30:"edit.php?post_type=testimonial";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:65:"edit.php?post_type=testimonial>post-new.php?post_type=testimonial";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:34:"post-new.php?post_type=testimonial";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:12:"Testimonials";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:30:"edit.php?post_type=testimonial";s:12:"page_heading";s:0:"";s:8:"position";i:8;s:6:"parent";s:0:"";s:9:"css_class";s:23:"menu-top menu-icon-post";s:8:"hookname";s:22:"menu-posts-testimonial";s:8:"icon_url";s:20:"dashicons-admin-post";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:31:">edit.php?post_type=testimonial";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:30:"edit.php?post_type=testimonial";}}s:15:"separator_wIwND";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:9;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:16:">separator_wIwND";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"separator_wIwND";s:12:"page_heading";s:0:"";s:8:"position";i:9;s:6:"parent";s:0:"";s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:15:"separator_wIwND";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:0:"";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";}}s:31:"acf-options-contact-information";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:10;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:32:">acf-options-contact-information";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:3:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:63:"acf-options-contact-information>acf-options-contact-information";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:19:"Contact Information";s:10:"menu_title";s:19:"Contact Information";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"acf-options-contact-information";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:31:"acf-options-contact-information";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:63:"acf-options-contact-information>acf-options-contact-information";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:46:"admin.php?page=acf-options-contact-information";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:56:"acf-options-contact-information>acf-options-social-media";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:12:"Social Media";s:10:"menu_title";s:12:"Social Media";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:24:"acf-options-social-media";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:31:"acf-options-contact-information";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:56:"acf-options-contact-information>acf-options-social-media";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:39:"admin.php?page=acf-options-social-media";}}i:2;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:56:"acf-options-contact-information>acf-options-google-tools";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:12:"Google Tools";s:10:"menu_title";s:12:"Google Tools";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:24:"acf-options-google-tools";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:31:"acf-options-contact-information";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:56:"acf-options-contact-information>acf-options-google-tools";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:39:"admin.php?page=acf-options-google-tools";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Globals";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"acf-options-contact-information";s:12:"page_heading";s:0:"";s:8:"position";i:10;s:6:"parent";s:0:"";s:9:"css_class";s:72:"menu-top menu-icon-generic toplevel_page_acf-options-contact-information";s:8:"hookname";s:45:"toplevel_page_acf-options-contact-information";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:32:">acf-options-contact-information";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:46:"admin.php?page=acf-options-contact-information";}}s:5:"wpcf7";a:24:{s:10:"page_title";N;s:10:"menu_title";s:5:"Forms";s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:11;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:6:">wpcf7";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:2:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:11:"wpcf7>wpcf7";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:17:"Edit Contact Form";s:10:"menu_title";s:13:"Contact Forms";s:12:"access_level";s:24:"wpcf7_read_contact_forms";s:16:"extra_capability";s:0:"";s:4:"file";s:5:"wpcf7";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:5:"wpcf7";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:11:"wpcf7>wpcf7";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:20:"admin.php?page=wpcf7";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:15:"wpcf7>wpcf7-new";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:20:"Add New Contact Form";s:10:"menu_title";s:7:"Add New";s:12:"access_level";s:24:"wpcf7_edit_contact_forms";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"wpcf7-new";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:5:"wpcf7";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:15:"wpcf7>wpcf7-new";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:24:"admin.php?page=wpcf7-new";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:14:"Contact Form 7";s:10:"menu_title";s:7:"Contact";s:12:"access_level";s:24:"wpcf7_read_contact_forms";s:16:"extra_capability";s:0:"";s:4:"file";s:5:"wpcf7";s:12:"page_heading";s:0:"";s:8:"position";i:11;s:6:"parent";s:0:"";s:9:"css_class";s:28:"menu-top toplevel_page_wpcf7";s:8:"hookname";s:19:"toplevel_page_wpcf7";s:8:"icon_url";s:15:"dashicons-email";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:6:">wpcf7";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:20:"admin.php?page=wpcf7";}}s:15:"separator_GmRFX";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:12;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:16:">separator_GmRFX";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"separator_GmRFX";s:12:"page_heading";s:0:"";s:8:"position";i:12;s:6:"parent";s:0:"";s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:15:"separator_GmRFX";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:0:"";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";}}s:10:"upload.php";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:13;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:11:">upload.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:2:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:21:"upload.php>upload.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Library";s:12:"access_level";s:12:"upload_files";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"upload.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:10:"upload.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:21:"upload.php>upload.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"upload.php";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:24:"upload.php>media-new.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Add New";s:12:"access_level";s:12:"upload_files";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"media-new.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:10:"upload.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:24:"upload.php>media-new.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:13:"media-new.php";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:5:"Media";s:12:"access_level";s:12:"upload_files";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"upload.php";s:12:"page_heading";s:0:"";s:8:"position";i:13;s:6:"parent";s:0:"";s:9:"css_class";s:24:"menu-top menu-icon-media";s:8:"hookname";s:10:"menu-media";s:8:"icon_url";s:21:"dashicons-admin-media";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:11:">upload.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"upload.php";}}s:17:"edit-comments.php";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:14;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:18:">edit-comments.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:1:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:35:"edit-comments.php>edit-comments.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:1;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:12:"All Comments";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"edit-comments.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:17:"edit-comments.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:35:"edit-comments.php>edit-comments.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"edit-comments.php";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:1;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:87:"Comments <span class=\'awaiting-mod count-0\'><span class=\'pending-count\'>0</span></span>";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"edit-comments.php";s:12:"page_heading";s:0:"";s:8:"position";i:14;s:6:"parent";s:0:"";s:9:"css_class";s:27:"menu-top menu-icon-comments";s:8:"hookname";s:13:"menu-comments";s:8:"icon_url";s:24:"dashicons-admin-comments";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:18:">edit-comments.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"edit-comments.php";}}s:15:"separator_1fPeE";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:15;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:16:">separator_1fPeE";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"separator_1fPeE";s:12:"page_heading";s:0:"";s:8:"position";i:15;s:6:"parent";s:0:"";s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:15:"separator_1fPeE";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:0:"";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";}}s:9:"users.php";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:16;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:10:">users.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:3:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:19:"users.php>users.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"All Users";s:12:"access_level";s:10:"list_users";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"users.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:9:"users.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:19:"users.php>users.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"users.php";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:22:"users.php>user-new.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Add New";s:12:"access_level";s:12:"create_users";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"user-new.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:9:"users.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:22:"users.php>user-new.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:12:"user-new.php";}}i:2;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:21:"users.php>profile.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:12:"Your Profile";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"profile.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:9:"users.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:21:"users.php>profile.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"profile.php";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:5:"Users";s:12:"access_level";s:10:"list_users";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"users.php";s:12:"page_heading";s:0:"";s:8:"position";i:16;s:6:"parent";s:0:"";s:9:"css_class";s:24:"menu-top menu-icon-users";s:8:"hookname";s:10:"menu-users";s:8:"icon_url";s:21:"dashicons-admin-users";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:10:">users.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"users.php";}}s:11:"separator_4";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:17;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:12:">separator_4";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"separator_4";s:12:"page_heading";s:0:"";s:8:"position";i:17;s:6:"parent";s:0:"";s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:12:">separator_4";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";}}s:10:"themes.php";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:18;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:11:">themes.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:5:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:21:"themes.php>themes.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:1;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Themes";s:12:"access_level";s:13:"switch_themes";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"themes.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:21:"themes.php>themes.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"themes.php";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:24:"themes.php>customize.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:1;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Customize";s:12:"access_level";s:9:"customize";s:16:"extra_capability";s:0:"";s:4:"file";s:89:"customize.php?return=%2Fwp-admin%2Foptions-general.php%3Fpage%3Dmenu_editor%26message%3D1";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:20:"hide-if-no-customize";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:24:"themes.php>customize.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:89:"customize.php?return=%2Fwp-admin%2Foptions-general.php%3Fpage%3Dmenu_editor%26message%3D1";}}i:2;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:22:"themes.php>widgets.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:1;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Widgets";s:12:"access_level";s:18:"edit_theme_options";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"widgets.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:22:"themes.php>widgets.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"widgets.php";}}i:3;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:24:"themes.php>nav-menus.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:5:"Menus";s:12:"access_level";s:18:"edit_theme_options";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"nav-menus.php";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:24:"themes.php>nav-menus.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:13:"nav-menus.php";}}i:4;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:27:"themes.php>theme-editor.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:1;s:8:"defaults";a:18:{s:10:"page_title";s:6:"Editor";s:10:"menu_title";s:6:"Editor";s:12:"access_level";s:11:"edit_themes";s:16:"extra_capability";s:0:"";s:4:"file";s:16:"theme-editor.php";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:27:"themes.php>theme-editor.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:16:"theme-editor.php";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Appearance";s:12:"access_level";s:13:"switch_themes";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"themes.php";s:12:"page_heading";s:0:"";s:8:"position";i:18;s:6:"parent";s:0:"";s:9:"css_class";s:29:"menu-top menu-icon-appearance";s:8:"hookname";s:15:"menu-appearance";s:8:"icon_url";s:26:"dashicons-admin-appearance";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:11:">themes.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"themes.php";}}s:11:"plugins.php";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:19;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:12:">plugins.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:3:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:23:"plugins.php>plugins.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:17:"Installed Plugins";s:12:"access_level";s:16:"activate_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"plugins.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:11:"plugins.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:23:"plugins.php>plugins.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"plugins.php";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:30:"plugins.php>plugin-install.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Add New";s:12:"access_level";s:15:"install_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:18:"plugin-install.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:11:"plugins.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:30:"plugins.php>plugin-install.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:18:"plugin-install.php";}}i:2;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:29:"plugins.php>plugin-editor.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:1;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Editor";s:12:"access_level";s:12:"edit_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"plugin-editor.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:11:"plugins.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:29:"plugins.php>plugin-editor.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"plugin-editor.php";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:87:"Plugins <span class=\'update-plugins count-0\'><span class=\'plugin-count\'>0</span></span>";s:12:"access_level";s:16:"activate_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"plugins.php";s:12:"page_heading";s:0:"";s:8:"position";i:19;s:6:"parent";s:0:"";s:9:"css_class";s:26:"menu-top menu-icon-plugins";s:8:"hookname";s:12:"menu-plugins";s:8:"icon_url";s:23:"dashicons-admin-plugins";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:12:">plugins.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"plugins.php";}}s:15:"separator_Sxh9B";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:20;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:16:">separator_Sxh9B";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"separator_Sxh9B";s:12:"page_heading";s:0:"";s:8:"position";i:20;s:6:"parent";s:0:"";s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:15:"separator_Sxh9B";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:0:"";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";}}s:4:"cctm";a:24:{s:10:"page_title";N;s:10:"menu_title";s:4:"CCTM";s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:21;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:5:">cctm";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:5:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:9:"cctm>cctm";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:27:"Manage Custom Content Types";s:10:"menu_title";s:20:"Custom Content Types";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:4:"cctm";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:4:"cctm";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:9:"cctm>cctm";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:19:"admin.php?page=cctm";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:16:"cctm>cctm_fields";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:18:"CCTM Custom Fields";s:10:"menu_title";s:13:"Custom Fields";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"cctm_fields";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:4:"cctm";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:16:"cctm>cctm_fields";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:26:"admin.php?page=cctm_fields";}}i:2;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:18:"cctm>cctm_settings";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:20:"CCTM Global Settings";s:10:"menu_title";s:15:"Global Settings";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"cctm_settings";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:4:"cctm";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:18:"cctm>cctm_settings";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:28:"admin.php?page=cctm_settings";}}i:3;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:15:"cctm>cctm_tools";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:10:"CCTM Tools";s:10:"menu_title";s:5:"Tools";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"cctm_tools";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:4:"cctm";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:15:"cctm>cctm_tools";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:25:"admin.php?page=cctm_tools";}}i:4;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:15:"cctm>cctm_cache";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:16:"CCTM Clear Cache";s:10:"menu_title";s:11:"Clear Cache";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"cctm_cache";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:4:"cctm";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:15:"cctm>cctm_cache";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:25:"admin.php?page=cctm_cache";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:27:"Manage Custom Content Types";s:10:"menu_title";s:20:"Custom Content Types";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:4:"cctm";s:12:"page_heading";s:0:"";s:8:"position";i:21;s:6:"parent";s:0:"";s:9:"css_class";s:27:"menu-top toplevel_page_cctm";s:8:"hookname";s:18:"toplevel_page_cctm";s:8:"icon_url";s:85:"http://9zero7films.dev/wp-content/plugins/custom-content-type-manager/images/gear.png";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:5:">cctm";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:19:"admin.php?page=cctm";}}s:34:"edit.php?post_type=acf-field-group";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:22;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:35:">edit.php?post_type=acf-field-group";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:5:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:69:"edit.php?post_type=acf-field-group>edit.php?post_type=acf-field-group";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:12:"Field Groups";s:10:"menu_title";s:12:"Field Groups";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:34:"edit.php?post_type=acf-field-group";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:34:"edit.php?post_type=acf-field-group";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:69:"edit.php?post_type=acf-field-group>edit.php?post_type=acf-field-group";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:34:"edit.php?post_type=acf-field-group";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:73:"edit.php?post_type=acf-field-group>post-new.php?post_type=acf-field-group";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:7:"Add New";s:10:"menu_title";s:7:"Add New";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:38:"post-new.php?post_type=acf-field-group";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:34:"edit.php?post_type=acf-field-group";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:73:"edit.php?post_type=acf-field-group>post-new.php?post_type=acf-field-group";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:38:"post-new.php?post_type=acf-field-group";}}i:2;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:53:"edit.php?post_type=acf-field-group>acf-settings-tools";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:5:"Tools";s:10:"menu_title";s:5:"Tools";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:18:"acf-settings-tools";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:34:"edit.php?post_type=acf-field-group";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:53:"edit.php?post_type=acf-field-group>acf-settings-tools";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:58:"edit.php?post_type=acf-field-group&page=acf-settings-tools";}}i:3;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:52:"edit.php?post_type=acf-field-group>acf-settings-info";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:4:"Info";s:10:"menu_title";s:4:"Info";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"acf-settings-info";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:34:"edit.php?post_type=acf-field-group";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:52:"edit.php?post_type=acf-field-group>acf-settings-info";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:57:"edit.php?post_type=acf-field-group&page=acf-settings-info";}}i:4;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:55:"edit.php?post_type=acf-field-group>acf-settings-updates";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:7:"Updates";s:10:"menu_title";s:7:"Updates";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:20:"acf-settings-updates";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:34:"edit.php?post_type=acf-field-group";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:55:"edit.php?post_type=acf-field-group>acf-settings-updates";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:60:"edit.php?post_type=acf-field-group&page=acf-settings-updates";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:13:"Custom Fields";s:10:"menu_title";s:13:"Custom Fields";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:34:"edit.php?post_type=acf-field-group";s:12:"page_heading";s:0:"";s:8:"position";i:22;s:6:"parent";s:0:"";s:9:"css_class";s:53:"menu-top toplevel_page_edit?post_type=acf-field-group";s:8:"hookname";s:44:"toplevel_page_edit?post_type=acf-field-group";s:8:"icon_url";s:31:"dashicons-welcome-widgets-menus";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:35:">edit.php?post_type=acf-field-group";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:34:"edit.php?post_type=acf-field-group";}}s:11:"separator_5";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:23;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:12:">separator_5";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"separator_5";s:12:"page_heading";s:0:"";s:8:"position";i:23;s:6:"parent";s:0:"";s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:12:">separator_5";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";}}s:19:"options-general.php";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:24;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:20:">options-general.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:7:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:39:"options-general.php>options-general.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"General";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-general.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:39:"options-general.php>options-general.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-general.php";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:39:"options-general.php>options-writing.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Writing";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-writing.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:39:"options-general.php>options-writing.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-writing.php";}}i:2;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:39:"options-general.php>options-reading.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Reading";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-reading.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:39:"options-general.php>options-reading.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-reading.php";}}i:3;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:42:"options-general.php>options-discussion.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Discussion";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:22:"options-discussion.php";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:42:"options-general.php>options-discussion.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:22:"options-discussion.php";}}i:4;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:37:"options-general.php>options-media.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:5:"Media";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"options-media.php";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:37:"options-general.php>options-media.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"options-media.php";}}i:5;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:41:"options-general.php>options-permalink.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Permalinks";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:21:"options-permalink.php";s:12:"page_heading";s:0:"";s:8:"position";i:5;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:41:"options-general.php>options-permalink.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:21:"options-permalink.php";}}i:6;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:31:"options-general.php>menu_editor";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:11:"Menu Editor";s:10:"menu_title";s:11:"Menu Editor";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"menu_editor";s:12:"page_heading";s:0:"";s:8:"position";i:6;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:31:"options-general.php>menu_editor";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:36:"options-general.php?page=menu_editor";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Settings";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-general.php";s:12:"page_heading";s:0:"";s:8:"position";i:24;s:6:"parent";s:0:"";s:9:"css_class";s:27:"menu-top menu-icon-settings";s:8:"hookname";s:13:"menu-settings";s:8:"icon_url";s:24:"dashicons-admin-settings";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:20:">options-general.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-general.php";}}s:9:"tools.php";a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:25;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:10:">tools.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:5:{i:0;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:19:"tools.php>tools.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:15:"Available Tools";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"tools.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:19:"tools.php>tools.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"tools.php";}}i:1;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:20:"tools.php>import.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Import";s:12:"access_level";s:6:"import";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"import.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:20:"tools.php>import.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"import.php";}}i:2;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:20:"tools.php>export.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Export";s:12:"access_level";s:6:"export";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"export.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:20:"tools.php>export.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"export.php";}}i:3;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:25:"tools.php>backupwordpress";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:14:"Manage Backups";s:10:"menu_title";s:7:"Backups";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"backupwordpress";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:25:"tools.php>backupwordpress";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:30:"tools.php?page=backupwordpress";}}i:4;a:24:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:7:"open_in";N;s:11:"template_id";s:31:"tools.php>regenerate-thumbnails";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:21:"Regenerate Thumbnails";s:10:"menu_title";s:17:"Regen. Thumbnails";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:21:"regenerate-thumbnails";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:31:"tools.php>regenerate-thumbnails";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:36:"tools.php?page=regenerate-thumbnails";}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:8:"defaults";a:18:{s:10:"page_title";s:0:"";s:10:"menu_title";s:5:"Tools";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"tools.php";s:12:"page_heading";s:0:"";s:8:"position";i:25;s:6:"parent";s:0:"";s:9:"css_class";s:24:"menu-top menu-icon-tools";s:8:"hookname";s:10:"menu-tools";s:8:"icon_url";s:21:"dashicons-admin-tools";s:9:"separator";b:0;s:6:"colors";b:0;s:7:"open_in";s:11:"same_window";s:11:"template_id";s:10:">tools.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"tools.php";}}}s:6:"format";a:3:{s:4:"name";s:22:"Admin Menu Editor menu";s:7:"version";s:3:"6.0";s:13:"is_normalized";b:1;}}s:18:"first_install_time";i:1399996809;s:21:"display_survey_notice";b:0;s:17:"plugin_db_version";i:140;s:24:"security_logging_enabled";b:0;s:17:"menu_config_scope";s:6:"global";s:13:"plugin_access";s:14:"manage_options";s:15:"allowed_user_id";N;s:28:"plugins_page_allowed_user_id";N;s:27:"show_deprecated_hide_button";N;s:37:"dashboard_hiding_confirmation_enabled";b:1;s:21:"submenu_icons_enabled";s:9:"if_custom";s:16:"ui_colour_scheme";s:7:"classic";s:23:"show_plugin_menu_notice";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1416, '_transient_timeout_hmbkp_schedule_default-2_complete_filesize', '2800081504', 'no') ; 
INSERT INTO `wp_options` VALUES (1417, '_transient_hmbkp_schedule_default-2_complete_filesize', '35345411', 'no') ; 
INSERT INTO `wp_options` VALUES (1418, '_transient_timeout_hmbkp_schedule_default-2_database_filesize', '2800081648', 'no') ; 
INSERT INTO `wp_options` VALUES (1419, '_transient_hmbkp_schedule_default-2_database_filesize', '1425408', 'no') ; 
INSERT INTO `wp_options` VALUES (1488, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TXpNM09EWjhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMExUQTNMVEE0SURFMk9qQTFPakl4IjtzOjM6InVybCI7czoyMDoiaHR0cDovL3dvcmRwcmVzcy5kZXYiO30=', 'yes') ; 
INSERT INTO `wp_options` VALUES (1713, '_transient_timeout_hmbkp_schedule_default-1_complete_filesize', '2821874744', 'no') ; 
INSERT INTO `wp_options` VALUES (1714, '_transient_hmbkp_schedule_default-1_complete_filesize', '122833294', 'no') ; 
INSERT INTO `wp_options` VALUES (1719, 'WPLANG', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (1817, 'hmbkp_default_path', '/Users/Joshua/CMS/Wordpress/dev/html/wp-content/backupwordpress-011083f724-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (1818, 'hmbkp_path', '/Users/Joshua/CMS/Wordpress/dev/html/wp-content/backupwordpress-011083f724-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (2065, 'hmbkp_notices', 'a:1:{s:13:"backup_errors";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2359, '_transient_timeout_gform_update_info', '1441673917', 'no') ; 
INSERT INTO `wp_options` VALUES (2360, '_transient_gform_update_info', 'a:5:{s:7:"headers";a:8:{s:4:"date";s:29:"Mon, 07 Sep 2015 00:58:37 GMT";s:6:"server";s:12:"Apache/2.4.7";s:12:"x-powered-by";s:21:"PHP/5.5.9-1ubuntu4.11";s:4:"vary";s:15:"Accept-Encoding";s:16:"content-encoding";s:4:"gzip";s:14:"content-length";s:3:"460";s:10:"connection";s:5:"close";s:12:"content-type";s:9:"text/html";}s:4:"body";s:2382:"{"is_valid_key":"0","version":"1.9.13","url":"","expiration_time":1422252000,"offerings":{"gravityforms":{"is_available":true,"version":"1.9.13"},"gravityforms-beta":{"is_available":true,"version":"1.9.0.1"},"gravityformsactivecampaign":{"is_available":true,"version":"1.2"},"gravityformsagilecrm":{"is_available":true,"version":"1.0"},"gravityformsauthorizenet":{"is_available":true,"version":"2.1"},"gravityformsaweber":{"is_available":true,"version":"2.3"},"gravityformsbatchbook":{"is_available":true,"version":"1.0"},"gravityformscampaignmonitor":{"is_available":true,"version":"3.4.1"},"gravityformscampfire":{"is_available":true,"version":"1.0"},"gravityformscapsulecrm":{"is_available":true,"version":"1.0"},"gravityformscleverreach":{"is_available":true,"version":"1.1"},"gravityformscoupons":{"is_available":true,"version":"2.2"},"gravityformsdropbox":{"is_available":true,"version":"1.0"},"gravityformsemma":{"is_available":true,"version":"1.0"},"gravityformsfreshbooks":{"is_available":true,"version":"2.2"},"gravityformsgetresponse":{"is_available":true,"version":"1.0"},"gravityformshelpscout":{"is_available":true,"version":"1.2"},"gravityformshighrise":{"is_available":true,"version":"1.0"},"gravityformshipchat":{"is_available":true,"version":"1.0"},"gravityformsicontact":{"is_available":true,"version":"1.0"},"gravityformslogging":{"is_available":true,"version":"1.0"},"gravityformsmadmimi":{"is_available":true,"version":"1.0"},"gravityformsmailchimp":{"is_available":true,"version":"3.6"},"gravityformspaypal":{"is_available":true,"version":"2.4"},"gravityformspaypalpaymentspro":{"is_available":true,"version":"1.8.1"},"gravityformspaypalpro":{"is_available":true,"version":"1.6"},"gravityformspicatcha":{"is_available":false,"version":"2.0"},"gravityformspolls":{"is_available":true,"version":"2.3"},"gravityformsquiz":{"is_available":true,"version":"2.4"},"gravityformssignature":{"is_available":true,"version":"2.3"},"gravityformsslack":{"is_available":true,"version":"1.2"},"gravityformsstripe":{"is_available":true,"version":"1.8"},"gravityformssurvey":{"is_available":true,"version":"2.5"},"gravityformstwilio":{"is_available":true,"version":"2.1"},"gravityformsuserregistration":{"is_available":true,"version":"2.4"},"gravityformszapier":{"is_available":true,"version":"1.8"},"gravityformszohocrm":{"is_available":true,"version":"1.0"}},"is_active":"1"}";s:8:"response";a:2:{s:4:"code";i:200;s:7:"message";s:2:"OK";}s:7:"cookies";a:0:{}s:8:"filename";N;}', 'no') ; 
INSERT INTO `wp_options` VALUES (2379, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1441630728', 'no') ; 
INSERT INTO `wp_options` VALUES (2380, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2015/08/billie/\'>WordPress 4.3 “Billie”</a> <span class="rss-date">August 18, 2015</span><div class="rssSummary">Version 4.3 of WordPress, named “Billie” in honor of jazz singer Billie Holiday, is available for download or update in your WordPress dashboard. New features in 4.3 make it even easier to format your content and customize your site. Menus in the Customizer Create your menu, update it, and assign it, all while live-previewing in [&hellip;]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://poststatus.com/using-react-with-wordpress-draft-podcast/\'>Post Status: Using React with WordPress — Draft podcast</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/help-me-add-comment-approval-notifications-to-wordpress\'>WPTavern: Help Me Add Comment Approval Notifications to WordPress</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/how-chris-klosowskis-lifestyle-changed-by-writing-one-wordpress-plugin\'>WPTavern: How Chris Klosowski’s Lifestyle Changed by Writing One WordPress Plugin</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'https://wordpress.org/plugins/woocommerce/\' class=\'dashboard-news-plugin-link\'>WooCommerce - excelling eCommerce</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=woocommerce&amp;_wpnonce=84eac0ebf3&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'WooCommerce - excelling eCommerce\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (2408, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1442347889;s:7:"checked";a:2:{s:11:"9zero7films";s:3:"1.0";s:13:"twentyfifteen";s:3:"1.3";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2409, 'finished_splitting_shared_terms', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (2411, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:2:{i:0;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.3.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.3.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.3.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.3.1-new-bundled.zip";s:7:"partial";s:69:"https://downloads.wordpress.org/release/wordpress-4.3.1-partial-0.zip";s:8:"rollback";b:0;}s:7:"current";s:5:"4.3.1";s:7:"version";s:5:"4.3.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:3:"4.3";}i:1;O:8:"stdClass":12:{s:8:"response";s:10:"autoupdate";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.3.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.3.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.3.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.3.1-new-bundled.zip";s:7:"partial";s:69:"https://downloads.wordpress.org/release/wordpress-4.3.1-partial-0.zip";s:8:"rollback";s:70:"https://downloads.wordpress.org/release/wordpress-4.3.1-rollback-0.zip";}s:7:"current";s:5:"4.3.1";s:7:"version";s:5:"4.3.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:3:"4.3";s:13:"support_email";s:26:"updatehelp42@wordpress.org";s:9:"new_files";s:0:"";}}s:12:"last_checked";i:1442347835;s:15:"version_checked";s:3:"4.3";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2413, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (2424, 'theme_mods_twentyfifteen', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1441591028;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2425, 'theme_mods_9zero7films', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2434, 'widget_calendar', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2435, 'widget_nav_menu', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2436, 'widget_gform_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2437, 'widget_pages', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2438, 'widget_cctm_post_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2440, 'widget_summarizeposts_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2441, 'widget_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2451, 'rewrite_rules', 'a:113:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:40:"testimonials/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"testimonials/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"testimonials/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"testimonials/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"testimonials/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"testimonials/([^/]+)/trackback/?$";s:38:"index.php?testimonial=$matches[1]&tb=1";s:41:"testimonials/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?testimonial=$matches[1]&paged=$matches[2]";s:48:"testimonials/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?testimonial=$matches[1]&cpage=$matches[2]";s:33:"testimonials/([^/]+)(/[0-9]+)?/?$";s:50:"index.php?testimonial=$matches[1]&page=$matches[2]";s:29:"testimonials/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"testimonials/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"testimonials/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"testimonials/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"testimonials/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:35:"classes/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"classes/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"classes/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"classes/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"classes/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"classes/([^/]+)/trackback/?$";s:32:"index.php?class=$matches[1]&tb=1";s:36:"classes/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?class=$matches[1]&paged=$matches[2]";s:43:"classes/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?class=$matches[1]&cpage=$matches[2]";s:28:"classes/([^/]+)(/[0-9]+)?/?$";s:44:"index.php?class=$matches[1]&page=$matches[2]";s:24:"classes/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"classes/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"classes/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"classes/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"classes/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"faqs/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"faqs/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"faqs/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"faqs/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"faqs/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:25:"faqs/([^/]+)/trackback/?$";s:30:"index.php?faq=$matches[1]&tb=1";s:33:"faqs/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?faq=$matches[1]&paged=$matches[2]";s:40:"faqs/([^/]+)/comment-page-([0-9]{1,})/?$";s:43:"index.php?faq=$matches[1]&cpage=$matches[2]";s:25:"faqs/([^/]+)(/[0-9]+)?/?$";s:42:"index.php?faq=$matches[1]&page=$matches[2]";s:21:"faqs/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"faqs/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"faqs/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"faqs/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"faqs/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=10&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:47:"[0-9]{4}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:44:"([0-9]{4})/([0-9]{1,2})/([^/]+)/trackback/?$";s:69:"index.php?year=$matches[1]&monthnum=$matches[2]&name=$matches[3]&tb=1";s:64:"([0-9]{4})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&name=$matches[3]&feed=$matches[4]";s:59:"([0-9]{4})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&name=$matches[3]&feed=$matches[4]";s:52:"([0-9]{4})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&name=$matches[3]&paged=$matches[4]";s:59:"([0-9]{4})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&name=$matches[3]&cpage=$matches[4]";s:44:"([0-9]{4})/([0-9]{1,2})/([^/]+)(/[0-9]+)?/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&name=$matches[3]&page=$matches[4]";s:36:"[0-9]{4}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"[0-9]{4}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"[0-9]{4}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"[0-9]{4}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"[0-9]{4}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2457, 'wpcf7', 'a:1:{s:7:"version";s:5:"4.2.2";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2465, 'options_social_twitter', 'http://www.twitter.com', 'no') ; 
INSERT INTO `wp_options` VALUES (2466, '_options_social_twitter', 'field_52d9041a331f8', 'no') ; 
INSERT INTO `wp_options` VALUES (2467, 'options_social_facebook', 'http://www.facebook.com', 'no') ; 
INSERT INTO `wp_options` VALUES (2468, '_options_social_facebook', 'field_52d9042c331f9', 'no') ; 
INSERT INTO `wp_options` VALUES (2469, 'options_social_linkedin', '', 'no') ; 
INSERT INTO `wp_options` VALUES (2470, '_options_social_linkedin', 'field_52d9044e331fa', 'no') ; 
INSERT INTO `wp_options` VALUES (2471, 'options_social_google_plus', 'http://www.google.com', 'no') ; 
INSERT INTO `wp_options` VALUES (2472, '_options_social_google_plus', 'field_52d90475331fc', 'no') ; 
INSERT INTO `wp_options` VALUES (2473, 'options_connect_0_google_url', '', 'no') ; 
INSERT INTO `wp_options` VALUES (2474, '_options_connect_0_google_url', 'field_55ed4290bc03a', 'no') ; 
INSERT INTO `wp_options` VALUES (2475, 'options_connect_1_facebook_url', 'http://www.facebook.com', 'no') ; 
INSERT INTO `wp_options` VALUES (2476, '_options_connect_1_facebook_url', 'field_55ed4249bc038', 'no') ; 
INSERT INTO `wp_options` VALUES (2477, 'options_connect', 'a:2:{i:0;s:14:"connect_google";i:1;s:16:"connect_facebook";}', 'no') ; 
INSERT INTO `wp_options` VALUES (2478, '_options_connect', 'field_55ed41d2bc037', 'no') ; 
INSERT INTO `wp_options` VALUES (2544, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2582, '_site_transient_timeout_available_translations', '1441949493', 'yes') ; 
INSERT INTO `wp_options` VALUES (2583, '_site_transient_available_translations', 'a:65:{s:2:"ar";a:8:{s:8:"language";s:2:"ar";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-18 00:32:07";s:12:"english_name";s:6:"Arabic";s:11:"native_name";s:14:"العربية";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/ar.zip";s:3:"iso";a:2:{i:1;s:2:"ar";i:2;s:3:"ara";}s:7:"strings";a:1:{s:8:"continue";s:16:"المتابعة";}}s:3:"ary";a:8:{s:8:"language";s:3:"ary";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-07 00:00:29";s:12:"english_name";s:15:"Moroccan Arabic";s:11:"native_name";s:31:"العربية المغربية";s:7:"package";s:60:"https://downloads.wordpress.org/translation/core/4.3/ary.zip";s:3:"iso";a:2:{i:1;s:5:"ar_MA";i:3;s:3:"ary";}s:7:"strings";a:1:{s:8:"continue";s:16:"المتابعة";}}s:2:"az";a:8:{s:8:"language";s:2:"az";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-27 19:48:02";s:12:"english_name";s:11:"Azerbaijani";s:11:"native_name";s:16:"Azərbaycan dili";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/az.zip";s:3:"iso";a:2:{i:1;s:2:"az";i:2;s:3:"aze";}s:7:"strings";a:1:{s:8:"continue";s:5:"Davam";}}s:5:"bg_BG";a:8:{s:8:"language";s:5:"bg_BG";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-17 19:15:29";s:12:"english_name";s:9:"Bulgarian";s:11:"native_name";s:18:"Български";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/bg_BG.zip";s:3:"iso";a:2:{i:1;s:2:"bg";i:2;s:3:"bul";}s:7:"strings";a:1:{s:8:"continue";s:22:"Продължение";}}s:5:"bn_BD";a:8:{s:8:"language";s:5:"bn_BD";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-20 08:45:05";s:12:"english_name";s:7:"Bengali";s:11:"native_name";s:15:"বাংলা";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/bn_BD.zip";s:3:"iso";a:1:{i:1;s:2:"bn";}s:7:"strings";a:1:{s:8:"continue";s:23:"এগিয়ে চল.";}}s:5:"bs_BA";a:8:{s:8:"language";s:5:"bs_BA";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-18 21:20:44";s:12:"english_name";s:7:"Bosnian";s:11:"native_name";s:8:"Bosanski";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/bs_BA.zip";s:3:"iso";a:2:{i:1;s:2:"bs";i:2;s:3:"bos";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:2:"ca";a:8:{s:8:"language";s:2:"ca";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-18 04:19:00";s:12:"english_name";s:7:"Catalan";s:11:"native_name";s:7:"Català";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/ca.zip";s:3:"iso";a:2:{i:1;s:2:"ca";i:2;s:3:"cat";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:2:"cy";a:8:{s:8:"language";s:2:"cy";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-19 09:17:13";s:12:"english_name";s:5:"Welsh";s:11:"native_name";s:7:"Cymraeg";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/cy.zip";s:3:"iso";a:2:{i:1;s:2:"cy";i:2;s:3:"cym";}s:7:"strings";a:1:{s:8:"continue";s:6:"Parhau";}}s:5:"da_DK";a:8:{s:8:"language";s:5:"da_DK";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-18 19:34:34";s:12:"english_name";s:6:"Danish";s:11:"native_name";s:5:"Dansk";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/da_DK.zip";s:3:"iso";a:2:{i:1;s:2:"da";i:2;s:3:"dan";}s:7:"strings";a:1:{s:8:"continue";s:12:"Forts&#230;t";}}s:5:"de_DE";a:8:{s:8:"language";s:5:"de_DE";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-08 13:22:20";s:12:"english_name";s:6:"German";s:11:"native_name";s:7:"Deutsch";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/de_DE.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:10:"Fortfahren";}}s:5:"de_CH";a:8:{s:8:"language";s:5:"de_CH";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-09 10:05:26";s:12:"english_name";s:20:"German (Switzerland)";s:11:"native_name";s:17:"Deutsch (Schweiz)";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/de_CH.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:10:"Fortfahren";}}s:12:"de_DE_formal";a:8:{s:8:"language";s:12:"de_DE_formal";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-08 13:35:36";s:12:"english_name";s:15:"German (Formal)";s:11:"native_name";s:13:"Deutsch (Sie)";s:7:"package";s:69:"https://downloads.wordpress.org/translation/core/4.3/de_DE_formal.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:10:"Fortfahren";}}s:2:"el";a:8:{s:8:"language";s:2:"el";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-03 22:30:30";s:12:"english_name";s:5:"Greek";s:11:"native_name";s:16:"Ελληνικά";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/el.zip";s:3:"iso";a:2:{i:1;s:2:"el";i:2;s:3:"ell";}s:7:"strings";a:1:{s:8:"continue";s:16:"Συνέχεια";}}s:5:"en_AU";a:8:{s:8:"language";s:5:"en_AU";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-13 23:56:05";s:12:"english_name";s:19:"English (Australia)";s:11:"native_name";s:19:"English (Australia)";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/en_AU.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_NZ";a:8:{s:8:"language";s:5:"en_NZ";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-17 22:20:50";s:12:"english_name";s:21:"English (New Zealand)";s:11:"native_name";s:21:"English (New Zealand)";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/en_NZ.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_GB";a:8:{s:8:"language";s:5:"en_GB";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-17 20:57:21";s:12:"english_name";s:12:"English (UK)";s:11:"native_name";s:12:"English (UK)";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/en_GB.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_CA";a:8:{s:8:"language";s:5:"en_CA";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-14 00:38:16";s:12:"english_name";s:16:"English (Canada)";s:11:"native_name";s:16:"English (Canada)";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/en_CA.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"eo";a:8:{s:8:"language";s:2:"eo";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-16 10:50:33";s:12:"english_name";s:9:"Esperanto";s:11:"native_name";s:9:"Esperanto";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/eo.zip";s:3:"iso";a:2:{i:1;s:2:"eo";i:2;s:3:"epo";}s:7:"strings";a:1:{s:8:"continue";s:8:"Daŭrigi";}}s:5:"es_PE";a:8:{s:8:"language";s:5:"es_PE";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-19 14:33:57";s:12:"english_name";s:14:"Spanish (Peru)";s:11:"native_name";s:17:"Español de Perú";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/es_PE.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_ES";a:8:{s:8:"language";s:5:"es_ES";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-19 00:53:46";s:12:"english_name";s:15:"Spanish (Spain)";s:11:"native_name";s:8:"Español";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/es_ES.zip";s:3:"iso";a:1:{i:1;s:2:"es";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CO";a:8:{s:8:"language";s:5:"es_CO";s:7:"version";s:6:"4.3-RC";s:7:"updated";s:19:"2015-08-04 06:10:33";s:12:"english_name";s:18:"Spanish (Colombia)";s:11:"native_name";s:20:"Español de Colombia";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/4.3-RC/es_CO.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CL";a:8:{s:8:"language";s:5:"es_CL";s:7:"version";s:3:"4.0";s:7:"updated";s:19:"2014-09-04 19:47:01";s:12:"english_name";s:15:"Spanish (Chile)";s:11:"native_name";s:17:"Español de Chile";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.0/es_CL.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_MX";a:8:{s:8:"language";s:5:"es_MX";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-18 18:40:22";s:12:"english_name";s:16:"Spanish (Mexico)";s:11:"native_name";s:19:"Español de México";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/es_MX.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:2:"et";a:8:{s:8:"language";s:2:"et";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-05 16:34:02";s:12:"english_name";s:8:"Estonian";s:11:"native_name";s:5:"Eesti";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/et.zip";s:3:"iso";a:2:{i:1;s:2:"et";i:2;s:3:"est";}s:7:"strings";a:1:{s:8:"continue";s:6:"Jätka";}}s:2:"eu";a:8:{s:8:"language";s:2:"eu";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-25 13:32:40";s:12:"english_name";s:6:"Basque";s:11:"native_name";s:7:"Euskara";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/eu.zip";s:3:"iso";a:2:{i:1;s:2:"eu";i:2;s:3:"eus";}s:7:"strings";a:1:{s:8:"continue";s:8:"Jarraitu";}}s:5:"fa_IR";a:8:{s:8:"language";s:5:"fa_IR";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-20 13:36:08";s:12:"english_name";s:7:"Persian";s:11:"native_name";s:10:"فارسی";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/fa_IR.zip";s:3:"iso";a:2:{i:1;s:2:"fa";i:2;s:3:"fas";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:2:"fi";a:8:{s:8:"language";s:2:"fi";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-18 09:17:58";s:12:"english_name";s:7:"Finnish";s:11:"native_name";s:5:"Suomi";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/fi.zip";s:3:"iso";a:2:{i:1;s:2:"fi";i:2;s:3:"fin";}s:7:"strings";a:1:{s:8:"continue";s:5:"Jatka";}}s:5:"fr_BE";a:8:{s:8:"language";s:5:"fr_BE";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-06 20:37:24";s:12:"english_name";s:16:"French (Belgium)";s:11:"native_name";s:21:"Français de Belgique";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/fr_BE.zip";s:3:"iso";a:2:{i:1;s:2:"fr";i:2;s:3:"fra";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:5:"fr_FR";a:8:{s:8:"language";s:5:"fr_FR";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-10 15:08:48";s:12:"english_name";s:15:"French (France)";s:11:"native_name";s:9:"Français";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/fr_FR.zip";s:3:"iso";a:1:{i:1;s:2:"fr";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:2:"gd";a:8:{s:8:"language";s:2:"gd";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-27 14:28:09";s:12:"english_name";s:15:"Scottish Gaelic";s:11:"native_name";s:9:"Gàidhlig";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/gd.zip";s:3:"iso";a:3:{i:1;s:2:"gd";i:2;s:3:"gla";i:3;s:3:"gla";}s:7:"strings";a:1:{s:8:"continue";s:15:"Lean air adhart";}}s:5:"gl_ES";a:8:{s:8:"language";s:5:"gl_ES";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-18 23:34:00";s:12:"english_name";s:8:"Galician";s:11:"native_name";s:6:"Galego";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/gl_ES.zip";s:3:"iso";a:2:{i:1;s:2:"gl";i:2;s:3:"glg";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:3:"haz";a:8:{s:8:"language";s:3:"haz";s:7:"version";s:5:"4.1.7";s:7:"updated";s:19:"2015-03-26 15:20:27";s:12:"english_name";s:8:"Hazaragi";s:11:"native_name";s:15:"هزاره گی";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.1.7/haz.zip";s:3:"iso";a:1:{i:3;s:3:"haz";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:5:"he_IL";a:8:{s:8:"language";s:5:"he_IL";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-17 15:13:38";s:12:"english_name";s:6:"Hebrew";s:11:"native_name";s:16:"עִבְרִית";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/he_IL.zip";s:3:"iso";a:1:{i:1;s:2:"he";}s:7:"strings";a:1:{s:8:"continue";s:12:"להמשיך";}}s:2:"hr";a:8:{s:8:"language";s:2:"hr";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-08 19:57:36";s:12:"english_name";s:8:"Croatian";s:11:"native_name";s:8:"Hrvatski";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/hr.zip";s:3:"iso";a:2:{i:1;s:2:"hr";i:2;s:3:"hrv";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:5:"hu_HU";a:8:{s:8:"language";s:5:"hu_HU";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-20 12:47:55";s:12:"english_name";s:9:"Hungarian";s:11:"native_name";s:6:"Magyar";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/hu_HU.zip";s:3:"iso";a:2:{i:1;s:2:"hu";i:2;s:3:"hun";}s:7:"strings";a:1:{s:8:"continue";s:7:"Tovább";}}s:2:"hy";a:8:{s:8:"language";s:2:"hy";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-17 13:36:47";s:12:"english_name";s:8:"Armenian";s:11:"native_name";s:14:"Հայերեն";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/hy.zip";s:3:"iso";a:2:{i:1;s:2:"hy";i:2;s:3:"hye";}s:7:"strings";a:1:{s:8:"continue";s:20:"Շարունակել";}}s:5:"id_ID";a:8:{s:8:"language";s:5:"id_ID";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-08 17:47:38";s:12:"english_name";s:10:"Indonesian";s:11:"native_name";s:16:"Bahasa Indonesia";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/id_ID.zip";s:3:"iso";a:2:{i:1;s:2:"id";i:2;s:3:"ind";}s:7:"strings";a:1:{s:8:"continue";s:9:"Lanjutkan";}}s:5:"is_IS";a:8:{s:8:"language";s:5:"is_IS";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-22 13:47:37";s:12:"english_name";s:9:"Icelandic";s:11:"native_name";s:9:"Íslenska";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/is_IS.zip";s:3:"iso";a:2:{i:1;s:2:"is";i:2;s:3:"isl";}s:7:"strings";a:1:{s:8:"continue";s:6:"Áfram";}}s:5:"it_IT";a:8:{s:8:"language";s:5:"it_IT";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-19 06:13:38";s:12:"english_name";s:7:"Italian";s:11:"native_name";s:8:"Italiano";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/it_IT.zip";s:3:"iso";a:2:{i:1;s:2:"it";i:2;s:3:"ita";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:2:"ja";a:8:{s:8:"language";s:2:"ja";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-03 02:18:06";s:12:"english_name";s:8:"Japanese";s:11:"native_name";s:9:"日本語";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/ja.zip";s:3:"iso";a:1:{i:1;s:2:"ja";}s:7:"strings";a:1:{s:8:"continue";s:9:"続ける";}}s:5:"ko_KR";a:8:{s:8:"language";s:5:"ko_KR";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-17 22:59:51";s:12:"english_name";s:6:"Korean";s:11:"native_name";s:9:"한국어";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/ko_KR.zip";s:3:"iso";a:2:{i:1;s:2:"ko";i:2;s:3:"kor";}s:7:"strings";a:1:{s:8:"continue";s:6:"계속";}}s:5:"lt_LT";a:8:{s:8:"language";s:5:"lt_LT";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-18 07:48:28";s:12:"english_name";s:10:"Lithuanian";s:11:"native_name";s:15:"Lietuvių kalba";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/lt_LT.zip";s:3:"iso";a:2:{i:1;s:2:"lt";i:2;s:3:"lit";}s:7:"strings";a:1:{s:8:"continue";s:6:"Tęsti";}}s:5:"my_MM";a:8:{s:8:"language";s:5:"my_MM";s:7:"version";s:5:"4.1.7";s:7:"updated";s:19:"2015-03-26 15:57:42";s:12:"english_name";s:17:"Myanmar (Burmese)";s:11:"native_name";s:15:"ဗမာစာ";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.7/my_MM.zip";s:3:"iso";a:2:{i:1;s:2:"my";i:2;s:3:"mya";}s:7:"strings";a:1:{s:8:"continue";s:54:"ဆက်လက်လုပ်ေဆာင်ပါ။";}}s:5:"nb_NO";a:8:{s:8:"language";s:5:"nb_NO";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-17 18:45:19";s:12:"english_name";s:19:"Norwegian (Bokmål)";s:11:"native_name";s:13:"Norsk bokmål";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/nb_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nb";i:2;s:3:"nob";}s:7:"strings";a:1:{s:8:"continue";s:8:"Fortsett";}}s:5:"nl_NL";a:8:{s:8:"language";s:5:"nl_NL";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-20 06:57:09";s:12:"english_name";s:5:"Dutch";s:11:"native_name";s:10:"Nederlands";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/nl_NL.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:5:"nn_NO";a:8:{s:8:"language";s:5:"nn_NO";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-17 18:56:13";s:12:"english_name";s:19:"Norwegian (Nynorsk)";s:11:"native_name";s:13:"Norsk nynorsk";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/nn_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nn";i:2;s:3:"nno";}s:7:"strings";a:1:{s:8:"continue";s:9:"Hald fram";}}s:3:"oci";a:8:{s:8:"language";s:3:"oci";s:7:"version";s:6:"4.3-RC";s:7:"updated";s:19:"2015-08-02 07:53:33";s:12:"english_name";s:7:"Occitan";s:11:"native_name";s:7:"Occitan";s:7:"package";s:63:"https://downloads.wordpress.org/translation/core/4.3-RC/oci.zip";s:3:"iso";a:2:{i:1;s:2:"oc";i:2;s:3:"oci";}s:7:"strings";a:1:{s:8:"continue";s:9:"Contunhar";}}s:5:"pl_PL";a:8:{s:8:"language";s:5:"pl_PL";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-27 13:38:57";s:12:"english_name";s:6:"Polish";s:11:"native_name";s:6:"Polski";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/pl_PL.zip";s:3:"iso";a:2:{i:1;s:2:"pl";i:2;s:3:"pol";}s:7:"strings";a:1:{s:8:"continue";s:9:"Kontynuuj";}}s:2:"ps";a:8:{s:8:"language";s:2:"ps";s:7:"version";s:5:"4.1.7";s:7:"updated";s:19:"2015-03-29 22:19:48";s:12:"english_name";s:6:"Pashto";s:11:"native_name";s:8:"پښتو";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.7/ps.zip";s:3:"iso";a:2:{i:1;s:2:"ps";i:2;s:3:"pus";}s:7:"strings";a:1:{s:8:"continue";s:8:"دوام";}}s:5:"pt_BR";a:8:{s:8:"language";s:5:"pt_BR";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-20 02:24:55";s:12:"english_name";s:19:"Portuguese (Brazil)";s:11:"native_name";s:20:"Português do Brasil";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/pt_BR.zip";s:3:"iso";a:2:{i:1;s:2:"pt";i:2;s:3:"por";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"pt_PT";a:8:{s:8:"language";s:5:"pt_PT";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-08 14:23:10";s:12:"english_name";s:21:"Portuguese (Portugal)";s:11:"native_name";s:10:"Português";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/pt_PT.zip";s:3:"iso";a:1:{i:1;s:2:"pt";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"ro_RO";a:8:{s:8:"language";s:5:"ro_RO";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-18 16:44:05";s:12:"english_name";s:8:"Romanian";s:11:"native_name";s:8:"Română";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/ro_RO.zip";s:3:"iso";a:2:{i:1;s:2:"ro";i:2;s:3:"ron";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuă";}}s:5:"ru_RU";a:8:{s:8:"language";s:5:"ru_RU";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-03 10:08:50";s:12:"english_name";s:7:"Russian";s:11:"native_name";s:14:"Русский";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/ru_RU.zip";s:3:"iso";a:2:{i:1;s:2:"ru";i:2;s:3:"rus";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продолжить";}}s:5:"sk_SK";a:8:{s:8:"language";s:5:"sk_SK";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-31 19:45:06";s:12:"english_name";s:6:"Slovak";s:11:"native_name";s:11:"Slovenčina";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/sk_SK.zip";s:3:"iso";a:2:{i:1;s:2:"sk";i:2;s:3:"slk";}s:7:"strings";a:1:{s:8:"continue";s:12:"Pokračovať";}}s:5:"sl_SI";a:8:{s:8:"language";s:5:"sl_SI";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-06 16:10:24";s:12:"english_name";s:9:"Slovenian";s:11:"native_name";s:13:"Slovenščina";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/sl_SI.zip";s:3:"iso";a:2:{i:1;s:2:"sl";i:2;s:3:"slv";}s:7:"strings";a:1:{s:8:"continue";s:10:"Nadaljujte";}}s:2:"sq";a:8:{s:8:"language";s:2:"sq";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-18 17:16:31";s:12:"english_name";s:8:"Albanian";s:11:"native_name";s:5:"Shqip";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/sq.zip";s:3:"iso";a:2:{i:1;s:2:"sq";i:2;s:3:"sqi";}s:7:"strings";a:1:{s:8:"continue";s:6:"Vazhdo";}}s:5:"sr_RS";a:8:{s:8:"language";s:5:"sr_RS";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-17 18:31:56";s:12:"english_name";s:7:"Serbian";s:11:"native_name";s:23:"Српски језик";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/sr_RS.zip";s:3:"iso";a:2:{i:1;s:2:"sr";i:2;s:3:"srp";}s:7:"strings";a:1:{s:8:"continue";s:14:"Настави";}}s:5:"sv_SE";a:8:{s:8:"language";s:5:"sv_SE";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-19 10:43:45";s:12:"english_name";s:7:"Swedish";s:11:"native_name";s:7:"Svenska";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/sv_SE.zip";s:3:"iso";a:2:{i:1;s:2:"sv";i:2;s:3:"swe";}s:7:"strings";a:1:{s:8:"continue";s:9:"Fortsätt";}}s:2:"th";a:8:{s:8:"language";s:2:"th";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-18 14:10:42";s:12:"english_name";s:4:"Thai";s:11:"native_name";s:9:"ไทย";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/th.zip";s:3:"iso";a:2:{i:1;s:2:"th";i:2;s:3:"tha";}s:7:"strings";a:1:{s:8:"continue";s:15:"ต่อไป";}}s:2:"tl";a:8:{s:8:"language";s:2:"tl";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-20 03:52:15";s:12:"english_name";s:7:"Tagalog";s:11:"native_name";s:7:"Tagalog";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/tl.zip";s:3:"iso";a:2:{i:1;s:2:"tl";i:2;s:3:"tgl";}s:7:"strings";a:1:{s:8:"continue";s:10:"Magpatuloy";}}s:5:"tr_TR";a:8:{s:8:"language";s:5:"tr_TR";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-20 05:50:57";s:12:"english_name";s:7:"Turkish";s:11:"native_name";s:8:"Türkçe";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/tr_TR.zip";s:3:"iso";a:2:{i:1;s:2:"tr";i:2;s:3:"tur";}s:7:"strings";a:1:{s:8:"continue";s:5:"Devam";}}s:5:"ug_CN";a:8:{s:8:"language";s:5:"ug_CN";s:7:"version";s:5:"4.1.7";s:7:"updated";s:19:"2015-03-26 16:45:38";s:12:"english_name";s:6:"Uighur";s:11:"native_name";s:9:"Uyƣurqə";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.7/ug_CN.zip";s:3:"iso";a:2:{i:1;s:2:"ug";i:2;s:3:"uig";}s:7:"strings";a:1:{s:8:"continue";s:26:"داۋاملاشتۇرۇش";}}s:2:"uk";a:8:{s:8:"language";s:2:"uk";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-09-10 12:01:01";s:12:"english_name";s:9:"Ukrainian";s:11:"native_name";s:20:"Українська";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.3/uk.zip";s:3:"iso";a:2:{i:1;s:2:"uk";i:2;s:3:"ukr";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продовжити";}}s:5:"zh_CN";a:8:{s:8:"language";s:5:"zh_CN";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-20 19:10:20";s:12:"english_name";s:15:"Chinese (China)";s:11:"native_name";s:12:"简体中文";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/zh_CN.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"继续";}}s:5:"zh_TW";a:8:{s:8:"language";s:5:"zh_TW";s:7:"version";s:3:"4.3";s:7:"updated";s:19:"2015-08-19 00:50:06";s:12:"english_name";s:16:"Chinese (Taiwan)";s:11:"native_name";s:12:"繁體中文";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3/zh_TW.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"繼續";}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2589, '_site_transient_timeout_browser_3e236b20ec78fe3b7960c0638e68fd55', '1442601929', 'yes') ; 
INSERT INTO `wp_options` VALUES (2590, '_site_transient_browser_3e236b20ec78fe3b7960c0638e68fd55', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Safari";s:7:"version";s:3:"9.0";s:10:"update_url";s:28:"http://www.apple.com/safari/";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/safari.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/safari.png";s:15:"current_version";s:1:"5";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2613, 'hmbkp_schedule_1441997204', 'a:7:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:5:"email";a:1:{s:5:"email";s:0:"";}s:19:"schedule_start_time";i:1442008800;s:11:"max_backups";i:7;s:14:"duration_total";i:3;s:16:"backup_run_count";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2616, 'options_contact_map', 'a:3:{s:7:"address";s:56:"6925 Willow Street, NW Studio 223 Washington, D.C. 20012";s:3:"lat";s:10:"38.9736704";s:3:"lng";s:18:"-77.01422880000001";}', 'no') ; 
INSERT INTO `wp_options` VALUES (2617, '_options_contact_map', 'field_55ed4426dada3', 'no') ; 
INSERT INTO `wp_options` VALUES (2618, 'options_contact_street', '6925 Willow Street, NW', 'no') ; 
INSERT INTO `wp_options` VALUES (2619, '_options_contact_street', 'field_52eb3ffd2a2f5', 'no') ; 
INSERT INTO `wp_options` VALUES (2620, 'options_contact_suite', 'Studio 223', 'no') ; 
INSERT INTO `wp_options` VALUES (2621, '_options_contact_suite', 'field_55ed43dd6efb1', 'no') ; 
INSERT INTO `wp_options` VALUES (2622, 'options_contact_city', 'Washington', 'no') ; 
INSERT INTO `wp_options` VALUES (2623, '_options_contact_city', 'field_52eb40202a2f6', 'no') ; 
INSERT INTO `wp_options` VALUES (2624, 'options_contact_state', 'D.C.', 'no') ; 
INSERT INTO `wp_options` VALUES (2625, '_options_contact_state', 'field_52eb402a2a2f7', 'no') ; 
INSERT INTO `wp_options` VALUES (2626, 'options_contact_zipcode', '20012', 'no') ; 
INSERT INTO `wp_options` VALUES (2627, '_options_contact_zipcode', 'field_52eb406f2a2f8', 'no') ; 
INSERT INTO `wp_options` VALUES (2628, 'options_contact_phone', '(123) 456-7890', 'no') ; 
INSERT INTO `wp_options` VALUES (2629, '_options_contact_phone', 'field_52eb40812a2f9', 'no') ; 
INSERT INTO `wp_options` VALUES (2630, 'options_contact_email', 'contact@9zero7films.com', 'no') ; 
INSERT INTO `wp_options` VALUES (2631, '_options_contact_email', 'field_52eb40902a2fa', 'no') ; 
INSERT INTO `wp_options` VALUES (2632, 'options_contact_studio', '223', 'no') ; 
INSERT INTO `wp_options` VALUES (2633, '_options_contact_studio', 'field_55ed43dd6efb1', 'no') ; 
INSERT INTO `wp_options` VALUES (2634, 'options_social_instagram', 'http://www.instagram.com', 'no') ; 
INSERT INTO `wp_options` VALUES (2635, '_options_social_instagram', 'field_52d9044e331fa', 'no') ; 
INSERT INTO `wp_options` VALUES (2636, 'options_social_vimeo', 'http://www.vimeo.com', 'no') ; 
INSERT INTO `wp_options` VALUES (2637, '_options_social_vimeo', 'field_55f331bbb72b7', 'no') ; 
INSERT INTO `wp_options` VALUES (2638, 'options_social_youtube', 'http://www.youtube.com', 'no') ; 
INSERT INTO `wp_options` VALUES (2639, '_options_social_youtube', 'field_55f331c9b72b8', 'no') ; 
INSERT INTO `wp_options` VALUES (2640, 'options_newsletter_headline', 'Stay Up to Date', 'no') ; 
INSERT INTO `wp_options` VALUES (2641, '_options_newsletter_headline', 'field_55f334ae9bd30', 'no') ; 
INSERT INTO `wp_options` VALUES (2642, 'options_newsletter_description', 'Stay ahead of the curve with news, tips, tricks and updates in your inbox.', 'no') ; 
INSERT INTO `wp_options` VALUES (2643, '_options_newsletter_description', 'field_55f334ca9bd31', 'no') ; 
INSERT INTO `wp_options` VALUES (2644, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1442033451', 'yes') ; 
INSERT INTO `wp_options` VALUES (2645, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"5223";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"3269";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"3204";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"2734";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"2503";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"2001";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1906";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1836";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1787";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1769";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1738";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1728";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1621";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:4:"1419";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:4:"1357";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:4:"1299";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:4:"1207";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:4:"1165";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:4:"1150";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:4:"1021";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"975";}s:11:"woocommerce";a:3:{s:4:"name";s:11:"woocommerce";s:4:"slug";s:11:"woocommerce";s:5:"count";s:3:"942";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"932";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"896";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"865";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"853";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"806";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"791";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"767";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"743";}s:9:"ecommerce";a:3:{s:4:"name";s:9:"ecommerce";s:4:"slug";s:9:"ecommerce";s:5:"count";s:3:"738";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"736";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"695";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"687";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"682";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"669";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"649";}s:8:"security";a:3:{s:4:"name";s:8:"security";s:4:"slug";s:8:"security";s:5:"count";s:3:"645";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"640";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"639";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2648, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1442347889;s:8:"response";a:0:{}s:12:"translations";a:0:{}s:9:"no_update";a:9:{s:33:"admin-menu-editor/menu-editor.php";O:8:"stdClass":6:{s:2:"id";s:5:"11743";s:4:"slug";s:17:"admin-menu-editor";s:6:"plugin";s:33:"admin-menu-editor/menu-editor.php";s:11:"new_version";s:5:"1.4.5";s:3:"url";s:48:"https://wordpress.org/plugins/admin-menu-editor/";s:7:"package";s:66:"https://downloads.wordpress.org/plugin/admin-menu-editor.1.4.5.zip";}s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.1.3";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.1.3.zip";}s:35:"backupwordpress/backupwordpress.php";O:8:"stdClass":6:{s:2:"id";s:3:"885";s:4:"slug";s:15:"backupwordpress";s:6:"plugin";s:35:"backupwordpress/backupwordpress.php";s:11:"new_version";s:5:"3.2.7";s:3:"url";s:46:"https://wordpress.org/plugins/backupwordpress/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.3.2.7.zip";}s:36:"contact-form-7/wp-contact-form-7.php";O:8:"stdClass":6:{s:2:"id";s:3:"790";s:4:"slug";s:14:"contact-form-7";s:6:"plugin";s:36:"contact-form-7/wp-contact-form-7.php";s:11:"new_version";s:5:"4.2.2";s:3:"url";s:45:"https://wordpress.org/plugins/contact-form-7/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/contact-form-7.4.2.2.zip";}s:37:"custom-content-type-manager/index.php";O:8:"stdClass":7:{s:2:"id";s:5:"18003";s:4:"slug";s:27:"custom-content-type-manager";s:6:"plugin";s:37:"custom-content-type-manager/index.php";s:11:"new_version";s:7:"0.9.8.6";s:3:"url";s:58:"https://wordpress.org/plugins/custom-content-type-manager/";s:7:"package";s:78:"https://downloads.wordpress.org/plugin/custom-content-type-manager.0.9.8.6.zip";s:14:"upgrade_notice";s:61:"Fixed error renaming custom fields. All users should upgrade.";}s:45:"enable-media-replace/enable-media-replace.php";O:8:"stdClass":6:{s:2:"id";s:4:"8351";s:4:"slug";s:20:"enable-media-replace";s:6:"plugin";s:45:"enable-media-replace/enable-media-replace.php";s:11:"new_version";s:5:"3.0.3";s:3:"url";s:51:"https://wordpress.org/plugins/enable-media-replace/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/enable-media-replace.zip";}s:38:"post-duplicator/m4c-postduplicator.php";O:8:"stdClass":6:{s:2:"id";s:5:"31128";s:4:"slug";s:15:"post-duplicator";s:6:"plugin";s:38:"post-duplicator/m4c-postduplicator.php";s:11:"new_version";s:3:"2.8";s:3:"url";s:46:"https://wordpress.org/plugins/post-duplicator/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/post-duplicator.zip";}s:37:"post-types-order/post-types-order.php";O:8:"stdClass":6:{s:2:"id";s:5:"17292";s:4:"slug";s:16:"post-types-order";s:6:"plugin";s:37:"post-types-order/post-types-order.php";s:11:"new_version";s:7:"1.8.4.1";s:3:"url";s:47:"https://wordpress.org/plugins/post-types-order/";s:7:"package";s:59:"https://downloads.wordpress.org/plugin/post-types-order.zip";}s:47:"regenerate-thumbnails/regenerate-thumbnails.php";O:8:"stdClass":7:{s:2:"id";s:4:"4437";s:4:"slug";s:21:"regenerate-thumbnails";s:6:"plugin";s:47:"regenerate-thumbnails/regenerate-thumbnails.php";s:11:"new_version";s:5:"2.2.4";s:3:"url";s:52:"https://wordpress.org/plugins/regenerate-thumbnails/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/regenerate-thumbnails.zip";s:14:"upgrade_notice";s:124:"Better AJAX response error handling in the JavaScript. This should fix a long-standing bug in this plugin. Props Hew Sutton.";}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2649, 'mc4wp_lite_version', '2.3.10', 'yes') ; 
INSERT INTO `wp_options` VALUES (2650, 'mc4wp_lite', 'a:1:{s:7:"api_key";s:36:"3a548adbc2e977ec758ab69fcae40425-us2";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2657, '_transient_timeout_mc4wp_mailchimp_lists', '1442110211', 'no') ; 
INSERT INTO `wp_options` VALUES (2658, '_transient_mc4wp_mailchimp_lists', 'a:3:{s:10:"b367428ca9";O:8:"stdClass":5:{s:2:"id";s:10:"b367428ca9";s:4:"name";s:17:"9ZERO7 Films Test";s:16:"subscriber_count";i:1;s:10:"merge_vars";a:3:{i:0;O:8:"stdClass":4:{s:4:"name";s:13:"Email Address";s:10:"field_type";s:5:"email";s:3:"req";b:1;s:3:"tag";s:5:"EMAIL";}i:1;O:8:"stdClass":4:{s:4:"name";s:10:"First Name";s:10:"field_type";s:4:"text";s:3:"req";b:0;s:3:"tag";s:5:"FNAME";}i:2;O:8:"stdClass":4:{s:4:"name";s:9:"Last Name";s:10:"field_type";s:4:"text";s:3:"req";b:0;s:3:"tag";s:5:"LNAME";}}s:18:"interest_groupings";a:0:{}}s:10:"9e00420da0";O:8:"stdClass":5:{s:2:"id";s:10:"9e00420da0";s:4:"name";s:11:"New Project";s:16:"subscriber_count";i:1;s:10:"merge_vars";a:3:{i:0;O:8:"stdClass":4:{s:4:"name";s:13:"Email Address";s:10:"field_type";s:5:"email";s:3:"req";b:1;s:3:"tag";s:5:"EMAIL";}i:1;O:8:"stdClass":4:{s:4:"name";s:10:"First Name";s:10:"field_type";s:4:"text";s:3:"req";b:0;s:3:"tag";s:5:"FNAME";}i:2;O:8:"stdClass":4:{s:4:"name";s:9:"Last Name";s:10:"field_type";s:4:"text";s:3:"req";b:0;s:3:"tag";s:5:"LNAME";}}s:18:"interest_groupings";a:0:{}}s:10:"eb3bfa5417";O:8:"stdClass":5:{s:2:"id";s:10:"eb3bfa5417";s:4:"name";s:18:"Courtney R. Harris";s:16:"subscriber_count";i:63;s:10:"merge_vars";a:3:{i:0;O:8:"stdClass":4:{s:4:"name";s:13:"Email Address";s:10:"field_type";s:5:"email";s:3:"req";b:1;s:3:"tag";s:5:"EMAIL";}i:1;O:8:"stdClass":4:{s:4:"name";s:10:"First Name";s:10:"field_type";s:4:"text";s:3:"req";b:0;s:3:"tag";s:5:"FNAME";}i:2;O:8:"stdClass":4:{s:4:"name";s:9:"Last Name";s:10:"field_type";s:4:"text";s:3:"req";b:0;s:3:"tag";s:5:"LNAME";}}s:18:"interest_groupings";a:0:{}}}', 'no') ; 
INSERT INTO `wp_options` VALUES (2659, '_transient_timeout_mc4wp_mailchimp_lists_fallback', '1443233411', 'no') ; 
INSERT INTO `wp_options` VALUES (2660, '_transient_mc4wp_mailchimp_lists_fallback', 'a:3:{s:10:"b367428ca9";O:8:"stdClass":5:{s:2:"id";s:10:"b367428ca9";s:4:"name";s:17:"9ZERO7 Films Test";s:16:"subscriber_count";i:1;s:10:"merge_vars";a:3:{i:0;O:8:"stdClass":4:{s:4:"name";s:13:"Email Address";s:10:"field_type";s:5:"email";s:3:"req";b:1;s:3:"tag";s:5:"EMAIL";}i:1;O:8:"stdClass":4:{s:4:"name";s:10:"First Name";s:10:"field_type";s:4:"text";s:3:"req";b:0;s:3:"tag";s:5:"FNAME";}i:2;O:8:"stdClass":4:{s:4:"name";s:9:"Last Name";s:10:"field_type";s:4:"text";s:3:"req";b:0;s:3:"tag";s:5:"LNAME";}}s:18:"interest_groupings";a:0:{}}s:10:"9e00420da0";O:8:"stdClass":5:{s:2:"id";s:10:"9e00420da0";s:4:"name";s:11:"New Project";s:16:"subscriber_count";i:1;s:10:"merge_vars";a:3:{i:0;O:8:"stdClass":4:{s:4:"name";s:13:"Email Address";s:10:"field_type";s:5:"email";s:3:"req";b:1;s:3:"tag";s:5:"EMAIL";}i:1;O:8:"stdClass":4:{s:4:"name";s:10:"First Name";s:10:"field_type";s:4:"text";s:3:"req";b:0;s:3:"tag";s:5:"FNAME";}i:2;O:8:"stdClass":4:{s:4:"name";s:9:"Last Name";s:10:"field_type";s:4:"text";s:3:"req";b:0;s:3:"tag";s:5:"LNAME";}}s:18:"interest_groupings";a:0:{}}s:10:"eb3bfa5417";O:8:"stdClass":5:{s:2:"id";s:10:"eb3bfa5417";s:4:"name";s:18:"Courtney R. Harris";s:16:"subscriber_count";i:63;s:10:"merge_vars";a:3:{i:0;O:8:"stdClass":4:{s:4:"name";s:13:"Email Address";s:10:"field_type";s:5:"email";s:3:"req";b:1;s:3:"tag";s:5:"EMAIL";}i:1;O:8:"stdClass":4:{s:4:"name";s:10:"First Name";s:10:"field_type";s:4:"text";s:3:"req";b:0;s:3:"tag";s:5:"FNAME";}i:2;O:8:"stdClass":4:{s:4:"name";s:9:"Last Name";s:10:"field_type";s:4:"text";s:3:"req";b:0;s:3:"tag";s:5:"LNAME";}}s:18:"interest_groupings";a:0:{}}}', 'no') ; 
INSERT INTO `wp_options` VALUES (2661, '_transient_doing_cron', '1442347884.1731939315795898437500', 'yes') ; 
INSERT INTO `wp_options` VALUES (2662, '_transient_timeout_acf_pro_get_remote_info', '1442391036', 'no') ; 
INSERT INTO `wp_options` VALUES (2663, '_transient_acf_pro_get_remote_info', 'a:15:{s:4:"name";s:26:"Advanced Custom Fields Pro";s:4:"slug";s:26:"advanced-custom-fields-pro";s:8:"homepage";s:36:"http://www.advancedcustomfields.com/";s:7:"version";s:5:"5.3.0";s:6:"author";s:13:"elliot condon";s:10:"author_url";s:28:"http://www.elliotcondon.com/";s:12:"contributors";s:12:"elliotcondon";s:8:"requires";s:5:"3.6.0";s:6:"tested";s:3:"4.3";s:4:"tags";a:30:{i:0;s:5:"5.2.9";i:1;s:5:"5.2.8";i:2;s:5:"5.2.7";i:3;s:5:"5.2.6";i:4;s:5:"5.2.5";i:5;s:5:"5.2.4";i:6;s:5:"5.2.3";i:7;s:5:"5.2.2";i:8;s:5:"5.2.1";i:9;s:5:"5.2.0";i:10;s:5:"5.1.9";i:11;s:5:"5.1.8";i:12;s:5:"5.1.7";i:13;s:5:"5.1.6";i:14;s:5:"5.1.5";i:15;s:5:"5.1.4";i:16;s:5:"5.1.3";i:17;s:5:"5.1.2";i:18;s:5:"5.1.1";i:19;s:5:"5.1.0";i:20;s:5:"5.0.9";i:21;s:5:"5.0.8";i:22;s:5:"5.0.7";i:23;s:5:"5.0.6";i:24;s:5:"5.0.5";i:25;s:5:"5.0.4";i:26;s:5:"5.0.3";i:27;s:5:"5.0.2";i:28;s:5:"5.0.1";i:29;s:5:"5.0.0";}s:6:"tagged";s:151:"custom, field, custom field, advanced, simple fields, magic fields, more fields, repeater, matrix, post, type, text, textarea, file, image, edit, admin";s:11:"description";s:4328:"<p>Advanced Custom Fields is the perfect solution for any WordPress website which needs more flexible data like other Content Management Systems. </p>
<ul><li>Visually create your Fields</li><li>Select from multiple input types (text, textarea, wysiwyg, image, file, page link, post object, relationship, select, checkbox, radio buttons, date picker, true / false, repeater, flexible content, gallery and more to come!)</li><li>Assign your fields to multiple edit pages (via custom location rules)</li><li>Easily load data through a simple and friendly API</li><li>Uses the native WordPress custom post type for ease of use and fast processing</li><li>Uses the native WordPress metadata for ease of use and fast processing</li></ul>
<h4> Field Types </h4>
<ul><li>Text (type text, api returns text)</li><li>Text Area (type text, api returns text)</li><li>Number (type number, api returns integer)</li><li>Email (type email, api returns text)</li><li>Password (type password, api returns text)</li><li>WYSIWYG (a WordPress wysiwyg editor, api returns html)</li><li>Image (upload an image, api returns the url)</li><li>File (upload a file, api returns the url)</li><li>Select (drop down list of choices, api returns chosen item)</li><li>Checkbox (tickbox list of choices, api returns array of choices)</li><li>Radio Buttons ( radio button list of choices, api returns chosen item)</li><li>True / False (tick box with message, api returns true or false)</li><li>Page Link (select 1 or more page, post or custom post types, api returns the selected url)</li><li>Post Object (select 1 or more page, post or custom post types, api returns the selected post objects)</li><li>Relationship (search, select and order post objects with a tidy interface, api returns the selected post objects)</li><li>Taxonomy (select taxonomy terms with options to load, display and save, api returns the selected term objects)</li><li>User (select 1 or more WP users, api returns the selected user objects)</li><li>Google Maps (interactive map, api returns lat,lng,address data)</li><li>Date Picker (jquery date picker, options for format, api returns string)</li><li>Color Picker (WP color swatch picker)</li><li>Tab (Group fields into tabs)</li><li>Message (Render custom messages into the fields)</li><li>Repeater (ability to create repeatable blocks of fields!)</li><li>Flexible Content (ability to create flexible blocks of fields!)</li><li>Gallery (Add, edit and order multiple images in 1 simple field)</li><li>[Custom](<a href="http://www.advancedcustomfields.com/resources/tutorials/creating-a-new-field-type/)">www.advancedcustomfields.com/resources/tutorials/creating-a-new-field-type/)</a> (Create your own field type!)</li></ul>
<h4> Tested on </h4>
<ul><li>Mac Firefox 	:)</li><li>Mac Safari 	:)</li><li>Mac Chrome	:)</li><li>PC Safari 	:)</li><li>PC Chrome		:)</li><li>PC Firefox	:)</li><li>iPhone Safari :)</li><li>iPad Safari 	:)</li><li>PC ie7		:S</li></ul>
<h4> Website </h4>
<p><a href="http://www.advancedcustomfields.com/">www.advancedcustomfields.com/</a></p>
<h4> Documentation </h4>
<ul><li>[Getting Started](<a href="http://www.advancedcustomfields.com/resources/#getting-started)">www.advancedcustomfields.com/resources/#getting-started)</a></li><li>[Field Types](<a href="http://www.advancedcustomfields.com/resources/#field-types)">www.advancedcustomfields.com/resources/#field-types)</a></li><li>[Functions](<a href="http://www.advancedcustomfields.com/resources/#functions)">www.advancedcustomfields.com/resources/#functions)</a></li><li>[Actions](<a href="http://www.advancedcustomfields.com/resources/#actions)">www.advancedcustomfields.com/resources/#actions)</a></li><li>[Filters](<a href="http://www.advancedcustomfields.com/resources/#filters)">www.advancedcustomfields.com/resources/#filters)</a></li><li>[How to guides](<a href="http://www.advancedcustomfields.com/resources/#how-to)">www.advancedcustomfields.com/resources/#how-to)</a></li><li>[Tutorials](<a href="http://www.advancedcustomfields.com/resources/#tutorials)">www.advancedcustomfields.com/resources/#tutorials)</a></li></ul>
<h4> Bug Submission and Forum Support </h4>
<p><a href="http://support.advancedcustomfields.com/">support.advancedcustomfields.com/</a></p>
<h4> Please Vote and Enjoy </h4>
<p>Your votes really make a difference! Thanks.</p>
";s:12:"installation";s:467:"<ol><li>Upload <code>advanced-custom-fields</code> to the <code>/wp-content/plugins/</code> directory</li><li>Activate the plugin through the <code>Plugins</code> menu in WordPress</li><li>Click on the new menu item "Custom Fields" and create your first Custom Field Group!</li><li>Your custom field group will now appear on the page / post / template you specified in the field group\'s location rules!</li><li>Read the documentation to display your data: </li></ol>
";s:9:"changelog";s:7246:"<h4> 5.3.0 </h4>
<ul><li>WYSIWYG field: Fixed <code>Visual/Text</code> toggle bug with WP 4.3</li><li>Select field: Fixed Select2 bug hiding selected choices</li></ul>
<h4> 5.2.9 </h4>
<ul><li>Field group: Added new <code>status</code> setting to enable/disable</li><li>Field group: Added new <code>description</code> setting shown to developers when viewing the field group list</li><li>Field group: Moved <code>Show field keys</code> Screen Option within existing <code>Show on Screen</code> checkboxes</li><li>Tab field: Fixed missing min-height to left aligned tab wrapper</li><li>Relationship field: Added timeout to reduce AJAX requests whilst typing in search</li><li>Flexible Content field: Fixed minor JS bug where removing a layout would not update the order numbers</li><li>Core: Fixed bug validating uppercase file extensions</li><li>Core: Renamed menu items</li><li>Core: Replace sprite icons with font</li><li>Core: Added new setting <code>export_textdomain</code> to add __() to generated export code</li><li>Core: Fixed conflict with Post Type Order plugin causing issues when querying posts</li><li>Core: Fixed conflict with WPML causing issues when querying posts</li><li>Core: Added compatibility for WP 4.3</li><li>Core: Minor fixes and improvements</li><li>Language: Updated German translation - thanks to Ralf Koller</li><li>Language: Updated Italian translation - thanks to Davide Pantè</li></ul>
<h4> 5.2.8 </h4>
<ul><li>Image field: Added selection restrictions in media popup (width, height, size, type)</li><li>File field: Same as above</li><li>Gallery field: Same as above</li><li>Tab field: Added new <code>endpoint</code> setting - allows multiple tab groups</li><li>Tab field: Improved CSS/JS to allow individual tab groups to use different alignments (left/top)</li><li>Repeater field: Added logic to delete nested sub field values (grand children)</li><li>Options page: Added new <code>autoload</code> setting</li><li>Core: Added new filter <code>acf/prepare_field</code></li><li>Core: Added upload validation logic to ignore filetype case sensitivity</li><li>Core: Fixed upload issue when filesize restriction contained a decimal place</li><li>Core: Improved validation/save JS compatibility with 3rd party plugins</li><li>Core: Updated Select2 library to v3.5.2</li><li>Core: Fixed bug hiding Select2 choices when multiple found with the same label</li><li>Core: Minor fixes and improvements</li><li>Language: Updated Italian translation - thanks to Davide Pantè & Francesco Mazzola</li><li>Language: Updated German translation - thanks to Ralf Koller</li><li>Language: Updating Finnish translation - thanks to Sauli Rajala</li></ul>
<h4> 5.2.7 </h4>
<ul><li>Taxonomy field: Split setting <code>load_save_terms</code> into <code>load_terms</code> and <code>save_terms</code></li><li>Select field: Fixed bug causing values containing <code>,</code> to fail</li><li>Checkbox field: Fixed bug causing values containing <code>,</code> to fail</li><li>Checkbox field: Added new <code>toggle all</code> setting</li><li>User field: Added new filters <code>acf/fields/user/result</code> and <code>acf/fields/user/search_columns</code></li><li>Gallery field: Added logic to increase sidebar width when space is available</li><li>Options page: Added new <code>post_id</code> setting to customise where values are loaded and saved</li><li>API: Improved `get_field()` to better handle no value</li><li>API: Optimised asset loading when using the `acf_form()` function</li><li>API: Added new function `delete_sub_field()`</li><li>Core: Added new `acf/init` action when ACF has loaded all functionality</li><li>Core: Added compatibility with Select2 language translations</li><li>Core: Changed compatibility filter default to false</li><li>Core: Minor fixes and improvements</li><li>Language: Updated German translation - thanks to Thomas Meyer</li><li>Language: Updated French Translation - thanks to Maxime Bernard-Jacquet</li><li>Language: Updated Persian translation - thanks to Kamel</li></ul>
<h4> 5.2.6 </h4>
<ul><li>Core: Improved validation logic to display HTML5 validation messages</li><li>Core: Improved conditional logic performance for large field groups</li><li>Core: Removed updates menu item when not activated as a plugin (included within theme)</li><li>Core: Fixed various JS performance issues</li><li>Core: Minor fixes and improvements</li><li>Core: Added compatibility for saving widget in <code>accessibility mode</code></li><li>Language: Added Finnish translation - thanks to Sauli Rajala</li></ul>
<h4> 5.2.5 </h4>
<ul><li>Core: Fixed JS error preventing changes to large field groups</li><li>Language: Added Romanian translation - thanks to Eduard Ungureanu</li></ul>
<h4> 5.2.4 </h4>
<ul><li>WYSIWYG field: Fixed bug where new editor is not focused when adding media</li><li>Core: Added new <code>uploader</code> setting to `acf_form()` options for basic upload inputs</li><li>Core: Fixed Multisite loop when WordPress MU Domain Mapping plugin is active</li><li>Core: Improved CSS when editing taxonomy terms and users</li><li>Core: Fixed validation bugs when clicking save or preview </li><li>Core: Added compatibility with WPML translations when field group is not set as a translatable post type</li><li>Core: Many minor fixes and improvements</li></ul>
<h4> 5.2.3 </h4>
<ul><li>Taxonomy field: Added button and popup to create new terms</li><li>Taxonomy field: Added new <code>Create Terms</code> setting to prevent popup</li><li>Core: Added network database upgrade admin page and functionality</li><li>Core: Increased required WP version from 3.5 to 3.6</li><li>Core: Fixed Select2 dependancy conflict with WooCommerce</li><li>Core: Fixed WPML bug where field group translation information is lost</li><li>Core: Fixed conditional logic bug where showing a parent field would override sub field conditional logic</li><li>Core: Minor fixes and improvements</li><li>Language: Updated Persian translation - thanks to Kamel</li></ul>
<h4> 5.2.2 </h4>
<ul><li>Image field: Fixed UI bug when image has been removed via media library</li><li>Relationship field: Added new minimum selection setting</li><li>Select field: Fixed bug when searching for a numeric value</li><li>Tab field: Fixed conditional logic bug</li><li>Field group: Added compatibility for custom status in <code>Post Status</code> location rule</li><li>Core: Added new `show_updates` setting to prevent plugin updates</li><li>Core: Added compatibility for 3rd party update management websites</li><li>Core: Added spinner when saving taxonomy term, user and front end form</li><li>Core: Minor fixes and improvements</li><li>Language: Updated Slovak translation - thanks to Ján Fajčák</li></ul>
<p> </p>
<h4> 5.2.1 </h4>
<ul><li>Core: Fixed bug where <code>Taxonomy</code> field group location rule would change to <code>Post Taxonomy</code></li><li>Core: Fixed bug where field group postboxes would disappear from post edit screen</li><li>Core: Fixed bug where <code>Uploaded to post</code> setting would not work on front end image/file/gallery fields</li><li>Core: Fixed bug where multiple conditional logic tabs would not display correctly</li><li>Language: Updated Japanese translation - thanks to Shogo Kato</li></ul>
";s:14:"upgrade_notice";s:550:"<h4> 5.2.7 </h4>
<ul><li>Field class names have changed slightly in v5.2.7 from `field_type-{$type}` to `acf-field-{$type}`. This change was introduced to better optimise JS performance. The previous class names can be added back in with the following filter: <a href="http://www.advancedcustomfields.com/resources/acfcompatibility/">www.advancedcustomfields.com/resources/acfcompatibility/</a></li></ul>
<h4> 3.0.0 </h4>
<ul><li>Editor is broken in WordPress 3.3</li></ul>
<h4> 2.1.4 </h4>
<ul><li>Adds post_id column back into acf_values</li></ul>
";}', 'no') ; 
INSERT INTO `wp_options` VALUES (2664, '_site_transient_timeout_theme_roots', '1442349637', 'yes') ; 
INSERT INTO `wp_options` VALUES (2665, '_site_transient_theme_roots', 'a:2:{s:11:"9zero7films";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2666, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1442391041', 'no') ; 
INSERT INTO `wp_options` VALUES (2667, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:49:"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:26:"https://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Sep 2015 15:25:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:39:"http://wordpress.org/?v=4.4-alpha-34213";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress 4.3.1 Security and Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2015/09/wordpress-4-3-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/news/2015/09/wordpress-4-3-1/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Sep 2015 15:22:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3914";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:439:"WordPress 4.3.1 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. This release addresses three issues, including two cross-site scripting vulnerabilities and a potential privilege escalation. WordPress versions 4.3 and earlier are vulnerable to a cross-site scripting vulnerability when processing shortcode tags (CVE-2015-5714). Reported by [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Samuel Sidler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4022:"<div class="storycontent">
<p>WordPress 4.3.1 is now available. This is a<strong> security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>This release addresses three issues, including two cross-site scripting vulnerabilities and a potential privilege escalation.</p>
<ul>
<li>WordPress versions 4.3 and earlier are vulnerable to a cross-site scripting vulnerability when processing shortcode tags (CVE-2015-5714). Reported by Shahar Tal and Netanel Rubin of <a href="http://checkpoint.com/">Check Point</a>.</li>
<li>A separate cross-site scripting vulnerability was found in the user list table. Reported by Ben Bidner of the WordPress security team.</li>
<li>Finally, in certain cases, users without proper permissions could publish private posts and make them sticky (CVE-2015-5715). Reported by Shahar Tal and Netanel Rubin of <a href="http://checkpoint.com/">Check Point</a>.</li>
</ul>
<p>Our thanks to those who have practiced <a href="https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/">responsible disclosure</a> of security issues.</p>
<p>WordPress 4.3.1 also fixes twenty-six bugs. For more information, see the <a href="https://codex.wordpress.org/Version_4.3.1">release notes</a> or consult the <a href="https://core.trac.wordpress.org/log/branches/4.3/?rev=34199&amp;stop_rev=33647">list of changes</a>.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 4.3.1</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.3.1.</p>
</div>
<p>Thanks to everyone who contributed to 4.3.1:</p>
<p><a href="https://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone Gorges</a>, <a href="https://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="https://profiles.wordpress.org/chriscct7">chriscct7</a>, <a href="https://profiles.wordpress.org/extendwings">Daisuke Takahashi</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/DrewAPicture">Drew Jaynes</a>, <a href="https://profiles.wordpress.org/dustinbolton">dustinbolton</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/hauvong">hauvong</a>, <a href="https://profiles.wordpress.org/macmanx">James Huff</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/jobst">jobst</a>, <a href="https://profiles.wordpress.org/tyxla">Marin Atanasov</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/nikeo">nikeo</a>, <a href="https://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="https://profiles.wordpress.org/swissspidy">Pascal Birchler</a>, <a href="https://profiles.wordpress.org/figureone">Paul Ryan</a>, <a href="https://profiles.wordpress.org/peterwilsoncc">Peter Wilson</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/otto42">Samuel Wood</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/SergeyBiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/tmatsuur">tmatsuur</a>, <a href="https://profiles.wordpress.org/liljimmi">Tracy Levesque</a>, <a href="https://profiles.wordpress.org/umeshnevase">Umesh Nevase</a>, <a href="https://profiles.wordpress.org/vortfu">vortfu</a>, <a href="https://profiles.wordpress.org/welcher">welcher</a>, <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/09/wordpress-4-3-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"WordPress 4.3 “Billie”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"https://wordpress.org/news/2015/08/billie/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:50:"https://wordpress.org/news/2015/08/billie/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Aug 2015 19:12:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:3:"4.3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3845";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:352:"Version 4.3 of WordPress, named &#8220;Billie&#8221; in honor of jazz singer Billie Holiday, is available for download or update in your WordPress dashboard. New features in 4.3 make it even easier to format your content and customize your site. Menus in the Customizer Create your menu, update it, and assign it, all while live-previewing in [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:21776:"<p style="margin: 0;height: 0"><img src="https://wordpress.org/news/files/2015/08/WordPress-4-3-billie-1024x574.png" alt="WordPress 4.3 - &quot;Billie&quot;" width="692" height="388" class="alignnone size-large wp-image-3896" style="height:0px;width: 0px;margin: 0" /></p>
<p>Version 4.3 of WordPress, named &#8220;Billie&#8221; in honor of jazz singer <a href="https://en.wikipedia.org/wiki/Billie_Holiday">Billie Holiday</a>, is available for <a href="https://wordpress.org/download/">download</a> or update in your WordPress dashboard. New features in 4.3 make it even easier to format your content and customize your site.</p>
<p><iframe width=\'692\' height=\'389\' src=\'https://videopress.com/embed/T54Iy7Tw?hd=1\' frameborder=\'0\' allowfullscreen></iframe><script src=\'https://v0.wordpress.com/js/next/videopress-iframe.js?m=1435166243\'></script></p>
<hr />
<h2>Menus in the Customizer</h2>
<div><img src="//s.w.org/images/core/4.3/menu-customizer.png" alt="" /></div>
<p>Create your menu, update it, and assign it, all while live-previewing in the customizer. The streamlined customizer design provides a mobile-friendly and accessible interface. With every release, it becomes easier and faster to make your site just the way you want it.</p>
<hr />
<h2>Formatting Shortcuts</h2>
<div style="margin-bottom: 0"><div style="width: 640px; " class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-3845-1" width="640" height="360" loop="1" autoplay="1" preload="metadata" controls="controls"><source type="video/mp4" src="//s.w.org/images/core/4.3/formatting.mp4?_=1" /><source type="video/webm" src="//s.w.org/images/core/4.3/formatting.webm?_=1" /><source type="video/ogg" src="//s.w.org/images/core/4.3/formatting.ogv?_=1" /><a href="//s.w.org/images/core/4.3/formatting.mp4">//s.w.org/images/core/4.3/formatting.mp4</a></video></div></div>
<p>Your writing flow just got faster with new formatting shortcuts in WordPress 4.3. Use asterisks to create lists and number signs to make a heading. No more breaking your flow; your text looks great with a <code>*</code> and a <code>#</code>.</p>
<hr />
<h2>Site Icons</h2>
<p><img src="//s.w.org/images/core/4.3/site-icon-customizer.png" alt="" /><br />
&nbsp;<br />
Site icons represent your site in browser tabs, bookmark menus, and on the home screen of mobile devices. Add your unique site icon in the customizer; it will even stay in place when you switch themes. Make your whole site reflect your brand.</p>
<hr />
<h2>Better Passwords</h2>
<p><img src="//s.w.org/images/core/4.3/better-passwords.png" alt="" /><br />
&nbsp;<br />
Keep your site more secure with WordPress’ improved approach to passwords. Instead of receiving passwords via email, you’ll get a password reset link. When you add new users to your site or edit a user profile, WordPress will automatically generate a secure password.</p>
<hr />
<h2>Other improvements</h2>
<ul>
<li><strong>A smoother admin experience</strong> &#8211; Refinements to the list view across the admin make your WordPress more accessible and easier to work with on any device.</li>
<li><strong>Comments turned off on pages</strong> &#8211; All new pages that you create will have comments turned off. Keep discussions to your blog, right where they’re supposed to happen.</li>
<li><strong>Customize your site quickly</strong> &#8211; Wherever you are on the front-end, you can click the customize link in the toolbar to swiftly make changes to your site.</li>
</ul>
<hr />
<h2>The Team</h2>
<p><a class="alignleft" href="https://profiles.wordpress.org/obenland"><img src="https://www.gravatar.com/avatar/2370ea5912750f4cb0f3c51ae1cbca55?d=mm&amp;s=180&amp;r=G" alt="Konstantin Obenland" width="80" height="80" /></a>This release was led by <a href="http://konstantin.obenland.it/">Konstantin Obenland</a>, with the help of these fine individuals. There are 246 contributors with props in this release. Pull up some Billie Holiday on your music service of choice, and check out some of their profiles:</p>
<a href="https://profiles.wordpress.org/mercime">@mercime</a>, <a href="https://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/adamkheckler">Adam Heckler</a>, <a href="https://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="https://profiles.wordpress.org/akibjorklund">Aki Bjorklund</a>, <a href="https://profiles.wordpress.org/akirk">Alex Kirk</a>, <a href="https://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="https://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="https://profiles.wordpress.org/deconf">Alin Marcu</a>, <a href="https://profiles.wordpress.org/andfinally">andfinally</a>, <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/andg">Andrea Gandino</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/afragen">Andy Fragen</a>, <a href="https://profiles.wordpress.org/ankit-k-gupta">Ankit K Gupta</a>, <a href="https://profiles.wordpress.org/antpb">Anthony Burchell</a>, <a href="https://profiles.wordpress.org/anubisthejackle">anubisthejackle</a>, <a href="https://profiles.wordpress.org/aramzs">Aram Zucker-Scharff</a>, <a href="https://profiles.wordpress.org/arjunskumar">Arjun S Kumar</a>, <a href="https://profiles.wordpress.org/avnarun">avnarun</a>, <a href="https://profiles.wordpress.org/brad2dabone">Bad Feather</a>, <a href="https://profiles.wordpress.org/bcole808">Ben Cole</a>, <a href="https://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="https://profiles.wordpress.org/binarykitten">BinaryKitten</a>, <a href="https://profiles.wordpress.org/birgire">Birgir Erlendsson (birgire)</a>, <a href="https://profiles.wordpress.org/bjornjohansen">Bjorn Johansen</a>, <a href="https://profiles.wordpress.org/bolo1988">bolo1988</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone B. Gorges</a>, <a href="https://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="https://profiles.wordpress.org/bramd">Bram Duvigneau</a>, <a href="https://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="https://profiles.wordpress.org/krogsgard">Brian Krogsgard</a>, <a href="https://profiles.wordpress.org/brianlayman">Brian Layman</a>, <a href="https://profiles.wordpress.org/icaleb">Caleb Burks</a>, <a href="https://profiles.wordpress.org/calevans">CalEvans</a>, <a href="https://profiles.wordpress.org/chasewiseman">Chase Wiseman</a>, <a href="https://profiles.wordpress.org/chipbennett">Chip Bennett</a>, <a href="https://profiles.wordpress.org/chouby">Chouby</a>, <a href="https://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="https://profiles.wordpress.org/chriscct7">chriscct7</a>, <a href="https://profiles.wordpress.org/posykrat">Clement Biron</a>, <a href="https://profiles.wordpress.org/craig-ralston">Craig Ralston</a>, <a href="https://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="https://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="https://profiles.wordpress.org/mte90">Daniele Mte90 Scasciafratte</a>, <a href="https://profiles.wordpress.org/daniluk4000">daniluk4000</a>, <a href="https://profiles.wordpress.org/dmchale">Dave McHale</a>, <a href="https://profiles.wordpress.org/daveal">DaveAl</a>, <a href="https://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="https://profiles.wordpress.org/dlh">David Herrera</a>, <a href="https://profiles.wordpress.org/daxelrod">daxelrod</a>, <a href="https://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="https://profiles.wordpress.org/realloc">Dennis Ploetner</a>, <a href="https://profiles.wordpress.org/valendesigns">Derek Herman</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/dipeshkakadiya">dipesh.kakadiya</a>, <a href="https://profiles.wordpress.org/dmsnell">dmsnell</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="https://profiles.wordpress.org/kucrut">Dzikri Aziz</a>, <a href="https://profiles.wordpress.org/eclev91">eclev91</a>, <a href="https://profiles.wordpress.org/eligijus">eligijus</a>, <a href="https://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="https://profiles.wordpress.org/iseulde">Ella Iseulde Van Dorpe</a>, <a href="https://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="https://profiles.wordpress.org/ebinnion">Eric Binnion</a>, <a href="https://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="https://profiles.wordpress.org/fab1en">Fabien Quatravaux</a>, <a href="https://profiles.wordpress.org/flixos90">Felix Arntz</a>, <a href="https://profiles.wordpress.org/francoeurdavid">francoeurdavid</a>, <a href="https://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="https://profiles.wordpress.org/gabrielperezs">gabrielperezs</a>, <a href="https://profiles.wordpress.org/voldemortensen">Garth Mortensen</a>, <a href="https://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="https://profiles.wordpress.org/glennm">glennm</a>, <a href="https://profiles.wordpress.org/gtuk">gtuk</a>, <a href="https://profiles.wordpress.org/hailin">hailin</a>, <a href="https://profiles.wordpress.org/hauvong">hauvong</a>, <a href="https://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="https://profiles.wordpress.org/henrikakselsen">henrikakselsen</a>, <a href="https://profiles.wordpress.org/hnle">Hinaloe</a>, <a href="https://profiles.wordpress.org/hrishiv90">Hrishikesh Vaipurkar</a>, <a href="https://profiles.wordpress.org/hugobaeta">Hugo Baeta</a>, <a href="https://profiles.wordpress.org/polevaultweb">Iain Poulson</a>, <a href="https://profiles.wordpress.org/imath">imath</a>, <a href="https://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="https://profiles.wordpress.org/isaacchapman">isaacchapman</a>, <a href="https://profiles.wordpress.org/izem">izem</a>, <a href="https://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="https://profiles.wordpress.org/jacklenox">Jack Lenox</a>, <a href="https://profiles.wordpress.org/jadpm">jadpm</a>, <a href="https://profiles.wordpress.org/jamesgol">jamesgol</a>, <a href="https://profiles.wordpress.org/jancbeck">jancbeck</a>, <a href="https://profiles.wordpress.org/jfarthing84">Jeff Farthing</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/jpry">Jeremy Pry</a>, <a href="https://profiles.wordpress.org/jmichaelward">Jeremy Ward</a>, <a href="https://profiles.wordpress.org/jesin">Jesin A</a>, <a href="https://profiles.wordpress.org/jipmoors">jipmoors</a>, <a href="https://profiles.wordpress.org/eltobiano">jjberry</a>, <a href="https://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="https://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="https://profiles.wordpress.org/joemcgill">Joe McGill</a>, <a href="https://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="https://profiles.wordpress.org/picard102">John Leschinski</a>, <a href="https://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="https://profiles.wordpress.org/maxxsnake">Josh Davis</a>, <a href="https://profiles.wordpress.org/jpyper">Jpyper</a>, <a href="https://profiles.wordpress.org/jrf">jrf</a>, <a href="https://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="https://profiles.wordpress.org/jtsternberg">Justin Sternberg</a>, <a href="https://profiles.wordpress.org/ungestaltbar">Kai</a>, <a href="https://profiles.wordpress.org/karinchristen">karinchristen</a>, <a href="https://profiles.wordpress.org/karpstrucking">karpstrucking</a>, <a href="https://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="https://profiles.wordpress.org/kevkoeh">Kevin Koehler</a>, <a href="https://profiles.wordpress.org/kitchin">kitchin</a>, <a href="https://profiles.wordpress.org/ixkaito">Kite</a>, <a href="https://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="https://profiles.wordpress.org/leogopal">Leo Gopal</a>, <a href="https://profiles.wordpress.org/loushou">loushou</a>, <a href="https://profiles.wordpress.org/lumaraf">Lumaraf</a>, <a href="https://profiles.wordpress.org/tyxla">Marin Atanasov</a>, <a href="https://profiles.wordpress.org/nofearinc">Mario Peshev</a>, <a href="https://profiles.wordpress.org/clorith">Marius (Clorith)</a>, <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="https://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="https://profiles.wordpress.org/marsjaninzmarsa">marsjaninzmarsa</a>, <a href="https://profiles.wordpress.org/martinsachse">martinsachse</a>, <a href="https://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="https://profiles.wordpress.org/veraxus">Matt van Andel</a>, <a href="https://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="https://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="https://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="https://profiles.wordpress.org/nikonratm">Michael</a>, <a href="https://profiles.wordpress.org/mdawaffe">Michael Adams (mdawaffe)</a>, <a href="https://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="https://profiles.wordpress.org/michaelryanmcneill">michaelryanmcneill</a>, <a href="https://profiles.wordpress.org/mcguive7">Mickey Kay</a>, <a href="https://profiles.wordpress.org/mihai">mihai</a>, <a href="https://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="https://profiles.wordpress.org/mnelson4">Mike Nelson</a>, <a href="https://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="https://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="https://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="https://profiles.wordpress.org/mrutz">mrutz</a>, <a href="https://profiles.wordpress.org/nabil_kadimi">nabil_kadimi</a>, <a href="https://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="https://profiles.wordpress.org/nazmulhossainnihal">Nazmul Hossain Nihal</a>, <a href="https://profiles.wordpress.org/nicholas_io">nicholas_io</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/nickmomrik">Nick Momrik</a>, <a href="https://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="https://profiles.wordpress.org/rabmalin">Nilambar Sharma</a>, <a href="https://profiles.wordpress.org/onnimonni">Onni Hakala</a>, <a href="https://profiles.wordpress.org/ozh">Ozh</a>, <a href="https://profiles.wordpress.org/pareshradadiya-1">Paresh Radadiya</a>, <a href="https://profiles.wordpress.org/swissspidy">Pascal Birchler</a>, <a href="https://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="https://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/gungeekatx">Pete Nelson</a>, <a href="https://profiles.wordpress.org/peterwilsoncc">Peter Wilson</a>, <a href="https://profiles.wordpress.org/peterrknight">PeterRKnight</a>, <a href="https://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="https://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="https://profiles.wordpress.org/pragunbhutani">pragunbhutani</a>, <a href="https://profiles.wordpress.org/rachelbaker">Rachel Baker</a>, <a href="https://profiles.wordpress.org/ramiy">Rami Yushuvaev</a>, <a href="https://profiles.wordpress.org/rarylson">rarylson</a>, <a href="https://profiles.wordpress.org/lamosty">Rastislav Lamos</a>, <a href="https://profiles.wordpress.org/rauchg">rauchg</a>, <a href="https://profiles.wordpress.org/ravinderk">Ravinder Kumar</a>, <a href="https://profiles.wordpress.org/rclations">RC Lations</a>, <a href="https://profiles.wordpress.org/greuben">Reuben Gunday</a>, <a href="https://profiles.wordpress.org/rianrietveld">Rian Rietveld</a>, <a href="https://profiles.wordpress.org/ritteshpatel">Ritesh Patel</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="https://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="https://profiles.wordpress.org/rommelxcastro">Rommel Castro</a>, <a href="https://profiles.wordpress.org/magicroundabout">Ross Wintle</a>, <a href="https://profiles.wordpress.org/rhurling">Rouven Hurling</a>, <a href="https://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="https://profiles.wordpress.org/rmarks">Ryan Marks</a>, <a href="https://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="https://profiles.wordpress.org/ohryan">Ryan Neudorf</a>, <a href="https://profiles.wordpress.org/sagarjadhav">Sagar Jadhav</a>, <a href="https://profiles.wordpress.org/salcode">Sal Ferrarello</a>, <a href="https://profiles.wordpress.org/solarissmoke">Samir Shah</a>, <a href="https://profiles.wordpress.org/santagada">santagada</a>, <a href="https://profiles.wordpress.org/sc0ttkclark">Scott Kingsley Clark</a>, <a href="https://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/scribu">scribu</a>, <a href="https://profiles.wordpress.org/scruffian">scruffian</a>, <a href="https://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="https://profiles.wordpress.org/sebastiantiede">Sebastian</a>, <a href="https://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/shooper">Shawn Hooper</a>, <a href="https://profiles.wordpress.org/designsimply">Sheri Bigelow</a>, <a href="https://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="https://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="https://profiles.wordpress.org/metodiew">Stanko Metodiev</a>, <a href="https://profiles.wordpress.org/stephdau">Stephane Daury (stephdau)</a>, <a href="https://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="https://profiles.wordpress.org/stevegrunwell">Steve Grunwell</a>, <a href="https://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="https://profiles.wordpress.org/stuartshields">stuartshields</a>, <a href="https://profiles.wordpress.org/sudar">Sudar</a>, <a href="https://profiles.wordpress.org/sunnyratilal">Sunny Ratilal</a>, <a href="https://profiles.wordpress.org/taka2">taka2</a>, <a href="https://profiles.wordpress.org/tharsheblows">tharsheblows</a>, <a href="https://profiles.wordpress.org/thorbrink">Thor Brink</a>, <a href="https://profiles.wordpress.org/creativeinfusion">Tim Smith</a>, <a href="https://profiles.wordpress.org/tlexcellent">tlexcellent</a>, <a href="https://profiles.wordpress.org/tmatsuur">tmatsuur</a>, <a href="https://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="https://profiles.wordpress.org/tomasm">Tomas Mackevicius</a>, <a href="https://profiles.wordpress.org/tomharrigan">TomHarrigan</a>, <a href="https://profiles.wordpress.org/toro_unit">Toro_Unit (Hiroshi Urabe)</a>, <a href="https://profiles.wordpress.org/toru">Toru Miki</a>, <a href="https://profiles.wordpress.org/liljimmi">Tracy (LilJimmi) Levesque</a>, <a href="https://profiles.wordpress.org/tryon">Tryon Eggleston</a>, <a href="https://profiles.wordpress.org/tywayne">Ty Carlson</a>, <a href="https://profiles.wordpress.org/desaiuditd">Udit Desai</a>, <a href="https://profiles.wordpress.org/vivekbhusal">vivekbhusal</a>, <a href="https://profiles.wordpress.org/welcher">welcher</a>, <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="https://profiles.wordpress.org/willnorris">Will Norris</a>, <a href="https://profiles.wordpress.org/willgladstone">willgladstone</a>, <a href="https://profiles.wordpress.org/earnjam">William Earnhardt</a>, <a href="https://profiles.wordpress.org/willstedt">willstedt</a>, <a href="https://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="https://profiles.wordpress.org/ysalame">Yuri Salame</a>, <a href="https://profiles.wordpress.org/oxymoron">Zach Wills</a>, <a href="https://profiles.wordpress.org/katzwebdesign">Zack Katz</a>, and <a href="https://profiles.wordpress.org/tollmanz">Zack Tollman</a>.
<p>&nbsp;</p>
<p>Special thanks go to <a href="http://siobhanmckeown.com/">Siobhan McKeown</a> for producing the release video, <a href="http://hugobaeta.com/">Hugo Baeta</a> for the design, and <a href="http://jacklenox.com/">Jack Lenox</a> for the voice-over.</p>
<p>Finally, thanks to all of the contributors who provided subtitles for the release video, which at last count had been translated into 30 languages!</p>
<p>If you want to follow along or help out, check out <a href="https://make.wordpress.org/">Make WordPress</a> and our <a href="https://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.4!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:47:"https://wordpress.org/news/2015/08/billie/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress 4.2.4 Security and Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"https://wordpress.org/news/2015/08/wordpress-4-2-4-security-and-maintenance-release/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:92:"https://wordpress.org/news/2015/08/wordpress-4-2-4-security-and-maintenance-release/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 04 Aug 2015 12:10:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"4.2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3827";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:397:"WordPress 4.2.4 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. This release addresses six issues, including three cross-site scripting vulnerabilities and a potential SQL injection that could be used to compromise a site, which were discovered by Marc-Alexandre Montpas of Sucuri, Helen Hou-Sandí [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Samuel Sidler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2011:"<p>WordPress 4.2.4 is now available. This is a<strong> security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>This release addresses six issues, including three cross-site scripting vulnerabilities and a potential SQL injection that could be used to compromise a site, which were discovered by <a href="https://sucuri.net/">Marc-Alexandre Montpas</a> of Sucuri, <a href="http://helenhousandi.com/">Helen Hou-Sandí</a> of the WordPress security team, <a href="http://www.checkpoint.com/">Netanel Rubin</a> of Check Point, and <a href="https://hackerone.com/reactors08">Ivan Grigorov</a>. It also includes a fix for a potential timing side-channel attack, discovered by <a href="http://www.scrutinizer-ci.com/">Johannes Schmitt</a> of Scrutinizer, and prevents an attacker from locking a post from being edited, discovered by <a href="https://www.linkedin.com/in/symbiansymoh">Mohamed A. Baset</a>.</p>
<p>Our thanks to those who have practiced <a href="https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/">responsible disclosure</a> of security issues.</p>
<p>WordPress 4.2.4 also fixes four bugs. For more information, see the <a href="https://codex.wordpress.org/Version_4.2.4">release notes</a> or consult the <a href="https://core.trac.wordpress.org/log/branches/4.2?rev=33573&amp;stop_rev=33396">list of changes</a>.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 4.2.4</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.2.4.</p>
<p><em>Already testing WordPress 4.3? The second release candidate is now available (<a href="https://wordpress.org/wordpress-4.3-RC2.zip">zip</a>) and it contains these fixes. For more on 4.3, see <a href="https://wordpress.org/news/2015/07/wordpress-4-3-release-candidate/">the RC 1 announcement post</a>.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:89:"https://wordpress.org/news/2015/08/wordpress-4-2-4-security-and-maintenance-release/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 4.3 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"https://wordpress.org/news/2015/07/wordpress-4-3-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"https://wordpress.org/news/2015/07/wordpress-4-3-release-candidate/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 29 Jul 2015 23:50:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"4.3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3817";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:340:"The release candidate for WordPress 4.3 is now available. We&#8217;ve made more than 100 changes since releasing Beta 4 a week ago. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.3 on Tuesday, August 18, but we [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Konstantin Obenland";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2256:"<p>The release candidate for WordPress 4.3 is now available.</p>
<p>We&#8217;ve made more than <a href="https://core.trac.wordpress.org/log/trunk?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33512&amp;stop_rev=33372&amp;limit=120">100 changes</a> since releasing Beta 4 a week ago. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.3 on <strong>Tuesday, August 18</strong>, but we need your help to get there.</p>
<p>If you haven’t tested 4.3 yet, now is the time!</p>
<p><strong>Think you&#8217;ve found a bug?</strong> Please post to the <a href="https://wordpress.org/support/forum/alphabeta/">Alpha/Beta support forum</a>. If any known issues come up, you&#8217;ll be able to <a href="https://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>To test WordPress 4.3 RC1, you can use the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin or you can <a href="https://wordpress.org/wordpress-4.3-RC1.zip">download the release candidate here</a> (zip).</p>
<p>For more information about what’s new in version 4.3, check out the <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/">Beta 1</a>, <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/">Beta 2</a>, <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/">Beta 3</a>, and <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-4/">Beta 4</a> blog posts.</p>
<p><strong>Developers</strong>, please test your plugins and themes against WordPress 4.3 and update your plugin&#8217;s <em>Tested up to</em> version in the readme to 4.3 before next week. If you find compatibility problems, we never want to break things, so please be sure to post to the support forums so we can figure those out before the final release.</p>
<p>Be sure to <a href="https://make.wordpress.org/core/">follow along the core development blog</a>, where we&#8217;ll continue to post <a href="https://make.wordpress.org/core/tag/dev-notes+4-3/">notes for developers</a> for 4.3.</p>
<p><em>Drei Monate Arbeit</em><br />
<em>Endlich das Ziel vor Augen</em><br />
<em>Bald hab ich Urlaub!</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:72:"https://wordpress.org/news/2015/07/wordpress-4-3-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress 4.2.3 Security and Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2015/07/wordpress-4-2-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/news/2015/07/wordpress-4-2-3/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jul 2015 11:21:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"4.2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3807";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:380:"WordPress 4.2.3 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. WordPress versions 4.2.2 and earlier are affected by a cross-site scripting vulnerability, which could allow users with the Contributor or Author role to compromise a site. This was initially reported by Jon Cave and [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Gary Pendergast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2708:"<p>WordPress 4.2.3 is now available. This is a<strong> security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>WordPress versions 4.2.2 and earlier are affected by a cross-site scripting vulnerability, which could allow users with the Contributor or Author role to compromise a site. This was initially reported by <a href="https://profiles.wordpress.org/duck_">Jon Cave</a> and fixed by <a href="http://www.miqrogroove.com/">Robert Chapin</a>, both of the WordPress security team, and later reported by <a href="http://klikki.fi/">Jouko Pynnönen</a>.</p>
<p>We also fixed an issue where it was possible for a user with Subscriber permissions to create a draft through Quick Draft. Reported by Netanel Rubin from <a href="https://www.checkpoint.com/">Check Point Software Technologies</a>.</p>
<p>Our thanks to those who have practiced <a href="https://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/">responsible disclosure</a> of security issues.</p>
<p>WordPress 4.2.3 also contains fixes for 20 bugs from 4.2. For more information, see the <a href="https://codex.wordpress.org/Version_4.2.3">release notes</a> or consult the <a href="https://core.trac.wordpress.org/log/branches/4.2?rev=33382&amp;stop_rev=32430">list of changes</a>.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 4.2.3</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.2.3.</p>
<p>Thanks to everyone who contributed to 4.2.3:</p>
<p><a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone Gorges</a>, <a href="https://profiles.wordpress.org/chriscct7">Chris Christoff</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/iseulde">Ella Iseulde Van Dorpe</a>, <a href="https://profiles.wordpress.org/gabrielperezs">Gabriel Pérez</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/mdawaffe">Mike Adams</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="https://profiles.wordpress.org/magicroundabout">Ross Wintle</a>, and <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/07/wordpress-4-2-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.3 Beta 4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-4/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 22 Jul 2015 21:55:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"4.3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3796";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:337:"WordPress 4.3 Beta 4 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Konstantin Obenland";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2212:"<p>WordPress 4.3 Beta 4 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="https://wordpress.org/wordpress-4.3-beta4.zip">download the beta here</a> (zip).</p>
<p>For more information about what’s new in version 4.3, check out the <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/">Beta 1</a>, <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/">Beta 2</a>, and <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/">Beta 3</a> blog posts. Some of the changes in Beta 4 include:</p>
<ul>
<li><span class="s1">Fixed several bugs and broken flows in the </span><span class="s1"><strong>publish box </strong></span><span class="s1">in the edit screen.</span></li>
<li>Addressed a number of edge cases for word count in the <strong>editor</strong>.</li>
<li><span class="s1"><strong>Site icons</strong> </span><span class="s1">can now be previewed within the customizer. The feature has been removed from general settings.</span></li>
<li><strong>Various bug fixes</strong>. We&#8217;ve made <a href="https://core.trac.wordpress.org/log/trunk?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33369&amp;stop_rev=33289">more than 60 changes</a> in the last week.</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href="https://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.3">everything we’ve fixed</a>.</p>
<p><em>Few Tickets Remain</em><br />
<em>Edge Cases Disappearing</em><br />
<em>You Must Test Today</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.3 Beta 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 15 Jul 2015 21:49:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"4.3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3787";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:337:"WordPress 4.3 Beta 3 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Konstantin Obenland";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2529:"<p>WordPress 4.3 Beta 3 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="https://wordpress.org/wordpress-4.3-beta3.zip">download the beta here</a> (zip).</p>
<p>For more information about what’s new in version 4.3, check out the <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/">Beta 1</a> and <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/">Beta 2</a> blog posts. Some of the changes in Beta 3 include:</p>
<ul>
<li>Performance improvements for <strong>Menus in the Customizer</strong>, as well as bug fixes and visual enhancements.</li>
<li>Added <strong>Site Icon</strong> to the Customizer. The feature is now complete and requires lots of testing. Please help us ensure the site icon feature works well in both Settings and the Customizer.</li>
<li>The improvements to <strong>Passwords</strong> have been added to the installation flow. When installing and setting up WordPress, a strong password will be suggested to site administrators. Please test and let us know if you encounter issues.</li>
<li>Improved <strong>accessibility of comments and media list tables</strong>. If you use a screen reader, please let us know if you encounter any issues.</li>
<li>Lots and lots of code documentation improvements.</li>
<li><strong>Various other bug fixes</strong>. We&#8217;ve made <a href="https://core.trac.wordpress.org/log?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33286&amp;stop_rev=33141&amp;limit=150">more than 140 changes</a> in the last week.</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href="https://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.3">everything we’ve fixed</a>.</p>
<p><em>Want to test new things?</em><br />
<em>Wonder how four three shapes up?</em><br />
<em>Answer: beta three</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.3 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 08 Jul 2015 22:04:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"4.3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3769";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:337:"WordPress 4.3 Beta 2 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Konstantin Obenland";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2876:"<p>WordPress 4.3 Beta 2 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="https://wordpress.org/wordpress-4.3-beta2.zip">download the beta here</a> (zip).</p>
<p>For more information about what’s new in version 4.3, <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/">check out the Beta 1 blog post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Fixed an issue in beta 1 where an alert appeared when saving or publishing a new post/page for the first time.</li>
<li><strong><strong>Customizer</strong></strong> improvements including enhanced accessibility, smoother menu creation and location assignment, and the ability to handle nameless menus. Please help us test menus in the Customizer to fix any remaining edge cases!</li>
<li>More robust<strong> list tables</strong> with full content support on small screens and a fallback for the primary column for custom list tables. We&#8217;d love to know how these list tables, such as All Posts and Comments, work for you now on small screen devices.</li>
<li>The <strong>Site Icon</strong> feature has been improved so that cropping is skipped if the image is the exact size (512px square) and the media modal now suggests a minimum icon size. Please let us know how the flow feels and if you encounter any glitches!</li>
<li>The <strong>toolbar</strong> now has a direct link to the customizer, along with quick access to themes, widgets, and menus in the dashboard.</li>
<li>We enabled <strong>utf8mb4 for MySQL</strong> extension users, which was previously unintentionally limited to MySQLi users. Please let us know if you run into any issues.</li>
<li><strong>Various bug fixes</strong>. We&#8217;ve made <a href="https://core.trac.wordpress.org/log?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33138&amp;stop_rev=33046">almost 100 changes</a> in the last week.</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href="https://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;milestone=4.3&amp;group=component&amp;order=priority">everything we’ve fixed</a>.</p>
<p><em>Edges polished up</em><br />
<em>Features meliorated</em><br />
<em>Beta Two: go test!</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordCamps Update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"https://wordpress.org/news/2015/07/wordcamps-update/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2015/07/wordcamps-update/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 08 Jul 2015 16:13:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"Events";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3758";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:311:"Last week saw the halfway point for 2015, yay! This seems like a good time to update you on WordCamp happenings in the first half of this year. There have been 39 WordCamps in 2015 so far, with events organized in 17 different countries and on 5 continents. More than 14,000 people have registered for [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Andrea Middleton";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:9419:"<p>Last week saw the halfway point for 2015, yay! This seems like a good time to update you on WordCamp happenings in the first half of this year.</p>
<p>There have been <a href="https://central.wordcamp.org/schedule/past-wordcamps/">39 WordCamps in 2015</a> so far, with events organized in 17 different countries and on 5 continents. More than 14,000 people have registered for WordCamp tickets so far this year, isn&#8217;t that amazing?</p>
<p><a href="https://europe.wordcamp.org/2015/">WordCamp Europe</a> was held in Seville, Spain just a few weeks ago, with close to 1,000 registered participants and over 500 live stream participants. You can watch  <a href="http://wordpress.tv/2015/07/04/matt-mullenweg-keynote-qanda-wordcamp-europe-2015/">Matt Mullenweg’s keynote Q&amp;A</a> session from WordCamp Europe right now on WordPress.tv.</p>
<p>WordPress.tv has published 537 videos so far in 2015 from WordCamps around the world. Some of the more popular 2015 WordCamp talks on WordPress.tv include <a href="http://wordpress.tv/2015/03/13/tammie-lister-theme-dont-be-my-everything/">Tammie Lister: Theme, Don’t Be My Everything </a>from WordCamp Maui, <a href="http://wordpress.tv/2015/04/17/jenny-munn-seo-for-2015-whats-in-whats-out-and-how-to-be-in-it-to-win-it-for-good/">Jenny Munn: SEO for 2015 – What’s In, What’s Out and How to Be In It to Win It (For Good)</a> from WordCamp Atlanta, <a href="http://wordpress.tv/2015/02/27/fabrice-ducarme-les-constructeurs-de-page-pour-wordpress/">Fabrice Ducarme: Les Constructeurs de Page pour WordPress</a> from WordCamp Paris, <a href="http://wordpress.tv/2015/06/02/ben-furfie-how-to-value-price-websites/">Ben Furfie: How to Value Price Websites</a> from WordCamp London, and <a href="http://wordpress.tv/2015/06/09/morten-rand-hendriksen-building-themes-from-scratch-using-underscores-_s/">Morten Rand-Hendriksen: Building Themes From Scratch Using Underscores (_S)</a> from WordCamp Seattle. Check them out!</p>
<h3>Lots of great WordCamps are still to come</h3>
<p><a href="http://ma.tt/2015/06/wordcamp-us-survey/">WordCamp US</a> is currently in pre-planning, in the process of deciding on a host city. The following cities have proposed themselves as a great place to host the first WordCamp US: Chattanooga, Chicago, Detroit, Orlando, Philadelphia, and Phoenix. It&#8217;s possible the first WordCamp US will be held in 2016 so we can organize the best first WordCamp US imaginable.</p>
<p>At this time, there are 28 <a href="https://central.wordcamp.org/schedule/">WordCamps</a>, in 9 different countries, that have announced their dates for the rest of 2015. Twelve of these have tickets on sale:</p>
<ul>
<li><a href="https://columbus.wordcamp.org/2015/">WordCamp Columbus</a>, Columbus, Ohio: July 17-18</li>
<li><a href="https://scranton.wordcamp.org/2015/">WordCamp Scranton</a>, Scranton, Pennsylvania: July 18</li>
<li><a href="https://boston.wordcamp.org/2015/">WordCamp Boston</a>, Boston, Massachussetts: July 18-19</li>
<li><a href="https://milwaukee.wordcamp.org/2015/">WordCamp Milwaukee</a>, Milwaukee, Wisconsin: July 24-26</li>
<li><a href="https://asheville.wordcamp.org/2015/">WordCamp Asheville</a>, Asheville, North Carolina: July 24-26</li>
<li><a href="https://kansai.wordcamp.org/2015/">WordCamp Kansai</a>, Kansai, Japan: July 25-26</li>
<li><a href="https://fayetteville.wordcamp.org/2015/">WordCamp Fayetteville</a>, Fayetteville, Arkansas: July 31-August 2</li>
<li><a href="https://brighton.buddycamp.org/2015/">BuddyCamp Brighton</a>,  Brighton, UK: August 8</li>
<li><a href="https://vancouver.wordcamp.org/2015/">WordCamp Vancouver, BC,</a> Vancouver, BC, Canada: August 15-16</li>
<li><a href="https://russia.wordcamp.org/2015/">WordCamp Russia</a>, Moscow, Russia: August 15</li>
<li><a href="https://norrkoping.wordcamp.org/2015/">WordCamp Norrköping</a>, Norrköping, Sweden: August 28-29</li>
<li><a href="https://croatia.wordcamp.org/2015/">WordCamp Croatia</a>, Rijeka, Croatia: September 5-6</li>
<li><a href="https://krakow.wordcamp.org/2015/">WordCamp Krakow,</a>  Krakow, Poland: September 12-13</li>
<li><a href="https://nyc.wordcamp.org/2015/">WordCamp NYC</a>, New York City, New York: October 30-November 1</li>
</ul>
<p>The other 16 events don’t have tickets on sale yet, but they’ve set their dates! Subscribe to the sites to find out when registration opens:</p>
<ul>
<li><a href="https://pune.wordcamp.org/2015/">WordCamp Pune</a>, Pune, India: September 6</li>
<li><a href="https://capetown.wordcamp.org/2015/">WordCamp Cape Town</a>, Cape Town, South Africa: September 10-11</li>
<li><a href="https://baltimore.wordcamp.org/2015/">WordCamp Baltimore</a>, Baltimore, Maryland: September 12</li>
<li><a href="https://slc.wordcamp.org/2015/">WordCamp Salt Lake City</a>, Salt Lake City, Utah: September 12</li>
<li><a href="https://lithuania.wordcamp.org/2015/">WordCamp Lithuania</a>, Vilnius, Lithuania: September 19</li>
<li><a href="https://vegas.wordcamp.org/2015">WordCamp Vegas</a>, Las Vegas, Nevada: September 19-20</li>
<li><a href="https://switzerland.wordcamp.org/2015/">WordCamp Switzerland</a>, Zurich, Switzerland: September 19-20</li>
<li><a href="https://tampa.wordcamp.org/2015/">WordCamp Tampa</a>, Tampa, Florida: September 25-27</li>
<li><a href="https://rhodeisland.wordcamp.org/2015/">WordCamp Rhode Island</a>,  Providence, Rhode Island: September 25-26</li>
<li><a href="https://la.wordcamp.org/2015/">WordCamp Los Angeles</a>, Los Angeles, California: September 26-27</li>
<li><a href="https://denmark.wordcamp.org/2015/">WordCamp Denmark,</a>  Copenhagen, Denmark: October 3-4</li>
<li><a href="https://toronto.wordcamp.org/2015">WordCamp Toronto</a>, Toronto, Ontario, Canada: October 3-4</li>
<li><a href="https://hamptonroads.wordcamp.org/2015/">WordCamp Hampton Roads, </a>  Virginia Beach, VA, USA: October 17</li>
<li><a href="https://annarbor.wordcamp.org/2015">WordCamp Ann Arbor</a>, Ann Arbor, Michigan: October 24</li>
<li><a href="https://portland.wordcamp.org/2015/">WordCamp Portland</a>,  Portland, OR: October 24-25</li>
</ul>
<p>On top of all those exciting community events, there are 26 WordCamps in pre-planning as they look for the right event space.  If you have a great idea for a free or cheap WordCamp venue in any of the below locations, get in touch with the organizers through the WordCamp sites:</p>
<ul>
<li><a href="https://dfw.wordcamp.org/2015/">WordCamp DFW</a>:  Dallas/Fort Worth, Texas</li>
<li><a href="https://riodejaneiro.wordcamp.org/2015/">WordCamp Rio</a>: Rio de Janeiro, Brazil</li>
<li><a href="https://saratoga.wordcamp.org/2015/">WordCamp Saratoga</a>:  Saratoga Springs, New York</li>
<li><a href="https://sofia.wordcamp.org/2015">WordCamp Sofia</a>:  Sofia, Bulgaria</li>
<li><a href="https://austin.wordcamp.org/2015/">WordCamp Austin</a>:  Austin, TX</li>
<li><a href="https://ottawa.wordcamp.org/2015/">WordCamp Ottawa</a>:  Ottawa, Canada</li>
<li><a href="https://charleston.wordcamp.org/2015/">WordCamp Charleston</a>:  Charleston, South Carolina</li>
<li><a href="https://chicago.wordcamp.org/2015/">WordCamp Chicago</a>:  Chicago, Illinois</li>
<li><a href="https://albuquerque.wordcamp.org/2015/">WordCamp Albuquerque</a>:  Albuquerque, New Mexico</li>
<li><a href="https://prague.wordcamp.org/2015/">WordCamp Prague</a>:  Prague, Czech Republic</li>
<li><a href="https://seoul.wordcamp.org/2014/">WordCamp Seoul: </a>Seoul, South Korea</li>
<li><a href="https://louisville.wordcamp.org/2014/">WordCamp Louisville</a>: Louisville, Kentucky</li>
<li><a href="https://omaha.wordcamp.org/2015/">WordCamp Omaha</a>:  Omaha, Nebraska</li>
<li><a href="https://grandrapids.wordcamp.org/2015/">WordCamp Grand Rapids</a>:  Grand Rapids, Michigan</li>
<li><a href="https://easttroy.wordcamp.org/2015/">WordCamp East Troy</a>:  East Troy, Wisconsin</li>
<li><a href="https://palmademallorca.wordcamp.org/2015">WordCamp Mallorca</a>: Palma de Mallorca, Spain</li>
<li><a href="https://edinburgh.wordcamp.org/2015/">WordCamp Edinburgh</a>:  Edinburgh, United Kingdom</li>
<li><a href="https://orlando.wordcamp.org/2015/">WordCamp Orlando</a>:  Orlando, Florida</li>
<li><a href="https://mexico.wordcamp.org/2015/">WordCamp Mexico City</a>:  Mexico City, Mexico</li>
<li><a href="https://netherlands.wordcamp.org/2015/">WordCamp Netherlands</a>:  Utrecht, Netherlands</li>
<li><a href="https://phoenix.wordcamp.org/2016/">WordCamp Phoenix</a>:  Phoenix, Arizona</li>
<li><a href="https://saopaulo.wordcamp.org/2015/">WordCamp São Paulo</a>:  São Paulo, Brazil</li>
<li><a href="https://manchester.wordcamp.org/2015/">WordCamp Manchester</a>:  Manchester, United Kingdom</li>
<li><a href="https://tokyo.wordcamp.org/2015/">WordCamp Tokyo</a>:  Tokyo, Japan</li>
<li><a href="https://lima.wordcamp.org/2015/">WordCamp Lima</a>:  Lima, Peru</li>
<li><a href="https://seattle.wordcamp.org/2015-beginner/">WordCamp Seattle: Beginner</a>: Seattle, WA</li>
</ul>
<p>Don’t see your city on the list, but yearning for a local WordCamp? WordCamps are organized by local volunteers from the WordPress community, and we have a whole team of people to support new organizers setting up a first-time WordCamp. If you want to bring WordCamp to town, check out how you can <a href="https://central.wordcamp.org/become-an-organizer/">become a WordCamp organizer</a>!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wordpress.org/news/2015/07/wordcamps-update/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.3 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Jul 2015 01:30:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"4.3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3738";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"WordPress 4.3 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Konstantin Obenland";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4352:"<p>WordPress 4.3 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.3-beta1.zip">download the beta here</a> (zip).</p>
<p>4.3 is due out next month, but to get there, we need your help testing what we&#8217;ve been working on:</p>
<ul>
<li><strong>Menus</strong> can now be managed with the <strong>Customizer</strong>, which allows you to live preview changes you’re making without changing your site for visitors until you’re ready. We&#8217;re especially interested to know if this helps streamline the process of setting up your site (<a href="https://core.trac.wordpress.org/ticket/32576">#32576</a>).</li>
<li>Take control of another piece of your site with the <strong>Site Icon</strong> feature. You can now manage your site’s favicon and app icon from the admin area (<a href="https://core.trac.wordpress.org/ticket/16434">#16434</a>).</li>
<li>We put a lot of work into <strong>Better Passwords</strong> throughout WordPress. Now, WordPress will limit the life time of password resets, no longer send passwords via email, and generate and suggest secure passwords for you. Try it out and let us know what you think! (<a href="https://core.trac.wordpress.org/ticket/32589">#32589</a>)</li>
<li>We’ve also added <strong>Editor Improvements</strong>. Certain text patterns are automatically transformed as you type, including <code>*</code> and <code>-</code> transforming into unordered lists, <code>1.</code> and <code>1)</code> for ordered lists, <code>&gt;</code> for blockquotes and two to six number signs (<code>#</code>) for headings (<a href="https://core.trac.wordpress.org/ticket/31441">#31441</a>).</li>
<li>We’ve improved the <strong>list view</strong> across the admin dashboard. Now, when you view your posts and pages <strong>on small screen devices</strong>, columns are not truncated and can be toggled into view (<a href="https://core.trac.wordpress.org/ticket/32395">#32395</a>).</li>
</ul>
<p><strong>Developers</strong>: There have been a few of changes for you to test as well, including:</p>
<ul>
<li><strong>Taxonomy Roadmap:</strong> Terms shared across multiple taxonomies will <a href="https://make.wordpress.org/core/2015/06/09/eliminating-shared-taxonomy-terms-in-wordpress-4-3/">now be split</a> into separate terms on update to 4.3. Please let us know if you hit any snags (<a href="https://core.trac.wordpress.org/ticket/30261">#30261</a>).</li>
<li>Added <code>singular.php</code> to the template hierarchy as a fallback for <code>single.php</code> and <code>page.php</code>. (<a href="https://core.trac.wordpress.org/ticket/22314">#22314</a>).</li>
<li>The old Distraction Free Writing code was removed (<a href="https://core.trac.wordpress.org/ticket/30949">#30949</a>).</li>
<li>List tables now can (and often should) have a primary column defined. We’re working on a fallback for existing custom list tables but right now they likely have some breakage in the aforementioned responsive view (<a href="https://core.trac.wordpress.org/ticket/25408">#25408</a>).</li>
</ul>
<p>If you want a more in-depth view of what changes have made it into 4.3, <a href="https://make.wordpress.org/core/tag/4-3/">check out all 4.3-tagged posts</a> on the main development blog.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.3">everything we’ve fixed</a> so far.</p>
<p>Happy testing!</p>
<p><em>Site icons for all</em><br />
<em>Live preview menu changes</em><br />
<em>Four three beta now</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:32:"https://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Tue, 15 Sep 2015 20:10:41 GMT";s:12:"content-type";s:34:"application/rss+xml; charset=UTF-8";s:10:"connection";s:5:"close";s:25:"strict-transport-security";s:11:"max-age=360";s:10:"x-pingback";s:37:"https://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Tue, 15 Sep 2015 15:25:14 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911090210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (2668, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1442391041', 'no') ; 
INSERT INTO `wp_options` VALUES (2669, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1442347841', 'no') ; 
INSERT INTO `wp_options` VALUES (2670, '_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9', '1442391042', 'no') ; 
INSERT INTO `wp_options` VALUES (2671, '_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"Post Status: Gravity Flow makes custom form administrative workflows simple";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"https://poststatus.com/?p=14337";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:86:"https://poststatus.com/gravity-flow-makes-custom-form-administrative-workflows-simple/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6464:"<p></p>
<p><a href="https://gravityflow.io/">Gravity Flow</a> is one of the coolest new plugins I&#8217;ve seen in quite some time.</p>
<p>Invoices, purchase orders, job applications, and employee vacation requests are just a few potential applications for Gravity Flow, which makes form-centric approval, user input, and notification processes simple.</p>
<p>&#8220;With Gravity Flow, you use the power of <a href="http://www.gravityforms.com/">Gravity Forms</a> to design your forms, and you use Gravity Flow to design your process using easy to use drag-and-drop tools,&#8221; the video states. The flows created in Gravity Flow can be customized to include all sorts of user-defined paths to request stakeholder feedback, get administrative approval, or fire off a notification that a certain step in the flow has been accomplished. It can even be integrated with other notification systems like Zapier.</p>
<p>It&#8217;s not that common to see a WordPress plugin (especially an add-on plugin) that simultaneously targets a niche and serves it so extensively. Gravity Flow is built to extend the powerful Gravity Forms product, and it really takes it an extra mile.</p>
<p>I see a lot of potential for Gravity Flow for intranets and other corporate environments with lots of stakeholders and traditionally clunky, email based workflows for approval of common tasks.</p>
<h3>Trying Gravity Flow</h3>
<p>I took Gravity Flow for a spin, because there is a handy demo site capability built in. For a plugin this complex, being able to test drive it is a really great feature. Most workflow tasks can take place either in the admin or on the front-end.</p>
<p>Creating workflows feels a lot like adding regular notifications to Gravity Forms.</p>
<p><img class="aligncenter size-large wp-image-14340" src="https://cdn.poststatus.com/wp-content/uploads/2015/09/gravity-flow-workflow-752x579.png" alt="gravity-flow-workflow" width="752" height="579" /></p>
<p>Workflows have many configuration and sending options. And each step can be sorted and arranged to follow a series of steps, and can even allow for delays (like for a scholarship review period, in my example).</p>
<p>That&#8217;s the view for an administrator, but someone who is responsible for providing feedback or approval has a front-end view to directly interact with the workflow.</p>
<p><img class="aligncenter size-large wp-image-14339" src="https://cdn.poststatus.com/wp-content/uploads/2015/09/gravity-flow-review-update-workflow-752x872.png" alt="gravity-flow-review-update-workflow" width="752" height="872" /></p>
<p>And administrators can see reports of activity for various workflows.</p>
<p><img class="aligncenter size-large wp-image-14338" src="https://cdn.poststatus.com/wp-content/uploads/2015/09/gravity-flow-reports-752x552.png" alt="gravity-flow-reports" width="752" height="552" /></p>
<p>This is a pretty simple overview of the plugin, and I&#8217;d recommend you <a href="http://demo.gravityflow.io/">check out the demo</a>, or his full <a href="http://docs.gravityflow.io/category/34-walkthroughs">walkthrough</a> examples. but this at least highlights some of the plugin&#8217;s power.</p>
<h3>Development of Gravity Flow</h3>
<p>One of the more interesting things about Gravity Flow is that <a href="https://www.stevenhenty.com/">Steven Henty</a> made it. Steven actually works at Rocketgenius, the company behind Gravity Forms, and he is a developer of the main Gravity Forms product.</p>
<p>I talked to Steven about why this isn&#8217;t a Gravity Forms official add-on, and what it&#8217;s like working on a side project for your own company&#8217;s product.</p>
<blockquote><p>Rocketgenius has a lot of plans and loads of really exciting stuff in the pipeline so it was a question of priorities &#8211; Rocketgenius can’t possibly do absolutely everything at the same time. For me it’s a project that’s niche enough to be an interesting and profitable side project and yet not too time-consuming so I can continue to focus 100% on my day job.</p></blockquote>
<p>He also reiterated how important it is to him that he had his team behind him for this project. And Carl Hancock &#8212; co-founder of Rocketgenius &#8212; is excited about Steven&#8217;s product as well, saying &#8220;The product is awesome. It&#8217;s definitely more complex [and] business oriented, but that&#8217;s a good thing.&#8221;</p>
<p>Carl also shared that Steve has a background that lends itself to thinking about complex problems to solve, working on, &#8220;more enterprise stuff pre-WordPress, on a wide variety of platforms and programming languages.&#8221;</p>
<p>Steve did a great job with Gravity Flow, and I&#8217;m happy to see it out there.  On <a href="https://www.stevenhenty.com/gravity-flow/">his personal blog</a>, he highlights use cases for the product, which are real world examples based on how his first 100 beta testers are using it.</p>
<h3>Gravity ecosystem</h3>
<p>A few Rocketgenius employees have Gravity Forms focused side projects, which I think is really cool. Another favorite of mine is David Smith&#8217;s <a href="http://gravitywiz.com/">Gravity Wiz</a>, that adds functionality snippets, or &#8220;perks&#8221;, to Gravity Forms. The third-party ecosystem is doing well too; <a href="https://gravityplus.pro/">Gravity Plus</a> and <a href="https://gravityview.co/">Gravity View</a> are two healthy Gravity Forms focused businesses that come to mind, and I&#8217;m sure there are many more.</p>
<p>The main plugin continues to dominate the WordPress forms space. Though it is commercial only, it powers hundreds of thousands of websites, and has dozens of official <a href="http://www.gravityforms.com/add-ons/">add-ons</a>. Carl has told me many times he doesn&#8217;t even view most other WordPress forms plugins as competition (though newer entrants like <a href="https://ninjaforms.com/">Ninja Forms</a> are doing quite well for themselves), as Gravity Forms aims to take marketshare away from complex hosted solutions like Wufoo, rather than gobble up the much larger but less demanding market that just wants simple contact forms.</p>
<p>If you want to keep up with Gravity Flow, <a href="https://gravityflow.io/">check out the website</a>. And the project is <a href="https://github.com/stevehenty/gravityflow">on Github</a> as well, as Steve is billing for support and automatic upgrades, which starts at €87 (around $100) per year.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Sep 2015 13:55:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"Matt: Long Days";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45319";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:31:"http://ma.tt/2015/09/long-days/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:204:"<p>Sometimes it seems like the longest days are those in between an Apple announcement and when the products are actually available. I&#8217;m looking forward to iOS 9, WatchOS 2, 6s+, Apple TV&#8230;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Sep 2015 17:00:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WPTavern: A Recap of WordCamp Pune, India, by Topher DeRosia";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48212";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wptavern.com/a-recap-of-wordcamp-pune-india-by-topher-derosia";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8337:"<hr />
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/09/TopherDeRosia.png"><img class="alignright size-thumbnail wp-image-48213" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/09/TopherDeRosia.png?resize=150%2C150" alt="Topher DeRosia" /></a>This post was contributed by <a title="Topher DeRosia" href="http://topher1kenobe.com/" target="_blank">Topher DeRosia</a>. Topher has contributed to a <a href="https://profiles.wordpress.org/topher1kenobe#content-plugins">number of plugins</a>, spoken at many WordCamps, and is the lead of documentation for <a href="https://easydigitaldownloads.com/">Easy Digital Downloads.</a> He also operates <a href="http://heropress.com/">HeroPress.com</a> on the side.</p>
<hr />
<p>Last July, the lead organizer of <a href="https://pune.wordcamp.org/2015/">WordCamp Pune, India </a>asked if I would come and speak about HeroPress. This post isn&#8217;t going to be about <a href="http://heropress.com/about/">HeroPress</a> nor about <a href="http://heropress.com/category/wordcamp/pune/">my adventures on the trip</a>. No, this post is going to be about a WordCamp in a relatively large city in India, how it compares to American WordCamps, and some things that were experimented with.</p>
<h2>The Similarities</h2>
<p>In many ways, WordCamp Pune is exactly like every other WordCamp I&#8217;ve been to. The night before the event, there was a speaker dinner with excellent food and wonderful company. Registration was chaotic because WiFi was a mess.</p>
<p>Everyone was happy and excited to be there, and it was very loud because everyone wanted to be part of a conversation. It had all the elements I love about WordCamps; handshakes between new friends, hugs between old friends, and huge transfers of information between everyone, it was fantastic. Aside from WordCamp Miami, it&#8217;s also the largest WordCamp I&#8217;ve attended with 500 tickets sold.</p>
<p>It was well-organized, by which I mean things were well planned for, and handled well when they didn&#8217;t work out. Sessions were held in university class rooms. I think they were a little small for the number of attendees, but it didn&#8217;t detract from the experience. Here&#8217;s an example of a room:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/WordCamp-Pune-India-Classroom.png"><img class="aligncenter size-full wp-image-48218" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/WordCamp-Pune-India-Classroom.png?resize=904%2C509" alt="WordCamp Pune Classrooms" /></a>Here&#8217;s Ramya Pandyan talking about being a better blogger:</p>
<p><span class="embed-youtube"></span></p>
<h2>The Differences</h2>
<p>This is the first WordCamp I&#8217;ve attended where the sessions were in a variety of languages. I would expect this in a place like WordCamp EU, but to have it be a variety of <em>local</em> languages was fascinating to me.</p>
<p>The unofficial time zone of India is <a href="http://blogs.wsj.com/indiarealtime/2010/04/28/india-journal-understanding-ist-indian-stretchable-time/">Indian Stretchable Time</a>. On the first day of WordCamp, Saurabh worked hard to keep things on schedule. We started 30 minutes late, but on Foundation Day, things got started an hour late.</p>
<p>The room was full of people sitting and waiting patiently, but starting on time was <strong>not expected</strong>. In the US, I would have expected a lot more cranky people.</p>
<p>Many things were heavily guarded. The main venue was quite open, but to get into Foundation Day, I had to let these guys check me with a magnetic wand:</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/09/IndianPolicemen.png"><img class="aligncenter size-full wp-image-48219" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/09/IndianPolicemen.png?resize=904%2C510" alt="Indian Policemen" /></a>Then 20 feet away sign in at a guard house, and then 30 feet beyond that show my ID inside the front door of the venue. This kind of thing also happened at restaurants and every time I went into my hotel. No-one was ever aggressive or suspicious, it&#8217;s just something that happened and everyone took it in stride.</p>
<h2>The Word Lounge</h2>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/WordLounge.png"><img class="alignright size-full wp-image-48220" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/WordLounge.png?resize=298%2C462" alt="Word Lounge" /></a> There was a room set aside to be an all day open session for writers. There&#8217;s a local group called <a href="https://twitter.com/AlphabetSambar">Alphabet Sambar</a> (Sambar is a soup) that has a regular meetup to help each other with writing. They made sure to welcome attendees and keep a good discussion going all day.</p>
<p>I love this idea of unconference rooms based on topic. Some people thrive on the group communication that can come from that format, and I&#8217;d love to see other topical open forums at other WordCamps.</p>
<h2>The After Party</h2>
<p>I&#8217;m a big fan of quiet after parties, so I can talk to people. I can also appreciate people wanting a pretty intense party atmosphere. The <a href="https://twitter.com/crccpune">Classic Rock Coffee Co.</a> offered both.</p>
<p>It had three large areas, the largest being almost 6000 sq. ft., one about 800 sq. ft., and an ampitheater with seating for about 100 where they had live classic rock bands.</p>
<p>Additionally, there was a closed in area with seating for about 40 people that felt more like a cafe or restaurant. The larger open areas had a full bar and restaurant. Except for the cafe, the whole place had a fabric roof which is less sturdy than canvas. It had an outdoors feel.</p>
<p>I was sitting at a table of about 15 people and had no trouble communicating with any of them. I was probably 130 feet from the music and it was well contained. I was able to communicate without noise being an issue.</p>
<p>Groups of people sat at tables, in the cafe, in the ampitheater; wherever they were most comfortable. It was probably my favorite after-party venue of all time.</p>
<a href="http://wptavern.com/a-recap-of-wordcamp-pune-india-by-topher-derosia#gallery-48212-1-slideshow">Click to view slideshow.</a>
<h2>Bits and Pieces</h2>
<p>The most difficult thing for me was trying to discern people through their accents. Just about everyone had a solid handle on English, but there&#8217;s a mental fatigue that comes from parsing the words through an accent. The longer you do it, the harder it gets, especially with sleep deprivation. I tried not to be rude, and people were patient with me.</p>
<p>There was a photo area with some crazy hats and people seemed to have a really good time with it. I can see it working at other WordCamps as well. The ladies from Hummingbird got one of me in a crazy hat, but I haven&#8217;t seen it yet.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/CrazyHatPicture.png"><img class="alignright size-full wp-image-48226" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/CrazyHatPicture.png?resize=1025%2C578" alt="Crazy Hat Picture" /></a></p>
<p>Lunch was prepared on-site in realtime and it worked. It was mostly sandwiches, and the food prep people took a request, made the sandwich, and handed it to the person in moments. I wouldn&#8217;t have expected it to work that smoothly, but it did.</p>
<p>Fruit and bottled water were available just about all the time, which was nice since it was pretty hot that day.</p>
<h2>Summary</h2>
<p>Except for the food and language, this WordCamp didn&#8217;t feel all that foreign to me. I suspect it&#8217;s because WordCamps have a solid template for sessions, scheduling, etc. I enjoyed that, it enabled me to really take part in the event without having to stand to the side wondering what was going on.</p>
<p>The organizers seemed to be on the ball and did a great job sharing the responsibilities, which I think is vital with a camp this size. The people were engaged, took full advantage of the options available to them, and <strong>that</strong> is what made it a successful WordCamp in my opinion.</p>
<p>If you ever get the chance to attend a WordCamp in a culture other than your own, I highly recommend you jump at the opportunity.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 12 Sep 2015 02:50:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:122:"Post Status: Justifying conferences, improving WordPress comments, and WordPress’s PHP version support — Draft podcast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"https://poststatus.com/?p=14315";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:124:"https://poststatus.com/justifying-conferences-improving-wordpress-comments-and-wordpresss-php-version-support-draft-podcast/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2719:"<p>Welcome to the Post Status Draft podcast, which you can find <a href="https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008">on iTunes</a> and <a href="http://simplecast.fm/podcasts/1061/rss">via RSS</a> for your favorite podcatcher. Brian and his co-host, <a href="https://twitter.com/joe_hoyle">Joe Hoyle</a>, a co-founder and the CTO of <a href="https://hmn.md/">Human Made</a>, discuss some of today’s hottest, current WordPress news.</p>
<p><!--[if lt IE 9]><script>document.createElement(\'audio\');</script><![endif]-->
<a href="https://audio.simplecast.fm/17141.mp3">https://audio.simplecast.fm/17141.mp3</a><br />
<a href="https://audio.simplecast.fm/17141.mp3">Direct Download</a></p>
<h3>Links and Stories Discussed</h3>
<h4>Events links</h4>
<ul>
<li><a href="http://feelingrestful.com">A Day of REST </a> and <a href="https://poststatus.com/a-day-of-rest-a-conference-devoted-to-the-wordpress-rest-api/">the Post Status post on it</a></li>
<li><a href="https://2015.us.wordcamp.org">WordCamp US</a></li>
<li><a href="https://tampa.wordcamp.org/2015/">WordCamp Tampa</a></li>
<li><a href="https://nyc.wordcamp.org/2015/">WordCamp NYC</a></li>
<li><a href="http://pressnomics.com/">PressNomics</a></li>
<li><a href="https://europe.wordcamp.org/2015/how-we-selected-vienna-the-wordcamp-europe-2016-host-city/">WordCamp Europe</a></li>
<li><a href="https://www.groovehq.com/blog/friday-qa-september-04-2015">Are conferences worth it?</a></li>
</ul>
<h4>Comments links</h4>
<ul>
<li><a href="https://poststatus.com/wordpress-comments/">Brian’s recommendations for comments</a></li>
<li><a href="https://markjaquith.wordpress.com/2015/03/27/cache-buddy/">Performance for comments</a>, part of Mark Jaquith&#8217;s Cache Buddy</li>
<li><a href="https://pippinsplugins.com/featured-comments/">Featuring comments</a> by Pippin Williamson</li>
<li><a href="https://github.com/staylor/comments-redux">Comments Redux</a></li>
<li><a href="https://core.trac.wordpress.org/component/Comments">Comment Trac tickets</a></li>
</ul>
<h4>PHP links</h4>
<ul>
<li><a href="https://wordpress.org/about/stats/">WordPress PHP stats</a></li>
<li><a href="http://php.net/releases/">PHP releases</a></li>
<li><a href="https://www.zend.com/en/resources/php-7">New in PHP7</a></li>
<li><a href="https://www.digitalocean.com/company/blog/getting-ready-for-php-7/">PHP benchmarks</a></li>
<li><a href="https://make.wordpress.org/core/2015/09/10/wordpress-and-php7/">PHP7 on WordPress</a></li>
</ul>
<h4>Segments</h4>
<ul>
<li>We start the show with events and discuss justification for them.</li>
<li>25 minutes in or so, we switch to comment discussion.</li>
<li>47 minutes in we switch to PHP.</li>
</ul>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 11 Sep 2015 23:06:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:89:"WPTavern: A Look Inside the Offices of 16 People Who Work With WordPress on a Daily Basis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48204";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:99:"http://wptavern.com/a-look-inside-the-offices-of-16-people-who-work-with-wordpress-on-a-daily-basis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2088:"<p>In a remote worker environment, people have the choice to work from home or wherever it&#8217;s convenient. Syed Waseem Abbas published a <a href="http://torquemag.io/inside-the-workplaces-of-16-wordpress-community-mavens/">guest post on Torquemag,</a> that looks at the offices of 16 people who work with WordPress on a daily basis.</p>
<p>Some of the offices are classy while others are small. Many of the people featured in the post use one or more Apple products. If you&#8217;re curious as to what my setup looks like, here you go.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/JeffrosOffice.jpg"><img class="size-full wp-image-48205" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/JeffrosOffice.jpg?resize=960%2C720" alt="My Home Office" /></a>My Home Office
<p>Most of the work I do is on a Windows 7 Professional 64bit desktop PC with two 23-inch monitors. When I work remotely, I use a fully loaded 15-inch MacBook Pro with retina display from 2013. As a devoted Windows user, I feel like I&#8217;m part of a dying breed, especially within the WordPress ecosystem.</p>
<p>For WordPress Weekly, I use a <a href="http://www.amazon.com/Samson-CO1U-Studio-Condenser-Microphone/dp/B000PTF0E2">Samson CO1U</a> USB powered condenser microphone connected to a <a href="http://www.amazon.com/musical-instruments/dp/B001D7UYBO/ref=sr_1_1?s=musical-instruments&ie=UTF8&qid=1442008126&sr=1-1&keywords=Rode+Swivel+mount">Rode PSA1 swivel mount</a> with a boom arm.</p>
<p>I predominantly work in a sitting position which is why I&#8217;m in the market for a standing desk where the height can be easily adjusted. I&#8217;m also looking for a new office chair where the arm rests don&#8217;t disintegrate within the first year of use.</p>
<p>If you have any suggestions, let me know in the comments. Also, if you need inspiration to create the perfect office environment, check out <a href="https://officetoday.wordpress.com/">Office Today</a>. Office Today features remote offices and locations from across the world used by Automattic employees.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 11 Sep 2015 22:18:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"WPTavern: Tickets On Sale For WordCamp US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48142";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://wptavern.com/tickets-on-sale-for-wordcamp-us";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2810:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/TicketsFeaturedImage.png"><img class="size-full wp-image-48146" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/TicketsFeaturedImage.png?resize=650%2C200" alt="Tickets Featured Image" /></a>photo credit: <a href="http://www.flickr.com/photos/32029534@N00/14207873200">lucky random fate : san francisco (2013)</a> &#8211; <a href="https://creativecommons.org/licenses/by-nd/2.0/">(license)</a>
<p>Tickets for the first annual <a href="https://2015.us.wordcamp.org/">WordCamp US</a> are now <a href="https://2015.us.wordcamp.org/tickets/">on sale</a>. Due to overwhelming popularity, tickets are being released in batches with the first batch selling out within hours. There are three types of tickets available for purchase.</p>
<ol>
<li>A full weekend pass for <strong>$40</strong> that includes both session days as well as a ticket for Contributor day. Lunch each day and swag are also included.</li>
<li><span class="tix-ticket-excerpt">A live stream ticket for <strong>$20</strong> that allows you to watch the event from any place that has an internet connection. You also receive a limited edition WordCamp US 2015 t-shirt. Shirts will be mailed out after the event concludes.</span></li>
<li>A live stream ticket for <strong>$10</strong> that allows you to watch the event from any place that has an internet connection. This is a great option for meetup groups hosting watch parties.</li>
</ol>
<p>If you&#8217;re in a giving mood, there are 100 Jawn microsponsorships available for $250. This sponsorship <span class="tix-ticket-excerpt">gives you a General Admission ticket and an opportunity to provide financial support for the event. You&#8217;ll also be listed by name on the thank you section of the Sponsors page.</span></p>
<p>A group of tickets are being reserved for those volunteering or speaking at the event. Information related to the <a href="https://2015.us.wordcamp.org/2015/08/26/2015-wordpress-community-summit-dates-announced/">Community Summit</a> along with an application will be released next week. Although hotel accommodations are not yet available, the team plans to publish this information within the next few days.</p>
<p>Based on the <a href="https://2015.us.wordcamp.org/tickets/attendees/">attendees list</a> so far, the event is shaping up to be a great opportunity to meet some of the best of the best in the WordPress ecosystem. Expect this list to grow as more tickets become available.</p>
<p>If you host a WordPress meetup and are planning to have a WordCamp US watch party, please let me know in the comments. About a week before the event, I&#8217;ll publish a compiled list of watch parties so people know where to go to watch the event for free with like-minded individuals.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 11 Sep 2015 20:41:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WPTavern: bbPress 2015 Survey Results Show Users Want Attachments, Better Moderation Tools";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48180";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:99:"http://wptavern.com/bbpress-2015-survey-results-show-users-want-attachments-better-moderation-tools";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4797:"<p>The bbPress development team <a href="https://bbpress.org/blog/2015/09/2015-bbpress-survey-results/">published the results</a> of its 2015 survey. This year, 213 people participated which is 30 more <a href="https://bbpress.org/blog/2014/05/2014-bbpress-survey-results/">than last year</a>. After reviewing, replacing, and removing some questions from the 2014 survey, this year&#8217;s survey has 25 questions.</p>
<p>A variety of survey question types were used to gather the data including, multiple choices, check boxes, text fields, email box, and open‐ended questions. Empty forms were deleted and those marked as incomplete were reviewed individually. Submissions that had no responses on the second and third pages of the survey were excluded from the report.</p>
<h2>Highlights From the Survey</h2>
<p>The majority of respondents use bbPress 2.5 and above with WordPress 4.2 and above. Seventy-one percent of participants using bbPress &lt;=1.x.x are also using the latest version of WordPress. This data indicates bbPress users are vigilant in keeping their sites up to date.</p>
<p>In terms of who uses bbPress, 51% of respondents use it on their own sites while 30% create sites with bbPress forums for others.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/bbPress2015Users.png"><img class="size-full wp-image-48182" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/bbPress2015Users.png?resize=485%2C249" alt="bbPress 2015 Survey Users" /></a>bbPress 2015 Survey Who Uses bbPress
<p>For the second year in a row, the top three languages used are English 74%, German 7%, and French 6.5%. Three-fourths or 75% of bbPress installations are within WordPress either in the domain root, physical directory, or physical subdomain.</p>
<p>The remaining 25% are on multisite installations where more than half have activated bbPress network-wide and the rest in multiple networks.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/bbPress2015SurveyInstalls.jpg"><img class="size-full wp-image-48183" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/bbPress2015SurveyInstalls.jpg?resize=900%2C237" alt="bbPress User Installations" /></a>bbPress User Installations
<p>One statistic I&#8217;m proud of is that 29% of the respondents found out about the survey through WP Tavern.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/2015bbPressSurveyHowFoundOut.png"><img class="aligncenter size-full wp-image-48184" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/2015bbPressSurveyHowFoundOut.png?resize=854%2C328" alt="How People Found Out About The Survey" /></a>The most wanted features in a bbPress theme are, Responsive (69.5%), Light and Fresh Design (52%), and Compatible with the latest bbPress version (49%). A preference for Responsive, mobile-first themes is in fourth place at 39%.</p>
<p>For the second year in a row, Attachments (42.5%), Ajaxification of Topics and Replies (41.5%), and Moderation tools in the front end (39%) are the most requested features.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/09/bbPress2015MostRequestedFeatures.png"><img class="size-full wp-image-48196" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/09/bbPress2015MostRequestedFeatures.png?resize=463%2C219" alt="2015 Most Requested Features" /></a>2015 Most Requested Features
<h2>The Future of bbPress</h2>
<p>Mercime, a BuddyPress and bbPress core contributor, confirmed at the end of the survey that the bbPress project is alive and well. According to Mercime, the development team is in the middle of a large migration project:</p>
<blockquote><p>The <a href="https://bbpress.svn.wordpress.org/trunk/src/humans.txt">bbPress core team</a> has been involved in the process of migrating the WordPress Support Forums (English and all Rosetta sites) from bbPress 1.x.x to bbPress 2.5.8 starting with one European-language forums subsite which has been already ported and being tested on.</p>
<p>While this migration has been discussed many times and often over the years, <a href="https://profiles.wordpress.org/johnjamesjacoby/">@johnjamesjacoby</a> formally started the process when he <a href="https://make.wordpress.org/meta/2015/05/15/wp-org-forums-plugins-audit/">posted the results of an audit</a> to show the custom functionality required for a successful migration.</p></blockquote>
<p>The project involves multiple teams including, the <a href="https://make.wordpress.org/support/">WP Support team</a> and <a href="https://make.wordpress.org/meta/">WP Meta Team</a>. The migration will impact more than 8 million users on WordPress.org. Any improvements made to bbPress to ease the migration process are going to be merged back into the project.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Sep 2015 20:54:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WPTavern: WPML Confirms It Did Not Have a Security Breach";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48173";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wptavern.com/wpml-confirms-it-did-not-have-a-security-breach";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1427:"<p>When WPML emailed new <a href="http://wptavern.com/wpml-emails-passwords-to-affected-customers-in-plaintext">passwords to customers in plaintext</a>, some customers thought it was due to a security breach. Amit Kvint, compatibility team leader for WPML, confirmed the emails are not a result of a security breach.</p>
<p>In a <a href="https://wpml.org/2015/09/password-update-email-from-wpml/">post on the official WPML blog</a>, Kvint says the emails were a preventive measure to insure accounts remain secure, &#8220;The main purpose and underlying principle for this action was making sure everyone has a good new strong password, we consider this an important step in online security,&#8221; Kvint said.</p>
<p>Kvint acknowledges the improvements in WordPress 4.3 in how passwords are handled and admits that sending passwords in plaintext was not a good idea, &#8220;The best practice would be, once the password is sent, to login and reset the password to a new strong one. We will definitely revise the way this is done in the future,&#8221; Kvint said.</p>
<p>The blog post does not go into detail in how they determined passwords to be weak. To the best of my knowledge, WPML does not have a policy in place to enforce strong passwords. While no accounts were compromised, if some of the contacted customers choose a weak password, wouldn&#8217;t it defeat the purpose of resetting passwords in the first place?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Sep 2015 07:28:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:88:"WPTavern: Jetpack 3.7 Introduces a Simpler Interface, Adds Support for Development Sites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48161";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://wptavern.com/jetpack-3-7-introduces-a-simpler-interface-adds-support-for-development-sites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3151:"<p>Jetpack 3.7 <a href="http://jetpack.me/2015/09/09/jetpack-3-7-simpler-ui-support-for-development-sites-and-more/">is available</a> and includes a simpler user interface, support for development sites, and fixes several issues with a variety of modules.</p>
<p>The new interface separates some of Jetpack&#8217;s functionality into categories such as, performance and security, traffic growth, and WordPress.com tools. The most commonly used modules are listed first with a link underneath that takes users to the other 27 modules and the old settings page.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/Jetpack-37Interface.png"><img class="size-full wp-image-48162" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/Jetpack-37Interface.png?resize=968%2C492" alt="Jetpack 3.7 Interface" /></a>Jetpack 3.7 Interface
<p>Turning a module on or off is accomplished by clicking a toggle. Services you need to pay for are clearly marked with links to learn more.</p>
<p>One of the biggest drawbacks to Jetpack is switching between a local server or staging environment. If you move your site from one URL to another, Jetpack automatically detects the change and prompts the user to confirm if the URL is correct.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/JetpackStagingSite1.png"><img class="size-full wp-image-48163" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/JetpackStagingSite1.png?resize=1025%2C155" alt="Jetpack on a staging site" /></a>Jetpack on a staging site
<p>If Jetpack thinks two URLs are separate websites, it recommends that you create a new connection to prevent a service interruption on the original domain. The prompt has links to reset the connection, confirm that the URL is part of a development environment, or submit a trouble ticket.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/JetpackStagingSite2.png"><img class="size-full wp-image-48164" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/JetpackStagingSite2.png?resize=1025%2C143" alt="Jetpack double checking to see if two URLs are separate sites" /></a>Jetpack double checking to see if two URLs are separate sites
<p>The VideoPress player in Jetpack 3.7 works on mobile devices thanks to its responsive redesign. Having VideoPress enabled allows you to easily embed VideoPress powered videos to your site by copying and pasting the video&#8217;s URL into the visual editor.</p>
<p>Here are a few other changes included in 3.7:</p>
<ul>
<li>The ability to enable per-post opt-out for Subscriptions by <a href="http://jetpack.me/support/subscriptions/#filters">adding a filter</a> to a functionality plugin.</li>
<li>A new Widget Visibility rule that allows you to show or hide widgets based on a page’s parent.</li>
<li>Sharing buttons now display on bbPress forum posts</li>
</ul>
<p>Jetpack 3.7 is <a href="https://wordpress.org/plugins/jetpack/">available for free</a> from the WordPress plugin directory. To view a list of all the changes in this release, <a href="https://wordpress.org/plugins/jetpack/changelog/">check out the changelog</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Sep 2015 04:41:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:94:"WPTavern: A Conceptual WordPress Plugin by Stephen Cronin That Makes Comment Moderation Easier";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48149";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:104:"http://wptavern.com/a-conceptual-wordpress-plugin-by-stephen-cronin-that-makes-comment-moderation-easier";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2409:"<p>Moderating replies to comments in the backend of WordPress is tough. For example, WordPress 4.3 displays the reply and who it&#8217;s in response too, but doesn&#8217;t show the text of the parent comment.</p>
<p>You can&#8217;t see the parent comment unless you open the author link in a new browser tab. This is not an optimal user experience and makes it more difficult to determine if the reply is from a spammer.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/WordPress43CommentContent.png"><img class="size-full wp-image-48150" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/WordPress43CommentContent.png?resize=851%2C161" alt="WordPress 4.3 Comment Content Area" /></a>WordPress 4.3 Comment Content Area
<p><a href="https://wordpress.org/plugins/show-parent-comment/">Show Parent Comment</a> by Stephen Cronin, founder of <a href="http://scratch99.com/">Scratch99 Design</a>, is a potential solution to the problem. Simply activate and browse to the comment section of the WordPress backend.</p>
<p>Show Parent Comment displays the text of the parent comment inside the reply. This helps moderators keep track of the conversation and helps to identify copy/paste spammers.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/ShowParentCommentPlugin.png"><img class="size-full wp-image-48151" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/ShowParentCommentPlugin.png?resize=847%2C223" alt="Show Parent Comment Plugin" /></a>Easy Way to See The Parent Comment
<p>While the plugin works as advertised and shows the parent comment text, the interface needs to be improved. I&#8217;m not a fan of the background color and some of the comment information is repeated.</p>
<p>One idea is to replace the <strong>In Reply to Author</strong> text to say, <strong>In Response To</strong>. The show more or less button is a good idea but I think the text size needs to be increased.</p>
<p>Although Show Parent Comment is available on the <a href="https://wordpress.org/plugins/show-parent-comment/">plugin directory for free</a>, it&#8217;s a proof of concept and is not officially supported by Cronin.</p>
<p>The concept needs work but I think something similar needs to be added to WordPress core. As it stands, moderating comment replies is not a great experience and I think Cronin&#8217;s plugin is a step in the right direction.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Sep 2015 22:12:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WPTavern: WPML Emails Passwords to Affected Customers in Plaintext";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48123";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://wptavern.com/wpml-emails-passwords-to-affected-customers-in-plaintext";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3791:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ClearTextPasswordFeaturedImage.png"><img class="size-full wp-image-31477" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ClearTextPasswordFeaturedImage.png?resize=637%2C200" alt="Clear Text Password" /></a>photo credit: <a href="https://www.flickr.com/photos/thegloaming/1402099967/">thegloaming</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a>Customers who purchased <a href="https://wpml.org/">WPML</a>, a multilingual plugin for WordPress, <a href="https://wpml.org/forums/topic/strange-email-from-wpml/#post-699832">are receiving</a> a suspicious email that looks similar to a phishing attempt. Matt Radford, a customer of WPML, kindly sent the Tavern a copy of the email.</p>
<blockquote><p><b>Dear Matt</b>,</p>
<p>We want to make sure that your WPML account remains secure. For this, we are updating all client accounts with auto-generated strong passwords. A strong password helps prevent unauthorized use of your WPML account.</p>
<p>Our system will start the password update shortly. We will send you another email with your new password.</p>
<p>All the best,</p>
<p><b>WPML team</b></p></blockquote>
<p>Radford received a follow-up email that includes his new password in plaintext. WPML explains why the passwords were sent in plaintext, &#8220;We detected weak passwords in our system and following this we are enforcing, on a one-time procedure, strong passwords to all our clients.</p>
<p>&#8220;As for sending them in plaintext, if you consider it not to be safe, please update your password in order to keep it secure,&#8221; WPML said.</p>
<p>When questioned if passwords are stored in plaintext within the database, WPML replied, &#8220;As for storing passwords in our database we are not storing it in plaintext, we are using standard WordPress. Yes they&#8217;re salted and hashed.&#8221;</p>
<p>Denise VanDeCruze, a WPML support forum moderator, says <a href="https://wpml.org/forums/topic/strange-email-from-wpml/#post-700143">the email was generated automatically</a> from their systems. She confirms that sending passwords in plaintext is not a best practice and urges users to login to their accounts and generate a new password using the reset password link.</p>
<blockquote><p>This email was automatically generated by our system and sent to clients with passwords that were deemed too simple. However, sending new passwords in plain text via email without requiring user action is not best practice. I urge you to change your WPML account password. <a href="https://wpml.org/account/account-settings/" rel="nofollow">https://wpml.org/account/account-settings/</a></p>
<p>You were right to be cautious of this sudden email. Although it was not a phishing attempt, it was not the best way to ensure a safe password. In the future we will be mindful of adhering to strict security standards. Please let me know if you have any further questions.</p></blockquote>
<p>WPML has not published any information on <a href="https://wpml.org/blog/">its blog</a> that explains the situation and has yet to respond to our requests for comment. If you&#8217;re a WPML customer and receive an email with a new password, you should immediately login and generate a new password using the site&#8217;s reset password link and follow the instructions.</p>
<p>Emailing passwords in plaintext is a terrible security practice. One of the key improvements in WordPress 4.3 is that <a href="https://make.wordpress.org/core/2015/07/28/passwords-strong-by-default/">WordPress no longer emails passwords</a>. Instead, it sends password reset links that expire after 24 hours. In hindsight, WPML should have generated and sent password reset emails to affected customers.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Sep 2015 23:54:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"Post Status: Using React with WordPress — Draft podcast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"https://poststatus.com/?p=14241";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://poststatus.com/using-react-with-wordpress-draft-podcast/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2161:"<p>Welcome to the Post Status Draft podcast, which you can find <a href="https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008">on iTunes</a> and <a href="http://simplecast.fm/podcasts/1061/rss">via RSS</a> for your favorite podcatcher. Brian and his co-host, <a href="https://twitter.com/joe_hoyle">Joe Hoyle</a>, a co-founder and the CTO of <a href="https://hmn.md/">Human Made</a>, discuss some of today&#8217;s hottest, current WordPress news.</p>
<p>Listen now:</p>
<a href="https://audio.simplecast.fm/16368.mp3">https://audio.simplecast.fm/16368.mp3</a>
<p><a href="http://audio.simplecast.fm/16368.mp3">Direct download</a></p>
<p>Stories discussed:</p>
<ul>
<li><a href="https://poststatus.com/notes/language-packs-for-wordpress-themes-and-plugins/">Language packs background and details</a> (members only)</li>
<li><a href="https://make.wordpress.org/plugins/2015/09/01/plugin-translations-on-wordpress-org/">Plugin translation details</a></li>
<li><a href="https://translate.wordpress.org/">WordPress.org sub-site for translations of WordPress, plugins, and themes</a></li>
<li><a href="https://make.wordpress.org/core/2015/09/01/lets-garden-trac/">Trac gardening</a></li>
<li><a href="http://facebook.github.io/react/">ReactJS</a></li>
<li><a href="https://www.youtube.com/channel/UCorlLn2oZfgOJ-FUcF2eZ1A">React Europe talks</a></li>
<li><a href="https://github.com/rackt/redux">Redux framework</a></li>
<li><a href="https://webpack.github.io/">Web Pack</a></li>
<li><a href="https://ustwo.com/">USTwo site in React with a WordPress backend</a></li>
<li><a href="https://loopconf.io/talks/react-flux-wordpress-developers/">Loopconf talk on React and Flux</a></li>
<li><a href="https://nomadbase.io/location-update/">Nomadbase React app</a></li>
<li><a href="https://deliciousbrains.com/creating-mobile-app-wp-api-react-native/">React and the WP API for a native app</a></li>
<li><a href="http://feelingrestful.com/">A Day of Rest: a WordPress REST API conference</a></li>
<li><a href="https://poststatus.com/a-day-of-rest-a-conference-devoted-to-the-wordpress-rest-api/">Details for A Day of REST</a></li>
</ul>
<p>&nbsp;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 05 Sep 2015 14:19:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Katie Richards";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: Help Me Add Comment Approval Notifications to WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48059";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wptavern.com/help-me-add-comment-approval-notifications-to-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1094:"<p>Since <a href="http://wptavern.com/the-wp-tavern-comment-moderation-policy">enabling comment moderation</a> on the Tavern, I&#8217;ve discovered that WordPress does not notify commenters when their comments are approved.</p>
<p>On the Tavern, I&#8217;m using the <a title="http://wordpress.org/plugins/comment-approved/" href="http://wordpress.org/plugins/comment-approved/">Comment Approved</a> plugin by <a title="http://media-enzo.nl/" href="http://media-enzo.nl/">Niels van Renselaar</a>. It allows me to create a custom notification message that is sent when a comment is approved. Unfortunately, I don&#8217;t think it&#8217;s working. Please let me know if you&#8217;ve received any comment approval emails from the Tavern.</p>
<p>I strongly believe this feature should be in core. I&#8217;ve started the process by creating a <a href="https://core.trac.wordpress.org/ticket/33717">feature request ticket</a> on WordPress trac. Let&#8217;s discuss the pros and cons or why you think it shouldn&#8217;t be in core. Please give me your feedback in the comments or within the ticket.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 04 Sep 2015 19:30:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:83:"WPTavern: How Chris Klosowski’s Lifestyle Changed by Writing One WordPress Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48051";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://wptavern.com/how-chris-klosowskis-lifestyle-changed-by-writing-one-wordpress-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1458:"<p>Chris Klosowski, co-lead developer of Easy Digital Downloads, <a href="https://kungfugrep.com/2015/09/how-writing-one-plugin-changed-my-lifestyle/">explains how writing one plugin</a> changed his lifestyle. He left his corporate job to be a full-time distributed worker and being a distributed worker comes with its own set of challenges.</p>
<blockquote><p>My truest challenge in this new lifestyle is knowing when it’s time to ignore Slack, shut off email, take off the Pebble, and just spend time with my family. It’s a challenge I’m learning to face, and the hardest part is admitting to myself that it’s a problem.</p>
<p>It’s come up in conversation a couple times with my wife, and every time, she lets me know when I’m failing. Honesty here is the key. Not guilt, not anger, just brutal honesty of when I’m not being the best husband and dad because I’m putting work before them.</p></blockquote>
<p>One of the greatest challenges a distributed worker faces is figuring out the balance between work, family, and personal life. If you&#8217;re struggling to find balance, I encourage you to read <a href="http://wptavern.com/the-mantra-of-family-comes-first">this post</a> and the nearly 100 comments that follow.</p>
<p>The comments are from people in similar positions trying to figure out how to balance work, life, and family. After nearly three years of being a distributed worker, I&#8217;m still trying to figure it out.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 04 Sep 2015 16:43:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: A Bug in Chrome 45 Causes WordPress Admin Menu to Break";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48045";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wptavern.com/a-bug-in-chrome-45-causes-wordpress-admin-menu-to-break";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2136:"<p>Within the last five weeks, <a href="https://core.trac.wordpress.org/ticket/33199">several people have reported</a> an issue in Chrome that breaks the WordPress admin menu. If you hover the mouse cursor over menu items in the sidebar, they&#8217;ll occasionally fall out-of-place.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/09/ChromeWPAdminMenu.png"><img class="aligncenter size-full wp-image-48046" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/09/ChromeWPAdminMenu.png?resize=764%2C543" alt="Chrome WordPress Admin Menu " /></a>Using Chrome 45.0.2454.85, I&#8217;m able to inconsistently reproduce the behaviour reported in the ticket. Through the process of elimination, users discovered Chrome is the software at fault and not WordPress.</p>
<p>The <a href="https://code.google.com/p/chromium/issues/detail?id=509179#c17">source of the problem</a> stems from Slimming Paint which is enabled by default in Chrome 45. Disabling slimming paint fixes the issue.</p>
<p>To disable this feature, visit <strong>chrome://flags/#disable-slimming-paint</strong> in Chrome and <strong>Enable</strong> the <em>Disable slimming paint</em> option, and make sure the other two <strong>Enable</strong> options are disabled because they will override the Disable option.</p>
<p>If this sounds confusing, please refer to the following screenshot provided by Samuel Wood.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/DisableSlimmingPaint.png"><img class="size-full wp-image-48056" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/DisableSlimmingPaint.png?resize=839%2C185" alt="Disable Slimming Paint Options" /></a>Disable Slimming Paint Options
<p>Chrome&#8217;s development team is <a href="https://code.google.com/p/chromium/issues/detail?id=509179&q=label%3AM-47%20slimming%20paint&colspec=ID%20Pri%20M%20Stars%20ReleaseBlock%20Cr%20Status%20Owner%20Summary%20OS%20Modified">aware of the issue</a> and is working towards a solution that is marked for release in Chrome 47. Until then, users are encouraged to disable Slimming Paint until Chrome fixes the issue.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 04 Sep 2015 15:49:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"WPTavern: A Dashboard Widget That Displays New Registered Users";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48037";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wptavern.com/a-dashboard-widget-that-displays-new-registered-users";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1119:"<p>If you run a WordPress site with user registration enabled and want to see recently registered accounts from the dashboard, check out the <a href="https://wordpress.org/plugins/new-user-dashboard/">New User Dashboard Widget plugin</a> by <a href="https://profiles.wordpress.org/swadeshswain/">Swadeshswain</a>. After installing and activating the plugin, a new registered user widget appears on the dashboard.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/NewUserDashboardWidget.png"><img class="size-full wp-image-48038" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/09/NewUserDashboardWidget.png?resize=536%2C146" alt="New Registered User Widget" /></a>New Registered User Widget
<p>The widget tells you a user&#8217;s registration date, name, and role. If you don&#8217;t see the widget after activating the plugin, click on the Screen Options tab and make sure the box next to New User is checked. New User Dashboard Widget is the type of plugin that does one thing only and does it well. There&#8217;s nothing to configure and it works out-of-the-box with WordPress 4.3.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 04 Sep 2015 00:02:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:92:"WPTavern: Proposal to Overhaul the Shortcode API in WordPress Goes Back to the Drawing Board";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48026";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:102:"http://wptavern.com/proposal-to-overhaul-the-shortcode-api-in-wordpress-goes-back-to-the-drawing-board";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:7118:"<p><a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, who contributes to WordPress core, <a href="https://make.wordpress.org/core/2015/09/02/shortcode-roadmap-draft-one/">published the first draft</a> of a roadmap that explains how the Shortcode API could be overhauled. &#8220;The decision to create this roadmap arose from specific needs that are not met by the old code,&#8221; Chapin said.</p>
<p>The proposal has an aggressive timeline with development starting in WordPress 4.4 and ending in WordPress 4.7. In WordPress 4.4, a new syntax would be introduced that provides opportunities to make significant changes to the API.</p>
<p>Here are a few examples of shortcodes that use the new syntax.<br />
<strong>Self-Closing</strong>: [{{shortcode}}]</p>
<p><strong>Attributes</strong>: [{{shortcode attr1=&#8221;value1&#8243; attr2=&#8217;value2&#8242; &#8220;value3&#8221; &#8216;value4&#8217; value5}}]</p>
<p><strong>Enclosing</strong>: [{{shortcode}$] HTML [${shortcode}}]</p>
<p><strong>Multiple Enclosures</strong>: [{{shortcode}$] HTML [${encl2}$] HTML [${encl3}$] HTML [${shortcode}}]</p>
<p><strong>Escaped Code</strong>: [!{{shortcode}}]</p>
<p>In the WordPress 4.5 development cycle, the focus would be to deprecate the old syntax, &#8220;Plugins that register shortcodes without declaring support for new features will raise debugging errors to alert developers that support for the old shortcode syntax is ending,&#8221; Chapin said. Posts using the old syntax would  continue to work.</p>
<p>During the WordPress 4.6 update process, shortcodes using the old syntax would be converted to use the new syntax. The Shortcode API would continue to provide deprecated support for the old syntax to provide a smooth transition.</p>
<p>An important point to note is that the new syntax does not support HTML inside of shortcode attributes. This leaves the potential for many sites to break as shortcodes may not perform the same way prior to WordPress 4.6</p>
<p>The transition process ends with WordPress 4.7 where support for the old syntax is eliminated. Shortcodes and plugins that use the old syntax would stop working. During the WordPress 4.7 update process, a second attempt would be made to upgrade old content to use the new syntax.</p>
<h2>The Proposal Raises Concerns</h2>
<p>The proposal has drawn constructive criticism from several members of the WordPress community. Nick Haskins, founder of Aesop Interactive, <a href="https://make.wordpress.org/core/2015/09/02/shortcode-roadmap-draft-one/#comment-27426">voiced his concern</a> saying the syntax isn&#8217;t easier for authors to use and will affect a large number of sites.</p>
<p><a href="http://halfelf.org/">Mika Epstein</a>, who voluntarily moderates the WordPress.org support forums and interacts with users on a daily basis, <a href="https://make.wordpress.org/core/2015/09/02/shortcode-roadmap-draft-one/#comment-27472">sums up a list of concerns</a> that many developers agree with.</p>
<blockquote>
<ul>
<li>All the plugins and themes on the planet we will break (because we will, they won’t read or test). We have to degrade them as gracefully as humanly possibly. Continuing to say “Well the developers were notified and should have updated” now that we’re as big as we are is not sustainable.</li>
</ul>
<ul>
<li>All the very (legitimately) angry end users who are broken because they didn’t upgrade plugins and themes (or the themes/plugins didn’t get updated). People were rightly angry last time. It’s the end users, not the developers, who will be hardest hit by this change.</li>
</ul>
<ul>
<li>Communicating clearly to the users that it’s now <code>{{gallery}}</code>. That’s going to be very hard. Incredibly hard. Updating their old posts (keeping in mind Justin’s Markdown caveat and those who use them as an aside – I know I know) is easier than making sure everyone knows what to do. At best we can keep tabs on the ones built into WP and perhaps use the logic we have in the visual editor NOW to convert them, but we have to figure out how to make sure everyone knows. This is nothing like the move of Menus to customizer. That was confusing, but the users could see what happened. This is a legit change, your old way is no longer going to work. That is huge.</li>
</ul>
<ul>
<li>The number of users who have premium themes and plugins that <em>do not</em> get update alerts. These people are simply not going to know they need to update and this is not their fault. We should never be breaking them if there’s possibly any alternative.</li>
</ul>
<ul>
<li>Users will be upgraded by their hosts vis-a-vis one-click installs and managed hosting so they will have up to date WP and out of date plugins/themes. So yes, many users will be on 4.7 and then a theme from 2014. It sucks, it’s the reality, we know it’s the reality, we cannot stick our heads in the sand.</li>
</ul>
<ul>
<li>Plugins that are already using {{template}} tags in their code. Yeah, I’ve seen it. Most of them use it for search/replace within their own code, but we’ll want to make sure we check for everyone in the repo who might be doing it on their own.</li>
</ul>
</blockquote>
<p>The best argument against using the new shortcode syntax is <a href="https://make.wordpress.org/core/2015/09/02/shortcode-roadmap-draft-one/#comment-27518">made by Stefano Agiletti.</a> Agiletti says Italian keyboards don&#8217;t have keys that create curly braces.</p>
<blockquote><p>Maybe English people don’t know that { and } are not present in all keyboards directly as the [ and ] are. On Italian keyboards [ and ] are generated using ALT-GR+è or ALT-GR++ and keyboards show ALT-GR basic sign like €@## and [ ].</p>
<p>To get { and } you need to type ALT-GR+SHIFT+è and ALT-GR+SHIFT++. Most people don’t know about this combination (I think only those who write code do) and the parentheses are not written on any key.</p></blockquote>
<h2>Back to the Drawing Board</h2>
<p>After a considerable amount of feedback and concerns shared by developers, the proposal is heading back to the drawing board. In a comment <a href="https://make.wordpress.org/core/2015/09/02/shortcode-roadmap-draft-one/#comment-27484">summarizing the feedback</a>, Andrew Nacin confirms that the new shortcode syntax does not fit the core team&#8217;s vision of being easy and intuitive for non-technical authors to use.</p>
<p>At the same time, he cautions that the team needs to do something, &#8220;The proposed syntax significantly clashes with the proposed vision and given all of your feedback, we’re clearly going to have to go back to the drawing board. Please note that <strong>we still need to do something</strong>, but maybe we can think further outside the box.&#8221;</p>
<p>I highly encourage you to read the <a href="https://make.wordpress.org/core/2015/09/02/shortcode-roadmap-draft-one/">proposal and the comments</a> that follow it. It&#8217;s a great read that highlights how difficult it will be to make changes to the Shortcode API that don&#8217;t end up causing a lot of sites to break.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 03 Sep 2015 21:16:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: WPWeekly Episode 206 – Stream Reverts to its Old Ways";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48018";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wptavern.com/wpweekly-episode-206-stream-reverts-to-its-old-ways";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2645:"<p>In this week&#8217;s episode of WordPress Weekly, <a href="http://marcuscouch.com/">Marcus Couch</a> and I discuss the news of the week including, Envato&#8217;s new item support policy, Twenty Sixteen available on GitHub, and BuddyPress 2.3.3. We also discuss Stream 3 which returns to hosting activity logs on the local server. We end the show with Marcus&#8217; plugin picks up the week.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/envato-implements-item-support-policy-for-themeforest-and-codecanyon">Envato Implements Item Support Policy for ThemeForest and CodeCanyon</a><br />
<a href="http://wptavern.com/twenty-sixteen-now-available-on-github-and-the-wordpress-theme-directory">Twenty Sixteen Now Available on GitHub and the WordPress Theme Directory</a><br />
<a href="http://wptavern.com/buddypress-2-3-3-patches-security-vulnerabilities-in-buddypress-messages-component">BuddyPress 2.3.3 Patches Security Vulnerabilities in BuddyPress Messages Component</a><br />
<a href="http://wptavern.com/wordpress-community-summit-set-for-december-2-3-2015">WordPress Community Summit Set for December 2-3, 2015</a><br />
<a href="http://wptavern.com/stream-is-shutting-down-its-cloud-data-storage-october-1st">Stream Is Shutting Down Its Cloud Data Storage October 1st</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href="https://wordpress.org/plugins/new-user-dashboard/">New User Dashboard Widget</a> is a dashboard widget that shows new registered members.</p>
<p><a href="https://wordpress.org/plugins/facebook-secret-meta/">Facebook Secret Meta</a> adds the necessary secret codes to your site, so when someone shares a link to your site on Facebook, they&#8217;ll see the site&#8217;s information and the new <strong>Author By</strong> data.</p>
<p><a href="https://wordpress.org/plugins/bp-automatic-friends/">BuddyPress Automatic Friends</a> automatically creates and accepts friendships for specified users upon new user registration.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, September 9th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #206:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 03 Sep 2015 08:21:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WPTavern: The WP Tavern Comment Moderation Policy";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=48012";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wptavern.com/the-wp-tavern-comment-moderation-policy";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3471:"<p>Those of you who regularly comment on the Tavern may have noticed that your comments don&#8217;t show up immediately after submitting them. That&#8217;s because about four weeks ago, for the first time in the Tavern&#8217;s history, comment moderation for all comments was enabled. I enabled moderation to address concerns raised by members of the community and to sleep better at night.</p>
<p>At the request of a few readers and to be more transparent, I&#8217;ve created a <a href="http://wptavern.com/comment-policy">comment moderation policy</a>. With the help of at least a dozen people, I&#8217;ve crafted a policy that is easy to read and more importantly, easy to follow. It explains our expectations, has a few tips on writing better comments, and lists possible reasons a comment may be deleted.</p>
<p>The policy is <a href="http://creativecommons.org/publicdomain/zero/1.0/">CC0 licensed</a> which is the least restrictive license offered by Creative Commons. Feel free to copy and modify it for your own use.</p>
<h2 class="font-headlines">WP Tavern Comment Moderation Policy</h2>
<p>We strive to create a fun, friendly, and inviting atmosphere. The ground rules for commenting on WP Tavern are simple. Treat people the way you want to be treated. Try to understand someone else’s perspective and if you disagree, respectfully explain why.</p>
<p>Text is a difficult medium to decipher context. Emoticons and emoji help, but it doesn’t solve the problem. Take a deep breath and assume the commenter has the best of intentions before responding and approach discussions with open minds.</p>
<p>We welcome different perspectives and viewpoints but we all need to clearly communicate them without tearing the opposition down in the process.</p>
<p>Stay on point using concise language. If your comment is more than a few paragraphs long, consider publishing it on your own site instead.</p>
<p>Your comment may be deleted if it matches any of the following criteria:</p>
<ul>
<li>Advocates an illegal practice</li>
<li>Uses vulgar, profane, or unnecessarily harsh language</li>
<li>Is spam or appears to be written primarily to post a link or advertise</li>
<li>Is written anonymously</li>
<li>Contains copyrighted material not licensed for distribution on the site</li>
<li>Impersonates another user</li>
<li>Contains an affiliate link</li>
<li>Personal insults, including those using racist or sexist terms.</li>
</ul>
<p>These guidelines are not meant to be an exhaustive list. The deletion of comments is wholly within the discretion of the moderators at WP Tavern and we will err on the side of maintaining a safe and friendly community.</p>
<h2 class="font-headlines">How Do I Report Comments?</h2>
<p>If you believe a comment published on WP Tavern violates any of the listed guidelines or that you feel needs special attention, <a href="http://wptavern.com/contact-me">contact us</a>. Please do not publicly report comments using social media such as Facebook or Twitter.</p>
<p>Form submissions are sent to authors with comment moderation capabilities. Include a link to the comment in your email with a short explanation as to why it needs our attention.</p>
<h2>The Goal</h2>
<p>The goal is to reestablish the comment section as a place where people feel welcome to voice their opinions without the fear of being ripped apart. We encourage criticism, disagreements, and open conversation but it needs to take place in a respectful manner.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 03 Sep 2015 06:36:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"Post Status: A Day of REST — a conference devoted to the WordPress REST API";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"https://poststatus.com/?p=14173";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"https://poststatus.com/a-day-of-rest-a-conference-devoted-to-the-wordpress-rest-api/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6733:"<p><a href="http://feelingrestful.com/">A Day of REST</a> will be the first ever event dedicated to the WordPress REST API. It&#8217;ll happen on January 28th 2016, with a follow-on hack day on the 29th, and will be held at Bishopsgate Institute in London, UK.</p>
<p>The event is aimed at developers who want to learn how to interact with the new WordPress REST API. From WordPress developers to Javascript developers, to application developers, A Day of REST promises to provide in-depth information that covers every aspect of the WordPress REST API.</p>
<p>This is exactly the kind of event I&#8217;ve been hoping to see in the WordPress community. Sessions will vary from an introduction to the WordPress REST API to in-depth case studies and guides on utilizing it in the real world.</p>
<p>It will be an incredible and rare opportunity to learn from the people making the API and those extending it further than anyone else. A niche event to be sure, A Day of REST  is a big bet on the WordPress REST API &#8212; which is not yet slated for core, but is widely expected to make it to core in the next few releases.</p>
<p>The conference is being organized to supply a clear demand for more information, resources, and education on the subject. At most WordCamps, REST API sessions seem to be some of the most crowded, with the most engaged and curious audiences. A Day of REST will be like those sessions, but much bigger, as the entire day will be dedicated to the single topic.</p>
<h3>Who is speaking at A Day of REST</h3>
<p><img class="aligncenter size-large wp-image-14179" src="https://cdn.poststatus.com/wp-content/uploads/2015/09/speakers-day-of-rest-752x603.jpg" alt="speakers-day-of-rest" width="752" height="603" /></p>
<p>The speaker roster consists of people who are building the WordPress REST API, and those who are already using it for production applications and websites. The speakers are:</p>
<ul>
<li>Ryan McCue &#8211;  WordPress REST API co-lead</li>
<li>Joe Hoyle &#8211; WordPress REST API team</li>
<li>Daniel Bachhuber &#8211; WordPress REST API team</li>
<li>Kathleen Vignos &#8211; Director of Engineering, WIRED</li>
<li>K. Adam White &#8211; Open Web Engineer, Bocoup</li>
<li>Jack Lenox &#8211; Design Engineer, Automattic</li>
<li>Scott Taylor &#8211; Senior Engineer, New York Times</li>
<li>Nikolay Bachiyski &#8211; Meta Engineer, Automattic</li>
</ul>
<h3>Post Status will be an official partner</h3>
<p>I&#8217;m really pleased that Post Status will be the official content partner for A Day of REST. That means I’ll be attending the event, and I&#8217;ll offer a number of in-depth posts related to the WordPress REST API, the sessions, interviews, and more.</p>
<p>I&#8217;ll also manage content for some of the larger event announcements, like this one. I&#8217;ve known the organizers for a long time, and they are big supporters of Post Status. A Day of REST offers a really great opportunity for me to work with them and offer my readers some unique privileges and exclusive content for a subject that&#8217;s of interest to most of my audience.</p>
<h3>So who is organizing?</h3>
<p><img class="aligncenter size-large wp-image-14180" src="https://cdn.poststatus.com/wp-content/uploads/2015/09/humans-752x333.jpg" alt="humans" width="752" height="333" /></p>
<p>A Day of REST is organized by <a href="https://poststatus.com/organizations/human-made/">Human Made</a>, who’ve brought on board <a href="http://siobhanmckeown.com/about/">Siobhan McKeown</a> to lead the charge putting the event together.</p>
<p>Human Made uses the API in a good bit of their services and product work, are really interested to see more adoption of the API, and are eager to provide education resources so that can happen. Those of you who pay close attention may know that two of Human Made&#8217;s own are actually part of the team of four that does much of the REST API development.</p>
<p><a href="https://twitter.com/rmccue">Ryan McCue</a> is the project co-lead, and is generally steering the ship; the API started as his GSoC (Google Summer of Code) project years ago. <a href="https://twitter.com/joe_hoyle">Joe Hoyle</a> is in day to day conversations for project direction and also commits a lot of code to the API; he is a co-founder of Human Made.</p>
<h3>Hack Day</h3>
<p>On 29th January 2016, there will be a WordPress REST API hack day. This event is being hosted by Mozilla Spaces in London. Space for the hack day is limited but the team would love for anyone interested to come along and help make the WordPress REST API. Bring a laptop and expect to get hacking. This event will be for building the REST API specifically, and not geared toward other projects.</p>
<h3>Ticket details</h3>
<p>Tickets are available <a href="http://feelingrestful.com/tickets/">from the website</a>. They’re £125 (+ VAT &amp; booking fees) &#8212; which ends up being around $235 US &#8212; and the price includes all of the usual conference goodies: presentations, lunch, swag, and an informal afterparty.</p>
<h3>Confirmed sponsors</h3>
<p>A Day of REST is excited to already have some awesome sponsors on board.</p>
<ul>
<li><a href="http://prospress.com/">ProsPress</a> &#8211; Gold sponsor</li>
<li><a href="http://www.gravityforms.com/">Gravity Forms</a> &#8211; Gold sponsor</li>
<li><a href="https://sucuri.net/">Sucuri</a> &#8211; Gold sponsor</li>
</ul>
<p>The team is also looking for more sponsors to get involved and help make this unique event happen. If you’d like to sponsor, send an email to events@humanmade.co.uk.</p>
<h3>More information</h3>
<p>Depending on the content, you can get updates either from this blog, or from the A Day of REST website, <a href="http://feelingrestful.com/">feelingrestful.com</a>. You should also follow <a href="https://twitter.com/feelingrestful">@feelingrestful</a> on Twitter for live updates. I&#8217;ll have in-depth content and broader event information and the event site will have more general announcements, news, and event updates.</p>
<p>London is quite accessible from much of the world, so I am hopeful and confident that there will be a diverse audience in attendance. I certainly look forward to visiting; and I was pleasantly surprised that it doesn&#8217;t get as cold there as I thought; January temperatures (lows and highs) stay around the 40s (F, or 5-9<strong><span class="temperature_label_default"><span class="temperature_label_unit_c">°</span></span></strong> C) &#8212; which is likely warmer than it&#8217;ll be where I live in January.</p>
<p>A Day of REST is an exciting development in the WordPress conference ecosystem and I&#8217;m confident it&#8217;s going to be a huge success.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 02 Sep 2015 13:36:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WPTavern: Envato Implements Item Support Policy for ThemeForest and CodeCanyon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47990";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://wptavern.com/envato-implements-item-support-policy-for-themeforest-and-codecanyon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3537:"<p>In August of 2014, Envato <a href="http://marketblog.envato.com/news/item-support-sustainability-authors-clarity-buyers/">announced a new initiative</a> that would allow sellers on <a href="http://codecanyon.net/?_ga=1.16356721.691392842.1429566039">CodeCanyon</a> and <a href="http://themeforest.net/?_ga=1.16356721.691392842.1429566039">ThemeForest</a> to inform buyers whether or not an item is supported. Earlier today, <a href="http://marketblog.envato.com/releases/item-support-policy-and-functionality-launched/">Envato implemented</a> an <a href="http://themeforest.net/page/item_support_policy">Item Support Policy</a> for sellers on ThemeForest and CodeCanyon.</p>
<p>When browsing items on ThemeForest or CodeCanyon, a blue badge indicates the seller provides support. There&#8217;s also a badge and text that informs potential buyers if an item is not supported.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/SupportedBadge.png"><img class="size-full wp-image-47991" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/09/SupportedBadge.png?resize=639%2C408" alt="This Item is Supported" /></a>This Item is Supported
<p>According to <a href="http://themeforest.net/page/item_support_policy">the policy</a>, buyers automatically receive six months of support from the date of purchase. If you need support for an entire year, you can buy an extension for a nominal upgrade fee. Envato takes 30% and gives 70% of the purchase to authors.</p>
<p>The price of a <b>6-month support extension</b> for a <b>Regular License</b> is calculated as:</p>
<ol>
<li>37.5% of the item price (30% of the list price) when purchased at the same time as the license;</li>
<li>62.5% of the item price (50% of the list price) when purchased during the support period; and</li>
<li>87.5% of the item price (70% of the list price) when purchased after the support period has ended.</li>
</ol>
<p>Andrew Freeman, product manager for Envato, says the changes provide a standardized definition of support, &#8220;Buyers will know exactly what to expect from all purchases on ThemeForest and CodeCanyon.&#8221;</p>
<p>Buyers who purchased supported items before the new policy went into effect have six months of free tech support starting on September 1st.</p>
<h2>Disgruntled Authors</h2>
<p>In a <a href="https://forums.envato.com/t/item-support-policy-and-functionality-launched/3619">forum thread</a> with over 165 responses, sellers discussed the pros and cons of the policy while some expressed anger. <a href="http://themeforest.net/user/jonathan01">Jonathan Atkinson</a>, founder of <a href="https://cr3ativ.com/">Cr3ativ</a>, who sells several items on ThemeForest, thinks the policy is not as good as alternatives offered outside of the marketplaces because of its confusing complexity for both authors and buyers,</p>
<blockquote><p>I&#8217;m not sure why Envato chose this solution when we already have a well established support/upgrade system in place within most of the WordPress community where 12 months of support is included in the purchase and customers receive a 50% discount to continue receiving support and updates.</p></blockquote>
<p>The policy is a work in progress, &#8220;We will be monitoring the impacts of this change very closely and will be tweaking, improving and enhancing the support tools over coming weeks and months,&#8221; Freeman said.</p>
<p>If you&#8217;re a buyer or seller on ThemeForest or CodeCanyon, let us know what you think of the support policy in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 02 Sep 2015 00:52:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Matt: On VentureBeat Podcast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45294";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://ma.tt/2015/08/on-venturebeat-podcast/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:303:"<p>I was on VentureBeat&#8217;s podcast with Dylan Tweeney, <a href="http://venturebeat.com/2015/08/11/how-matt-mullenweg-built-wordpress-into-a-giant-platform-powering-14-of-the-web-podcast/">talking a bit about how WordPress came to be and geeking out on some of the tech behind our approach</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 01 Sep 2015 02:23:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WPTavern: Twenty Sixteen Now Available on GitHub and the WordPress Theme Directory";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47973";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://wptavern.com/twenty-sixteen-now-available-on-github-and-the-wordpress-theme-directory";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2332:"<p>Twenty Sixteen, the default theme scheduled to ship with WordPress 4.4, is available for download on <a href="https://github.com/WordPress/twentysixteen">GitHub</a> and the <a href="https://wordpress.org/themes/twentysixteen/">WordPress theme directory</a>. According <a href="https://make.wordpress.org/core/2015/08/29/twenty-sixteen-is-now-on-github/">to Tammie Lister</a>, Twenty Sixteen will be developed as if it were a feature plugin and will merge into WordPress core later this year.</p>
<p>As development takes place on GitHub, changes will regularly sync up to the WordPress theme directory. By installing and activating Twenty Sixteen from the theme directory, users can easily update to new versions as they become available.</p>
<p>So far, Twenty Sixteen has 23 issues and 27 pull requests on GitHub. Many of the issues such as, <a href="https://github.com/WordPress/twentysixteen/pull/23">introducing automated Travis CI build testing into Twenty Sixteen,</a> are <a href="https://github.com/WordPress/twentysixteen/labels/discussion">up for discussion</a>.</p>
<p>Here is what the top half of the Tavern looks like with Twenty Sixteen activated.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/08/TavernOnTwentySixteen.png"><img class="size-full wp-image-47974" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/08/TavernOnTwentySixteen.png?resize=1025%2C563" alt="Twenty Sixteen on the Tavern" /></a>Twenty Sixteen on the Tavern
<p>Here is what the content section looks like. Notice the block of code that displays instead of an image.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/TavernContentOnTwentySixteen.png"><img class="size-full wp-image-47976" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/TavernContentOnTwentySixteen.png?resize=881%2C648" alt="Content on the Tavern with Twenty Sixteen " /></a>Content on the Tavern with Twenty Sixteen Activated
<p>Testers are encouraged to open issues and pull requests on GitHub. If you&#8217;re not familiar with how GitHub works, <a href="https://github.com/WordPress/twentysixteen/blob/master/CONTRIBUTING.md">this guide</a> explains how to contribute to the Twenty Sixteen project. Keep in mind that Twenty Sixteen is a work in progress and should not be used in a production environment.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 31 Aug 2015 20:05:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Matt: Rigamortis Cover";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45313";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:38:"http://ma.tt/2015/08/rigamortis-cover/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:267:"<p><span class="embed-youtube"></span></p>
<p>Great jazz cover of one of my favorite Kendrick Lamar songs, Rigamortis, which of course is inspired by the great jazz song <a href="https://www.youtube.com/watch?t=27&v=TstRwZygLAo">The Thorn by Willie Jones III</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 29 Aug 2015 03:33:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"Post Status: Our WordPress 4.4 wishlist — Draft podcast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"https://poststatus.com/?p=14136";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://poststatus.com/our-wordpress-4-4-wishlist-draft-podcast/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1568:"<p>Welcome to the Post Status Draft podcast, which you can find <a href="https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008">on iTunes</a> and <a href="http://simplecast.fm/podcasts/1061/rss">via RSS</a> for your favorite podcatcher. Brian and his co-host, <a href="https://twitter.com/joe_hoyle">Joe Hoyle</a>, a co-founder and the CTO of <a href="https://hmn.md/">Human Made</a>, discuss some of today&#8217;s hottest, current WordPress news.</p>
<p>Listen now:</p>
<a href="https://audio.simplecast.fm/16131.mp3">https://audio.simplecast.fm/16131.mp3</a>
<p><a href="http://audio.simplecast.fm/16131.mp3">Direct Download</a></p>
<p>Stories discussed:</p>
<ul>
<li><a href="https://poststatus.com/wordpress-4-3-billie-released/">WordPress 4.3 &#8220;Billie&#8221; released</a></li>
<li><a href="https://make.wordpress.org/core/2015/08/19/wordpress-4-4-whats-on-your-wishlist/">What is on your wishlist for WordPress 4.4?</a></li>
<li><a href="https://make.wordpress.org/core/2015/08/19/wordpress-4-4-whats-on-your-wishlist/#comment-26718">Don&#8217;t add WP API to Core in 4.4?</a></li>
<li><a href="https://choycedesign.com/2015/01/23/my-top-wordpress-pain-points/">Mel Choyce&#8217;s biggest issues with WordPress</a></li>
<li><a href="https://make.wordpress.org/core/2015/07/23/rest-api-whos-using-this-thing/">Who is using WP REST API and why?</a></li>
<li><a href="http://wp-api.org/">REST API Documentation</a></li>
<li><a href="https://poststatus.com/wordpress-json-rest-api/">A not-so-brief summary of the REST API</a></li>
</ul>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 28 Aug 2015 13:45:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Katie Richards";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"WPTavern: WordPress.com Unveils the Action Bar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47954";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wptavern.com/wordpress-com-unveils-the-action-bar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3846:"<p>WordPress.com has <a href="https://en.blog.wordpress.com/2015/08/26/new-action-bar/">unveiled a new user interface</a> called the Action Bar. It&#8217;s a bar that shows up in the bottom right corner of the screen for logged in users and is accessible from any device. The bar performs multiple tasks depending on the page you&#8217;re on.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/08/WordPressComActionBar.png"><img class="size-full wp-image-47955" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/08/WordPressComActionBar.png?resize=1025%2C627" alt="WordPress Action Bar" /></a>WordPress Action Bar
<p>When on a WordPress.com powered site that you&#8217;re not following, the bar turns into a Follow button. Clicking the follow button will notify you of new posts published on the site.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/actionbar-follow.png"><img class="size-full wp-image-47956" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/actionbar-follow.png?resize=192%2C60" alt="Action Bar Follow Button" /></a>Action Bar Follow Button
<p>If you click the three dots to the right, you&#8217;ll see a variety of options depending upon the page you&#8217;re viewing. If it&#8217;s the homepage, you&#8217;ll see links to download the theme the site uses, report the content, or manage the sites you follow.</p>
<p>If you&#8217;re browsing a specific post on a WordPress.com site, you&#8217;ll see an additional link to copy a shortlink for quick and easy sharing.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/ActionBarThreeDots.png"><img class="size-full wp-image-47957" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/ActionBarThreeDots.png?resize=265%2C319" alt="Easily Share Posts" /></a>Easily Share Posts
<p>If you have a site on WordPress.com and are logged in, the Follow button turns into a Customize button. This link provides a quick way to enter the Customizer. There&#8217;s also an Edit link if you&#8217;re browsing a published post.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/08/ActionBarEditCustomizeButton.png"><img class="size-full wp-image-47958" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/08/ActionBarEditCustomizeButton.png?resize=307%2C348" alt="Edit and Customize Links" /></a>Edit and Customize Links
<p>If the action bar is too big and you want to minimize it, click the three dots and select the option to Collapse the bar. It will shrink the bar into squares and get out of your way.</p>
<h2>My User Experience</h2>
<p>One of the best features of the action bar is the ability to quickly see and download a theme used on a WordPress.com site. However, it doesn&#8217;t work for WordPress.com specific sites like <a href="https://dailypost.wordpress.com/">The Daily Post</a>.</p>
<p>What annoys me about the action bar is that it disappears when I scroll down. I caught myself scrolling down to read a post and when I looked for the edit button to fix a typo, the action bar was gone. I think it should stay on the screen at all times.</p>
<p>I&#8217;d also like to see the Edit link in the action bar open a front-end editor. It&#8217;s time WordPress.com step up its game and stop forcing users through a backend interface to edit published content.</p>
<p>I like the experimental action bar but at the same time, I question the reasoning for adding yet another user interface element to mimic actions already supported by other buttons and links.</p>
<p>For example, between the admin bar, dashboard, the edit link underneath a post, and the action bar, there are now four different ways to edit a post. How many roads are necessary to reach the same destination?</p>
<p>If you have a site on WordPress.com, let me know what you think of the action bar.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 28 Aug 2015 07:43:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"Matt: Frequent Flyer Syndrome";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45311";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://ma.tt/2015/08/frequent-flyer-syndrome/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:175:"<p>It turns out <a href="http://www.economist.com/blogs/gulliver/2015/08/frequent-flyers">not everything about traveling all the time is roses</a>. (Posted from 38k feet.)</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 28 Aug 2015 07:17:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:92:"WPTavern: BuddyPress 2.3.3 Patches Security Vulnerabilities in BuddyPress Messages Component";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47948";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:102:"http://wptavern.com/buddypress-2-3-3-patches-security-vulnerabilities-in-buddypress-messages-component";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1516:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/04/BuddyPressFeaturedImage.png"><img class="aligncenter size-full wp-image-41978" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/04/BuddyPressFeaturedImage.png?resize=828%2C265" alt="BuddyPress Featured Image" /></a>BuddyPress 2.3.3<a href="https://buddypress.org/2015/08/buddypress-2-3-3/"> is available</a> and users are encouraged to <strong>update as soon as possible</strong>. A few security vulnerabilities were discovered in <a href="https://codex.buddypress.org/buddypress-components-and-features/#internal-messaging">BuddyPress Messages, </a>a core component that allows users to send and receive private messages.</p>
<p>A vulnerability was responsibly disclosed to the BuddyPress team that could allow members to manipulate a failed private outbound message and inject unexpected output to the browser. The vulnerability was reported by Krzysztof Katowicz-Kowalewski.</p>
<p>In addition to the first vulnerability, the BuddyPress core development team independently discovered and fixed related vulnerabilities with the messages component that could allow for carefully crafted private message content to be rendered incorrectly to the browser.</p>
<p>BuddyPress 2.3.3 also fixes a couple of bugs in the 2.3 codebase and improves support for backend changes made in WordPress 4.3. To protect your sites from these vulnerabilities, you should perform a full backup and <strong>update BuddyPress as soon as possible</strong>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 28 Aug 2015 06:27:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:62:"WPTavern: Theme Review Team Begins Phasing Out Favicon Support";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47940";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wptavern.com/theme-review-team-begins-phasing-out-favicon-support";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2148:"<p>One of the main features in WordPress 4.3 are Site Icons. A <a href="http://wptavern.com/wordpress-4-3-adds-new-site-icons-feature-and-a-text-editor-to-press-this">Site Icon</a> is an image that represents a website across multiple platforms and replaces Favicons. With Site Icons in WordPress core, the WordPress Theme Review team is <a href="https://make.wordpress.org/themes/2015/08/28/backward-compatible-faviconsicons/">phasing out the feature</a> in existing themes hosted in the theme directory.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/site-icon-customizer.png"><img class="size-full wp-image-47808" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/site-icon-customizer.png?resize=1010%2C568" alt="Site Icons in The Customizer" /></a>Site Icons in The Customizer
<p>Justin Tadlock, a theme review admin, <a href="https://make.wordpress.org/themes/2015/08/28/backward-compatible-faviconsicons/">published a tutorial</a> that explains how to provide a backwards compatible experience.</p>
<p>According to Tadlock, the easiest method is to check if the <code>has_site_icon()</code> function exists. This tells you if the user is running WordPress 4.3 and has the site icon feature available.</p>
<p>You can also check if the user has set up a new icon using the core WordPress feature by using the <code>has_site_icon()</code> conditional tag which returns either <code>TRUE</code> or <code>FALSE</code>.</p>
<p>Here’s some example code from the tutorial you can use to handle the check:</p>
<pre><code>if ( ! function_exists( \'has_site_icon\' ) || ! has_site_icon() ) {

    // Output old, custom favicon feature.
}</code></pre>
<p>For additional information, I encourage you to read<a href="http://scratch99.com/wordpress/development/backwards-compatibility-site-icons/"> Stephen Cronin&#8217;s post</a> which goes into more detail.</p>
<p>The Theme Review Team enforces a guideline where features added to core are phased out of themes within two major releases. By the time WordPress 4.5 is released, theme authors will be able to remove legacy code without disrupting the user experience.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 28 Aug 2015 05:05:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"WPTavern: WordPress Community Summit Set for December 2-3, 2015";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47930";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wptavern.com/wordpress-community-summit-set-for-december-2-3-2015";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2007:"<p>The <a href="https://2015.us.wordcamp.org/2015/08/26/2015-wordpress-community-summit-dates-announced/">WordPress community summit</a> will take place on December 2-3, 2015, in Philadelphia, PA two days before WordCamp US. The summit&nbsp;will be held at <a href="http://philadelphia.impacthub.net/" target="_blank">Impact Hub Philadelphia</a>, a co-working space where freelancers, entrepreneurs, and social innovators work together, share ideas, and build networks.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/08/ImpactHub.jpg"><img class="size-large wp-image-47931" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/08/ImpactHub.jpg?resize=500%2C333" alt="inside Impact Hub" /></a>Inside Impact HubImpact Hub is spacious and has dedicated meeting and conference rooms. According to the announcement, the summit is invite only similar to last year’s event at WordCamp San Francisco:</p>
<blockquote><p>The WordPress Community Summit is a smaller, invite-only event for&nbsp;active members and contributors on the many teams that work to improve&nbsp;WordPress: Core, Design, Mobile, Accessibility, Support, Polygots, Documentation, Themes, Plugins, Community, Meta, Training, Flow&nbsp;and&nbsp;TV .</p></blockquote>
<p>A survey or application form will soon be published which will result in a pool from which the attendees will be invited.</p>
<p>The summit is a rare opportunity for members of various contributor teams to focus and work together in the same physical location.</p>
<h2>Annual WordPress Survey</h2>
<p>If you use, build, or make a living with WordPress, please take the <a href="http://wp-survey.polldaddy.com/s/wp-2015">annual survey</a>. Results will be shared during Matt Mullenweg&#8217;s State of the Word presentation at WordCamp US. The more people who fill out the survey, the more representative the data will be.</p>
<p>Watch Mullenweg&#8217;s State of the Word presentation from 2014 to see results from the previous survey.</p>
<p></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 27 Aug 2015 21:07:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: Stream Is Shutting Down Its Cloud Data Storage October 1st";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47925";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://wptavern.com/stream-is-shutting-down-its-cloud-data-storage-october-1st";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3977:"<p>Stream 3 is <a href="https://wp-stream.com/introducing-stream-3/">available for download</a> and includes some significant improvements. Stream is a WordPress plugin that tracks changes to a site similar to an audit trail. When <a href="http://wptavern.com/stream-morphs-from-a-plugin-into-a-service">version two was released</a> nearly a year ago, it morphed from a plugin to a service. Activity logs were stored in the cloud which lessened the amount of resources used on local webservers.</p>
<p>Version three will no longer store data in the cloud. Instead, it will store activity logs locally. The cloud service provided by Stream 2 is closing on <strong>October 1st</strong>. This gives users a little more than a month to migrate data from the cloud to their local webserver.</p>
<h2>The Cloud is Expensive</h2>
<p>Luke Carbis, lead developer of Stream, says the time frame was chosen based on a number of factors, &#8220;We chose a 6 week migration window as a balance between bleeding cash and doing the right thing by our users.</p>
<p>&#8220;It&#8217;s also helpful to remember that the vast majority of our users are on a Free plan, which only includes 12 weeks of storage. We are monitoring the accounts of each of our paid users and I&#8217;m personally making sure that every one of them has migrated,&#8221; Carbis told the Tavern.</p>
<p>The move away from the cloud is largely based on cost. The majority of Stream&#8217;s customers signed up to the free plan with a significant lack of interest in the Pro Subscription. Server costs were also higher than expected.</p>
<h2>XWP to The Rescue</h2>
<p>With a lack of income from Stream 2 and acquisition talks failing, Carbis was contracted to do outside work leaving Frankie Jarrett the only person working on the project. Stream&#8217;s investor decided to pull the plug on the project at the same time Jarrett decided to resign from the company.</p>
<p>&#8220;When I heard that Frankie had resigned I gave him a call. We reminisced on our achievements, and threw around some of our ideas on what could have been. That conversation renewed my inspiration. I jotted down some notes, and that’s when things started to turn around,&#8221; Carbis said.</p>
<p>Members from <a href="https://xwp.co/">XWP</a> stepped in to lend a helping hand and the project is now officially under the XWP umbrella. This allows Stream to remain free and open source. The partnership will also facilitate add-on, connectors, and adapters</p>
<h2>What&#8217;s New in Stream 3</h2>
<p>Stream 3 is rewritten from the ground up. Activity logs use half the space in the database compared to Stream 2. It supports multisite through the use of Network Admin and uses a dependency injection model to be more extendable and efficient.</p>
<p>Although Stream 3 includes a variety of improvements two notable features have been removed, Notifications and Reports. If you depend on these features, please <a href="https://wp-stream.com/stream-3-faq/">review the following FAQ</a>.</p>
<h2>A New Direction</h2>
<p>Carbis and XWP are taking Stream into a new direction. Stream&#8217;s <a href="https://github.com/wp-stream/roadmap/">proposed roadmap</a> is available on GitHub and Carbis encourages users to not only review it, but to contribute to the project&#8217;s future, &#8220;I’d like to see Stream’s users contribute more to its direction. Contribution isn’t limited to ideas either. If you can design, develop, or translate, please consider <a href="http://github.com/wp-stream/stream">contributing to the Stream project</a>,&#8221; he said.</p>
<p>It will be interesting to see if Stream can regain the momentum it lost after transitioning to a cloud based system to store data. Now that Stream stores activity logs locally again, those in the EU should be able to use it without breaking privacy laws. Stream is <a href="https://wordpress.org/plugins/stream/">available for free</a> on the WordPress plugin directory.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 27 Aug 2015 20:17:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"Akismet: Quantifying Reddit Bigotry";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1859";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://blog.akismet.com/2015/08/27/quantifying-reddit-bigotry/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1729:"<p><small><em><strong>Update (2015-08-30): It looks like the team who created the tool decided to retire it due to some reported accuracy concerns.</strong></em></small></p>
<p>We never pass on the opportunity to mix in a little bit of humor with our passion for web content moderation.</p>
<p>One of our engineers, Dan Walmsley, participated in <a href="http://www.comedyhackday.org/la-2015">Cultivated Wit&#8217;s Comedy Hack Day</a> in Los Angeles last weekend, and his team&#8217;s resulting project has since surfaced on <a href="http://motherboard.vice.com/read/this-tool-quantifies-reddit-bigotry">Motherboard</a> and <a href="http://www.engadget.com/2015/08/26/reddit-bigotry-check/">Engadget</a>.</p>
<p><a href="http://www.freeredditcheck.com/">Free Reddit Check</a>, created by Dan&#8217;s team and crowned with the day&#8217;s top prize, is a site which attempts to quantify the terribleness of Reddit users based on their public comment content and subreddit participation. While perfectly suited for a hack day which pairs developers and comedians, there is certainly usefulness in determining the respectability of a potential online acquaintance. Or just knowing who to ignore.</p>
<p>And being obsessed with content analysis, community moderation, and keeping the web&#8217;s underbelly in check, we can&#8217;t help but think it&#8217;s a nifty idea.</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1859/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1859/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=blog.akismet.com&blog=116920&post=1859&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 27 Aug 2015 11:43:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Anthony Bubel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"WPTavern: WPWeekly Episode 205 – Interview With Miriam Schwab";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47915";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://wptavern.com/wpweekly-episode-205-interview-with-miriam-schwab";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2039:"<p>In this episode of WordPress Weekly, I&#8217;m joined by Miriam Schwab, founder and CEO of <a href="http://illuminea.com/">Illuminea</a>, a web development company based in Israel. She’s also on the Steering Board of <a href="http://digitaleveisrael.com/">Digital Eve Israel</a>, one of the leading communities for professional women in Israel to help empower women economically.</p>
<p>Schwab explains her WordPress origin story, what it&#8217;s like to live in Israel, and how active the WordPress community is in her area. She shares her thoughts on the future of WordPress and warns that if it doesn&#8217;t improve the user experience, it will drive users away to competing platforms. At the end of the interview, she tells us her favorite plugins that she installs on most of her client sites.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/first-look-at-the-twenty-sixteen-default-wordpress-theme">First Look at the Twenty Sixteen Default WordPress Theme</a><br />
<a href="http://wptavern.com/sessions-from-buddycamp-brighton-uk-now-available-to-watch-on-wordpress-tv">Sessions From BuddyCamp Brighton, UK Now Available to Watch on WordPress.tv</a><br />
<a href="http://wptavern.com/ostraining-makes-pods-framework-video-training-series-available-for-free">OSTraining Makes Pods Framework Video Training Series Available for Free</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, September 2nd 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #205:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 27 Aug 2015 04:24:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WPTavern: First Look at the Twenty Sixteen Default WordPress Theme";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47897";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://wptavern.com/first-look-at-the-twenty-sixteen-default-wordpress-theme";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2281:"<p>WordPress 4.4 is the last scheduled major release of the year and with it will come a new default theme to replace Twenty Fifteen. On the Make WordPress Core site, Tammie Lister <a href="https://make.wordpress.org/core/2015/08/25/introducing-twenty-sixteen/">published an image gallery</a> that shows off the design of Twenty Sixteen.</p>
<p>According to Lister, the process of determining the new default theme has taken months, &#8220;Lots of themes were considered, eventually settling on the one you see below. It’s a perfect fit,&#8221; she said.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/TwentySixteenConcept.png"><img class="size-large wp-image-47898" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/TwentySixteenConcept.png?resize=433%2C500" alt="Twenty Sixteen" /></a>Twenty Sixteen
<p>Twenty Sixteen is designed by <a href="https://profiles.wordpress.org/iamtakashi">Takashi Irie,</a> who also designed the <a href="http://takashiirie.com/2013/12/13/twenty-fourteen-wordpress-3-8-parker/">Twenty Fourteen</a> and <a href="http://takashiirie.com/2015/03/19/twenty-fifteen-the-wordpress-default-theme-for-2015/">Twenty Fifteen</a> default themes. Irie describes Twenty Sixteen as:</p>
<blockquote><p>A modernized approach of an ever-popular layout — a horizontal masthead and an optional right sidebar that works well with both blogs and websites. It has custom color options that allow you to make your own Twenty Sixteen. The theme was designed on a harmonious fluid grid with a mobile first approach. This means it looks great on any device.</p></blockquote>
<p>The new theme has hints of Twenty Fourteen but is different enough to stand on its own as a unique design. It doesn&#8217;t look as modern as <a href="https://twentyfifteendemo.wordpress.com/">Twenty Fifteen</a> out-of-the box but the design could change during the 4.4 development cycle.</p>
<p>If you want to help Twenty Sixteen be the best it can be, please join the weekly meetings held every Monday and Friday at 16:00 UTC in the #core-themes channel on <a href="https://make.wordpress.org/chat/">SlackHQ</a>. The meetings are a half hour-long and start once the theme is initially added to WordPress core.</p>
<p>What do you think of Twenty Sixteen?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 26 Aug 2015 01:20:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WPTavern: Sessions From BuddyCamp Brighton, UK Now Available to Watch on WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47892";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:94:"http://wptavern.com/sessions-from-buddycamp-brighton-uk-now-available-to-watch-on-wordpress-tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1354:"<p>Earlier this month, the first <a href="https://brighton.buddycamp.org/2015/">BuddyCamp Brighton, UK</a> successfully took place. Six speakers presented their sessions from within the venue while four participated remotely. Here&#8217;s a break down of the attendees:</p>
<ul>
<li>13 Sponsors.</li>
<li>8 Sessions.</li>
<li>7 Volunteers.</li>
<li>6 Speakers plus another 4 via video message.</li>
<li>33 Attendees.</li>
</ul>
<p>The conference featured sessions on the <a href="https://brighton.buddycamp.org/2015/session/the-origin-of-buddypress/">origin of BuddyPress</a>, a <a href="https://brighton.buddycamp.org/2015/session/fireside-with-paul-gibbs/">fireside chat with Paul Gibbs</a>, and <a href="https://brighton.buddycamp.org/2015/session/messages-from-contributors/">messages from BuddyPress contributors</a>.</p>
<p>Photographs of the event <a href="https://brighton.buddycamp.org/2015/photos/">are available</a> on the official BuddyCamp Brighton website. In addition to photographs, sessions were recorded and are <a href="http://wordpress.tv/event/buddycamp-brighton-2015/">available to watch for free</a> on WordPress.tv.</p>
<p>In the following video, Gibbs explains the origins of <a href="https://buddypress.org/">BuddyPress</a>.</p>
<p></p>
<p>If you attended BuddyCamp Brighton, UK please share your experience in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 26 Aug 2015 01:11:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WPTavern: OSTraining Makes Pods Framework Video Training Series Available for Free";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47885";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://wptavern.com/ostraining-makes-pods-framework-video-training-series-available-for-free";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2214:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/pods.jpg"><img class="aligncenter size-full wp-image-40653" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/pods.jpg?resize=628%2C290" alt="pods" /></a><a href="https://www.ostraining.com/">OSTraining</a>, a site that offers video training for WordPress, Joomla, Drupal, and other technologies <a href="https://www.ostraining.com/blog/wordpress/pods/">announced</a> their <a href="http://pods.io/">Pods Framework</a> video <a href="https://www.ostraining.com/courses/class/wordpress/pods/">training series</a> is now available for free. Steve Burge, founder of OSTraining.com, says offering the video series for free is the result of a partnership with the Pods Framework project.</p>
<p>&#8220;This project came about because the OSTraining and Pods teams bumped into each other on a regular basis. I often ran into Jim True and Josh Pollock from Pods. We met at WordCamps and WordPress meetups in Tampa, Orlando, and Miami, FL.</p>
<p>&#8220;The Pods team explained that they were working on improving their documentation. They started a YouTube series, wrote tutorials, and started the <a href="http://wptavern.com/pods-lead-developer-scott-kingsley-clark-launches-friends-of-pods-funding-campaign">Friends of Pods</a> initiative to support their efforts. Making the videos free is our way of contributing to the Pods project,&#8221; Burge told the Tavern.</p>
<p>Burge recorded the series after using Pods to create the <a href="http://appalachiantrail.com/">Appalachian Trail</a> website. The series provides an introduction to Pods, templates, creating a custom taxonomy, and more. Those interested can view the series on <a href="https://www.ostraining.com/courses/class/wordpress/pods/">OSTraining.com</a> or <a href="https://www.youtube.com/watch?list=PLtaXuX0nEZk9dCVMQRmSptuJ6YdVzMkr5&v=4rm95kNxRXg">YouTube</a>.</p>
<p>Here&#8217;s a look at the first video in the series which introduces viewers to the Pods Framework.</p>
<p><span class="embed-youtube"></span></p>
<p>Although it was created in 2014, the series contains great insight into the project and provides an educational foundation for learning Pods 3.0.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 24 Aug 2015 21:20:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:43:"Alex King: Request: Alex King Rememberances";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=22017";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"http://alexking.org/blog/2015/08/24/rememberances";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1445:"<p>Dear WordPress community,</p>
<p>My apologies for the selfish and personal nature of this post. I hope you will forgive me given the circumstances. As most of you know, I was <a href="http://alexking.org/blog/thread/cancer">diagnosed with stage 4 colon cancer in 2013</a>.</p>
<p>One of the things my wife and I are trying to do is put together some information about my career that will hopefully give my 6 year-old daughter a better sense of who I was as an adult. She knows me as &#8220;dad&#8221;, but when she gets older she&#8217;ll be curious about who I was to my peers and colleagues.</p>
<p>I&#8217;ve spent more than a decade in the WordPress community and I&#8217;d like to request that you to share a few thoughts or remembrances about me that we can compile and share with her when the time is right.</p>
<p>If we have crossed paths or if I have managed to do something that you found helpful, I&#8217;d love it if you would take a few minutes to write it down and <a href="http://alexking.org/contact">send it to me</a> or my wife: heatherkingcom@gmail.com. If you&#8217;re willing to have the story shared publicly, please indicate that accordingly. By default, we will keep everything confidential.</p>
<p class="threads-post-notice">This post is part of the thread: <a href="http://alexking.org/blog/thread/cancer">Cancer</a> &#8211; an ongoing story on this site. View the thread timeline for more context on this post.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 24 Aug 2015 21:01:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"WPTavern: Step Up Your Game: How to Work With Successful WordPress Clients";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47868";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://wptavern.com/step-up-your-game-how-to-work-with-successful-wordpress-clients";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:25388:"<hr />
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/MarioPeshev.jpg"><img class="alignright size-thumbnail wp-image-47869" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/MarioPeshev.jpg?resize=150%2C150" alt="Mario Y. Peshev" /></a>This post was contributed by <a title="Ryan Hellyer" href="http://geek.ryanhellyer.net/" target="_blank">Mario Peshev</a>. Mario is the founder and WordPress Architect at <a href="http://t.co/p9TnMSFMi2">DevriX</a> building and maintaining large WordPress-driven platforms. With over 10,000 hours of consulting and training, Mario&#8217;s Yin and Yang is his Open Source advocacy and business growth strategy.</p>
<hr />
<blockquote><p>Without continual growth and progress, such words as improvement, achievement, and success have no meaning &#8211; Benjamin Franklin</p></blockquote>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/StepUpYourGameFeaturedImage.png"><img class="size-full wp-image-47879" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/StepUpYourGameFeaturedImage.png?resize=682%2C281" alt="Step up your game featured image" /></a>photo credit: <a href="http://www.flickr.com/photos/58522126@N00/430932479">Stairwell</a> &#8211; <a href="https://creativecommons.org/licenses/by/2.0/">(license)</a>
<p>I’ve been a learnaholic for as long as I can remember and when I read the aforementioned quote, it resonates strongly with me. My prelude to WordPress years ago was one of the steps toward improvement and success and I’ve developed a special love-hate relationship with WordPress.</p>
<p>Utmost admiration about its influence over the world in terms of Open Source and opportunities for various people in different niches, and its plague of being diminished and depreciated by professional developers and successful businesses.</p>
<p>There are ways to solve these issues as long as the inner circle works towards the same goal.</p>
<p><strong>Note</strong>: If you are happy building lego type websites with random ThemeForest themes and you see that as your future, this post is not for you. If you love doing the same repeatedly for mom and pop shops, this may not resonate with you. This is applicable to people who want to get better at what they do, be more professional, and make some impact by solving complex problems for larger customers.</p>
<h2>WordPress For a Better Future</h2>
<p>In May, I presented at a conference focused on kids and teenagers to motivate them, prepare them for the adult life, and nurture their creativity. Kids these days hardly think about their future, between their teenage emotional dramas and boring homework assignments. If you think about it, how can they be passionate about becoming someone if they have no real idea what they need to know and do on a daily basis?</p>
<p>I used WordPress as an example of a platform that children can use, one that provides them with the opportunity to develop a talent or passion.</p>
<p>Using WordPress for homework and general notes (or a diary) could indicate interest in several areas:</p>
<ul>
<li>Young bloggers can potentially do creative writing or copywriting.</li>
<li>Constantly switching themes and playing with colors might open the room to design.</li>
<li>Adding plugins and trying to implement complex combinations is the first step to programming.</li>
<li>Sharing posts, looking at analytics and comparing different titles or photos is the way to marketing.</li>
</ul>
<p>There are other potential areas of course, but as long as kids can associate with an activity, become passionate about it, and start digging into it, they can save years of slacking, not to mention tens of thousands of dollars on college degrees for specialties they couldn’t care less about.</p>
<p>This is one of the reasons why more and more people join the WordPress industry and switch boring jobs in order to make a living off of WordPress.</p>
<h2>What Types Of WordPress Services Exist?</h2>
<p>The amount of opportunities for WordPress work is incredible but the vast pool of WordPress jobs is so vague and blurry, that hiring and educating talent is out of control.</p>
<p>I keep an eye on dozens of job boards, portals, and freelance networks. Clients look for Virtual Assistants to get their websites built. They look for expert WordPress developers to apply content changes to their site or web designers to develop complex plugins.</p>
<p>On a weekly basis I see references to WordPress administrators, programmers, developers, designers, marketers, digital artists, webmasters, VAs, and plenty of other job titles used improperly. As a matter of fact, I’m now fascinated when I see a WordPress related job post or an offer looking for the right type of candidate.</p>
<p>The great news is that you can do anything with WordPress. The caveat here is that WordPress itself is not a skill. You don’t ask for an Internet expert nowadays and you don’t go to the same doctor when you have a headache or you’ve injured your leg.</p>
<p>The wide industry of innocent clients and amateur service providers have made it nearly impossible to tell a developer from a marketer, or from a general user who has installed WordPress with an auto-installer twice.</p>
<h2>The Indecent World of WordPress Experts</h2>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/02/JobTitleFeaturedImage.png"><img class="size-full wp-image-39089" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/02/JobTitleFeaturedImage.png?resize=650%2C200" alt="Job Titles Featured Image" /></a>photo credit: <a href="http://www.flickr.com/photos/58871905@N03/5565517971">I love &#8217;84</a> &#8211; <a href="https://creativecommons.org/licenses/by/2.0/">(license)</a>
<p>I’ve read a lot about impostor syndrome in several reputable WordPress blogs, and people keep identifying themselves in the comments. In my opinion, this is a problem so insignificant as compared to the ever-growing pool of people claiming to be WordPress Experts.</p>
<p>In the last several years, I’ve interacted with people all around the world working with WordPress. From freelancers to successful business owners at conferences, and from beginner virtual assistants to full-stack consultants in social media, blogs and job networks.</p>
<p>The largest group of service providers that I’ve found is the one of <em>WordPress experts</em>. You can easily substitute expert with specialist, guru, master, ninja and rockstar. Just open a new tab and do a few quick searches in Google, job networks, social media and view the large number of results.</p>
<p>Next on the list are <em>WordPress developers</em>. A WordPress developer is often described as people who install plugins. There are various possible scenarios, but this is rarely the definition of an actual developer proficient in WordPress.</p>
<p>Some boards or blogs list specific skills that let you filter by programming language or a separate tool. My latest research with 200 contractors with WordPress developer titles led to 170 people who rate themselves with 4 or 5 out of 5 stars in PHP proficiency, and 30 with 3 stars.</p>
<p>Out of the 170 people in the first group, 150 were college students, Internet marketers, VAs, and people who have substituted strings in WordPress themes thanks to support forums or help from the Codex. Not a single line of code was written from scratch, let alone building anything, and 4 out of 5 or higher self-assessed their level of PHP experience.</p>
<p>Tom McFarlin <a href="http://tommcfarlin.com/wordpress-developers-programmer-implementer/">published a post</a> on the difference between a developer and implementer and I wrote an overview defining <a href="http://wptavern.com/why-wordpress-job-titles-dont-mean-much-anymore">various technical skills in the WordPress context</a>. Due to the lack of proper training, any official educational resource or meaningful set of skills per role, both finding talent and improving one’s skills is being challenged.</p>
<p>I challenge you to interview several successful clients around you who looked for skillful WordPress folks. They either happened to know the right people, were recommended someone, ended up with several freelancers who messed up big time, went AWOL and suddenly took the cash and disappeared, couldn’t deliver, or they did and the site is incredibly slow and/or got hacked soon thereafter.</p>
<p>That’s sending serious businesses away and I won’t touch the topic of under pricing services and products which brings the quality and support way down.</p>
<p>What motivates people to use a reliable resource in order to grow? The WordPress Foundation, nor any of the big players provide official training curriculum, and a definition for formal roles. There is no WordPress certification program (I won’t get into that to avoid unnecessary discussions), and there are no clear paths for requirements.</p>
<h2>The WordPress Community is Filled with Amateurs</h2>
<p>As a result, our community is a large group mostly composed of amateurs who started using WordPress one way or another. These people started earning money and reached a point where they don’t know where they stand, what they’re proficient in, if they’re doing fine, whether they’re experts, impostors, or somewhere in the middle, and what would be helpful to them?</p>
<p>We still use FTP and work with PHP 5.2-supported hosts. The most popular theme marketplaces provide products with broken and inconsistent code. The WordPress.org plugin repository accepts plenty of plugins with suspicious consistency and compatibility.</p>
<p>None of these issues are recognized publicly in the WordPress community. Some hosts prohibit SSH and allow solely FTP. PHP 5.2 will be supported by Core for a while, which doesn’t motivate hosts to upgrade. Marketplaces earn millions from their top sellers, so they’re not interested in quickly bringing up quality as long as poorly coded themes sell well. There’s also no formal constantly reviewed plugin repository for high quality plugins and no one is actively backing this idea up.</p>
<p>If you read the last paragraph as a rant, it’s because it is. It’s meant to be a “wake up call” to clients who don’t know better and service providers who want to become better. While the WordPress Core itself is incredibly stable and flexible, the rest of the infrastructure is mostly poorly coded due to under pricing, lack of skills, and lack of more successful clients interested in backing up WordPress teams and consultants.</p>
<p>There are different kinds of people and plenty of applications of WordPress. Whatever you do, it’s your professional duty to offer the right type of service instead of misleading your clients, and be aware of the other pertinent verticals. Moreover, it’s the only way forward working with reputable organizations and large profitable corporations.</p>
<h2>What is a Successful Client?</h2>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/SuccessFeaturedImage.png"><img class="size-full wp-image-32204" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/SuccessFeaturedImage.png?resize=636%2C278" alt="Success Featured Image" /></a>photo credit: <a href="https://www.flickr.com/photos/seeveeaar/2035597695/">seeveeaar</a> &#8211; <a href="http://creativecommons.org/licenses/by-nd/2.0/">cc</a>
<p><a href="http://prestigeconf.com/">Prestige Conference</a> happened a few weeks ago, and Shane Pearlman from <a href="https://tri.be/">Modern Tribe</a> shared his experience in a presentation entitled, Land the Big Fish: Strategies Acquiring Larger Clients. It’s a motivational talk that outlines different strategies on negotiating and landing larger customers.</p>
<p>During the Q&amp;A at the end of the session, Pearlman is asked, “What’s in it for me to go through all of that headache to procure bigger brand names?”</p>
<p>As I stated at the beginning, working with successful clients is not for everyone. Some people are afraid to leave their comfort zone. Others are too lazy to learn new skills or sometimes doing the same thing repeatedly may be their perfect job. For every other entrepreneur or business player, successful clients are exciting.</p>
<p>Each small change is magnified when working with successful clients. Usually, they have a lot of employees, a solid budget for marketing and advertising, a lot of traffic, and various complex requirements that help them attract more leads or automate their processes. T</p>
<p>hey are often respectable and have access to more capital. This allows them to invest more since their return of investment is worth it; while taking a risk due to saving a few bucks could very well ruin their reputation and harm their business. There are several examples of products or companies in the WordPress community that were hacked or where updates caused major issues.</p>
<p>Working with successful clients is extremely rewarding and exciting, but getting there requires ace skills and solid experience, as well as the right mindset.</p>
<h2>How to Target Successful Clients</h2>
<p>Based on my experience with banks, telecoms, automotive, airline brands, large educational institutions and media outlets over the last 12 years as a developer and a technical lead, there are several specific areas where courageous WordPress freelancers and small business owners can focus on if they are aiming for growth and successful clients, but aren’t there yet.</p>
<p>I have identified some steps for <a href="http://www.wpelevation.com/2015/08/8-steps-to-move-from-freelancer-to-successful-company/">moving from a freelancer to a successful company</a>. Here is what we should focus on in the WordPress context in order to step up our game, understand our industry better, and start acting professionally if we want to be taken seriously.</p>
<h2>WordPress is a Vague Term</h2>
<p>Being a WordPress Expert says nothing. You may be a lead developer of WordPress or someone who can memorize the order of all submenus under Settings in the admin dashboard. Both are classified as WordPress experts and that’s what many people don’t realize.</p>
<p>Specialize in a given niche and polish your skills. Focus on a specific group of projects &#8211; membership websites, eCommerce stores, multisite installs. Become a know-it-all professional for an extensible plugin such as, BuddyPress, Gravity Forms, or Easy Digital Downloads.</p>
<p>Understand the value you are providing and what it corresponds to. Be respectful to the broad community of professionals in your area, learn from them, ask them to be your mentors. Even the best athletes and CEOs have coaches, business mentors, and boards of directors. Find out what it is that you do whether it’s design, development, marketing, or something else and learn the skill inside and out.</p>
<h2>WordPress Installments Don’t Matter</h2>
<p>Plenty of people offer WordPress services as an add-on to their portfolio of other services without realizing the impact it has on the business. While WordPress is used for plenty of purposes, it’s still a technical platform that comes with its own specific set of requirements.</p>
<p>Imagine what will happen if:</p>
<ul>
<li>You set up a vulnerable plugin that is exploited and your client’s password is stolen, along with their private details.</li>
<li>You forget to protect the media uploader and the client uploads sensitive data. Scanned images of contracts and ID cards end up in the public space.</li>
<li>Your sitemap plugin indexes protected data since you used a plugin that doesn’t work.</li>
<li>You set up a site and sell it to a client, and due to the terrible choice of plugins, the site crashes miserably and kills the server during a demonstration in front of their big clients.</li>
</ul>
<p>Its a small list of what ifs, but they happen all the time. If you don’t possess the skills or offer the wrong service, this could damage your client’s business. Upping your game and providing solutions instead of websites allows you to take care of the infrastructure, maintenance work, support, development, security, marketing of the project.</p>
<p>At the very least, be aware of the consequences and partner up with other agencies and consultants. Complete packages are what successful clients look for and inexperienced people often mess up what others have built.</p>
<h2>WordPress Expert Skills Won’t Cut It</h2>
<p>Successful clients look for professional skills. They have real problems that can’t be solved with yet another plugin, and they are smart enough to know that.</p>
<p>If you are in the business of configuring themes and installing a few plugins for clients, that won’t do it for successful customers. You need to specialize in code, design, user experience, marketing, or something else that brings real value to them.</p>
<p>Large clients are looking for state of the art designs, performant and secure code, brilliant marketing skills, and growth hacking strategy. Large clients are successful because they are outstanding at what they do, the services they offer, and they appreciate high quality.</p>
<h2>Context-Specific WordPress Solutions</h2>
<p>Large organizations take their marketing presence and technical stack seriously. They carefully delegate based on multiple factors. Being in a meeting with a large client typically means discussing a use case together with several people such as, a creative director, VP of marketing, network engineer, and project manager.</p>
<p>In addition to being skillful in your niche and ready to provide value, you have to learn the business processes of your target client. Your idea of a solution may be applicable for small sites, but it may very well be a bad fit based on the company policy or the variety of services used by the team.</p>
<p>As an example, a creative director may require you to prepare your theme to be ADA Section 508 compliant, which is an accessibility standard required by certain organizations. The VP of marketing may ask for a Hubspot integration with Cvent within your website for proper CRM and meeting request management.</p>
<p>The network engineer could outline that they need to host the solution on-site, and set up a specific set of web application firewalls and internal web server security rules restricting certain process callbacks. The project manager might share a complicated timeline based on the organization load, holiday schedule, decision maker’s availability, conferences, and various deliverables that need to be presented by different people and other third-parties.</p>
<p>All of the above are things that we’ve been asked for over the past few months. If you are used to working with a specific host using Apache, prepare for writing documentation and shipping to a restricted server running HHVM. If you use a framework that isn’t accessible, you will need to step back, explore the Section 508 standards, and build something compatible.</p>
<p>Generic solutions are often not the right fit for large clients. But if you’re determined to learn more and become a better professional, that’s the perfect challenge for you.</p>
<h2>Solving More Complex Problems</h2>
<p>In addition to being able to adjust to different environments, working with large clients means solving more complex problems.</p>
<p>If a mom and pop shop is somewhat broken or down, it’s probably not a big deal if their site receives 100 visits per month. But for a project with tens of millions of views a month and thousands of concurrent users, it is unacceptable.</p>
<p>Working on larger and heavy platforms often means dealing with a lot of data, complex relationships, and solid traffic. This means that every single line of your code and business decision will inevitably impact the entire system in a way visible to hundreds of thousands of people.</p>
<p>In order to be able to cope with these, you should study your specialty in detail and understand what the impact is of every single change. These skills increase your value and let you face similar challenges and solve problems that the majority of beginners can’t even imagine.</p>
<p>You will learn a lot about the entire stack, and get to know hundreds of different rules. At some point you will voluntarily violate those rules, being aware of the fact that some design patterns and best practices don’t solve specific problems. It’s better to denormalize a database or minify a compression algorithm in order to solve a business problem for a large platform.</p>
<p>It’s just as they say at a music college &#8211; you learn the music theory for three years, and then you throw everything away and start playing jazz. You need to know the entire architecture and strategy first in order to decide how to optimize it in the best possible manner, whether it’s using a best practice or violating one for a specific purpose.</p>
<h2>Teaming Up</h2>
<p>If you have worked solo or in a small team, you will eventually need to partner up or grow. Either way, large projects are time consuming and require different expertise, and it’s unthinkable for one to know it all. Therefore, you will work with other professionals from more industries, team up and solve more complex problems together, and learn more about their challenges.</p>
<p>If you have thought about mastering a single skill, teaming up with the right people will add a few more skills as an extra perk, which will increase the potential of your main skill as well. Working with financial analysts on a project for a bank helped me to understand the entire model of loans and mortgages, as well as the internal banking policy.</p>
<p>This allowed me to learn how loans and interests work in different cases and get acquainted with standardized security regulations at companies in the financial field.</p>
<h2>Security Concerns</h2>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/HelloSecurityFeaturedImage.png"><img class="size-full wp-image-44224" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/HelloSecurityFeaturedImage.png?resize=688%2C368" alt="Hello Security Featured Image" /></a>photo credit: <a href="http://www.flickr.com/photos/8264582@N06/3383392046">Two Locks</a> &#8211; <a href="https://creativecommons.org/licenses/by/2.0/">(license)</a>
<p>Data privacy and security are important topics that people often misjudge. Working with large clients means more responsibility and higher impact in case of a problem. In the process of building a solution or consulting a reputable organization, you will most likely have to comply with various security policies.</p>
<p>While some of them may seem unnecessary, there is a reason they exist. The more familiar you are with them, the better it is for you, your clients, and future endeavors. If you’re not using VPNs, SSH keys, two-factor authentication, or voice recognition IDS, this may be a good lesson for you. Why are they needed, what problems do they solve, and how can you apply them to your personal data and existing set of clients?</p>
<h2>Organization and Accountability</h2>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/BrainyQuote1.jpg"><img class="size-full wp-image-47877" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/BrainyQuote1.jpg?resize=620%2C400" alt="BrainyQuote" /></a>BrainyQuote
<p>In order to be helpful to large businesses as a consultant, or an agency, you need to be reliable. This may be a result of a number of testimonials, successful track record at previous companies or a good portfolio. It’s always challenging to start with large customers, so improving your skills and working hard in order to become valuable is important.</p>
<p>Being organized and process-oriented is essential to most reputable organizations. The majority of them are more conservative and operate slowly, since a minor mistake could cost them millions or more.</p>
<p>They rely on detailed specifications, scope of work documents, use case diagrams, UX mockups/wireframes, E/R diagrams, and a large list of documents. They include every single detail in their planning &#8211; from holidays for each member of their team, to different dependencies from other service providers and third-party members.</p>
<p>Successful clients have managed to build a process and scale it in a way that grows their revenue in a predictable way. In order to be able to handle large projects, you need to treat them as a small project that takes longer to complete.</p>
<p>Learn how to use a project management system and version control properly, define your pricing strategy, make sure to predict all of the delays for both communication and payments. Learn how large organizations operate and do your due diligence upfront in order to avoid surprises.</p>
<p>Don’t take anything for granted and don’t assume anything. The more confident you are, the higher the possibility of making a major mistake. There are always new automatic deployment strategies or a DevOps service you haven’t heard of, another massive CSS3 grid, or a growth hacking strategy that you haven’t explored.</p>
<p>The more challenges you face, the more you’ll learn, and be able to solve complex problems.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 24 Aug 2015 18:42:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"Alex King: Personal WordPress Theme";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=21662";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://alexking.org/blog/2015/08/22/personal-wordpress-theme";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2188:"<p>I&#8217;ve forked the FavePersonal theme to release a few changes that I&#8217;ve made to it for my own site.</p>
<ol>
<li>An improved Gallery feature, including support for WordPress shortcode galleries. If you&#8217;re uploading photos directly to your gallery post, you can use drag and drop to set the order for them now.</li>
<li>The Post Formats admin UI is now responsive and works great on mobile devices.</li>
<li>Remove the Social plugin from the theme (requested by WP.org) &#8211; it can still be installed separately.</li>
<li>Make tons of misc. code changes to match new coding standards vs. previous coding standards (and pass the theme check).</li>
</ol>
<p><img src="http://alexking.org/wp-content/uploads/2015/08/maine-gallery-510x469.png" alt="Gallery" width="480" height="441" class="alignnone size-medium-img wp-image-22028" /></p>
<p>I was originally hoping to have the modified theme hosted on WordPress.org but after weeks of waiting for review, they responded that features of the theme like <a href="https://themes.trac.wordpress.org/ticket/24520#comment:4">choosing colors and post formats</a> should be done in separate plugins instead. This makes no sense to me as these are core features of the theme, but happily there are great places like <a href="https://github.com/alexkingorg/wp-personal">GitHub</a> that will host the project for us.</p>
<p>The Personal theme is quite assuredly <a href="https://www.google.com/webmasters/tools/mobile-friendly/?url=alexking.org">mobile-friendly</a>, which makes it a great fit for the importance Google&#8217;s is placing on mobile-friendly sites lately.</p>
<p>You can download from the <a href="https://github.com/alexkingorg/wp-personal/releases">releases page</a> on GitHub or, for you technically minded, grab the reop with git. Just make sure to also grab the submodules.</p>
<p><code>git clone git@github.com:alexkingorg/wp-personal.git<br />
cd wp-personal<br />
git submodule update --init --recursive</code></p>
<p class="threads-post-notice">This post is part of the project: <a href="http://alexking.org/project/personal">Personal Theme</a>. View the project timeline for more context on this post.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 22 Aug 2015 19:11:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:80:"WPTavern: WordCampus a Conference Devoted to Using WordPress in Higher Education";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47853";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://wptavern.com/wordcampus-a-conference-devoted-to-using-wordpress-in-higher-education";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1861:"<p>Higher education is a subject that <a href="http://wordpress.tv/?s=education">some WordCamps</a> have tackled over the years, but what if there was an event entirely devoted to it? That&#8217;s the idea <a href="http://bamadesigner.com">Rachel Carden</a> is proposing with <a href="http://wpcampus.org/">WordCampus</a>. The idea started off as a tweet but quickly gained momentum with others in the community.</p>
<blockquote class="twitter-tweet" width="550"><p lang="en" dir="ltr">Ooh. Dream with me: "<a href="https://twitter.com/hashtag/WordCampus?src=hash">#WordCampus</a>: A WordCamp for folks using <a href="https://twitter.com/hashtag/WordPress?src=hash">#WordPress</a> in Higher Education." I like it. <a href="https://twitter.com/hashtag/heweb?src=hash">#heweb</a> <a href="https://t.co/m1zEkpkP4B">https://t.co/m1zEkpkP4B</a></p>
<p>&mdash; Rachel Carden (@bamadesigner) <a href="https://twitter.com/bamadesigner/status/628324358126235648">August 3, 2015</a></p></blockquote>
<p></p>
<p>WordCampus is an event that would cover topics such as, how to manage a large-scale network of faculty blogs, abiding by FERPA regulations, or how to best implement single sign-on that integrates with Active Directory.</p>
<p>Carden <a href="https://poststatus.com/wordpress-higher-ed-conference-wordcampus/">outlines her idea in detail</a> on Post Status and says that even though camp is in the event&#8217;s name, it doesn&#8217;t imply that it would be an official WordCamp event. She&#8217;s also open to organizing an event not affiliated with the WordPress Foundation.</p>
<p>If you&#8217;re interested in speaking, sponsoring, or attending WordCampus, please <a href="http://wpcampus.org/">fill out the survey </a>and help spread the word. The more interest Carden generates, the more likely it is that the WordPress Foundation will back the event.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Aug 2015 19:40:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"WPTavern: What Do You Want to See in WordPress 4.4?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47850";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wptavern.com/what-do-you-want-to-see-in-wordpress-4-4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1220:"<p>Scott Taylor, who is <a href="http://wptavern.com/wordpress-core-team-announces-release-leads-for-wordpress-4-3-and-4-4">leading the development cycle</a> for WordPress 4.4, <a href="https://make.wordpress.org/core/2015/08/19/wordpress-4-4-whats-on-your-wishlist/">published a post</a> on the Make WordPress Core site asking people what they&#8217;d like to see in WordPress 4.4. The post has generated a number of comments from the community. Some of the most popular suggestions include:</p>
<ul>
<li>REST API</li>
<li>Fields API</li>
<li>Term Meta</li>
<li>Shortcake UI</li>
<li><a href="https://core.trac.wordpress.org/ticket/31467">Ticket 31467</a> Images should default to not linking</li>
<li>RICG Responsive Images</li>
<li>Posts 2 Posts</li>
</ul>
<p>Most of the items suggested are at various stages of development and there&#8217;s no guarantee any of them will make it into WordPress 4.4. However, the comments provide insight into what a lot of developers want in WordPress.</p>
<p>If there&#8217;s a ticket, feature, or plugin you&#8217;d like to see in WordPress 4.4, please <a href="https://make.wordpress.org/core/2015/08/19/wordpress-4-4-whats-on-your-wishlist/">leave a comment</a> on the post.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Aug 2015 18:16:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WPTavern: WPWeekly Episode 204 – Overview of WordPress 4.3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47844";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wptavern.com/wpweekly-episode-204-overview-of-wordpress-4-3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2272:"<p>In this week&#8217;s episode of WordPress Weekly, <a href="http://marcuscouch.com/">Marcus Couch</a> and I review WordPress 4.3. We discuss the Kim Parsell memorial scholarship and the events that led to its creation. We also discuss Nick Haskins&#8217; rebrand of Lasso. Last but not least, we spread the news that Automattic is hiring.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/wordpress-4-3-billie-named-after-jazz-singer-billie-holiday-is-available-for-download">WordPress 4.3 “Billie” Named After Jazz Singer Billie Holiday Is Available</a><br />
<a href="http://wptavern.com/the-wordpress-foundation-begins-accepting-applications-for-the-kim-parsell-memorial-scholarship"> The WordPress Foundation Begins Accepting Applications for the Kim Parsell Memorial Scholarship</a><br />
<a href="http://wptavern.com/nick-haskins-rebrands-lasso-to-editus"> Nick Haskins Rebrands Lasso to Editus</a><br />
<a href="https://automattic.com/work-with-us/">Automattic is Hiring</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href="https://wordpress.org/plugins/wp-remote-multisite-post/">WP Remote Multisite Post</a> allows for advanced remote posting from a WordPress master site to many WordPress client sites using XML-RPC.</p>
<p><a href="https://wordpress.org/plugins/fb-group-feed/">FB Group Feed</a> is a plugin to display Facebook group posts or a feed on your site in a post or a widget.</p>
<p><a href="https://wordpress.org/plugins/wp-webinarsystem/">WP Webinar System</a> allows you to run webinars within your WordPress website and customize everything around it.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, August 26th 4:00 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #204:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Aug 2015 17:28:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:105:"WPTavern: The WordPress Foundation Begins Accepting Applications for the Kim Parsell Memorial Scholarship";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47835";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:115:"http://wptavern.com/the-wordpress-foundation-begins-accepting-applications-for-the-kim-parsell-memorial-scholarship";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2885:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/01/KimParsell.png"><img class="size-full wp-image-36619" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/01/KimParsell.png?resize=655%2C418" alt="WordCamp San Francisco 2014 By Sheri Bigelow" /></a>WordCamp San Francisco 2014 By Sheri Bigelow
<p>Earlier this year, the WordPress Foundation <a href="https://make.wordpress.org/community/2015/01/15/remembering-kim-parsell/">created a scholarship</a> in memory of <a href="http://wptavern.com/kim-parsell-affectionately-known-as-wpmom-passes-away">Kim Parsell</a> to celebrate her life and contributions to WordPress. With the date and location secured for <a href="http://wptavern.com/philadelphia-pa-to-host-wordcamp-us-december-4th-6th">WordCamp US</a>, applications for the scholarship are now <a href="http://wordcampcentral.polldaddy.com/s/kim-parsell-scholarship-application">being accepted</a> by the Foundation.</p>
<p>Details of the scholarship are as follows:</p>
<ul>
<li>It is a scholarship for a woman contributor with financial need who has never attended WordCamp San Francisco before.</li>
<li>It will cover the ticket cost, flight, and lodging.</li>
<li>It will not cover things like taxis, meals outside the official event, or airport transportation.</li>
<li>One scholarship is awarded per year.</li>
<li>It is funded by the WordPress Foundation.</li>
<li>The application deadline is September 2, 2015.</li>
<li>A decision will be made by September 16, 2015, and applicants contacted.</li>
</ul>
<p>Because of the nature of this scholarship <a href="https://make.wordpress.org/community/2015/01/15/remembering-kim-parsell/">explained here</a>, applicants must fulfill four requirements.</p>
<ol>
<li>A woman (this includes trans women)</li>
<li>An active contributor to the WordPress open source project (through one of the contributor teams or as a local meetup/WordCamp organizer)</li>
<li>Someone with financial need</li>
<li>Someone who has never attended WordCamp San Francisco (the precursor to WCUS).</li>
</ol>
<p>Kim was an older woman who encouraged others, especially women around the same age group to get involved with WordPress. In light of this, older women are highly encouraged to apply for the scholarship if you meet the other requirements.</p>
<p>Kim once told me that attending WordCamp San Francisco 2014 was one of the best experiences of her life. It was her first WordCamp San Francisco and although she was unemployed at the time, she was able to attend thanks to financial assistance received from the <a title="http://wordpressfoundation.org/" href="http://wordpressfoundation.org/">WordPress Foundation</a>.</p>
<p>Thank you to Jen Mylo, the WordPress Foundation, and Matt Mullenweg for not only creating the scholarship, but for providing the opportunity for others to potentially have the same experience.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 19 Aug 2015 20:18:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"WPTavern: Hybrid Core 3.0 Experiments With Community-driven Documentation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47825";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://wptavern.com/hybrid-core-3-0-experiments-with-community-driven-documentation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2762:"<p>Hybrid Core 3.0, developed by Justin Tadlock, is <a href="http://themehybrid.com/weblog/hybrid-core-version-3-0-mr-reynolds">available for download</a>. More than a year in the making, 3.0 has over 269 commits and a slew of new features.</p>
<p>After the release of Hybrid Core 2.0 last year, Tadlock assumed it would be at least two years before he tackled another major release, &#8220;I’d planned on doing minor and patch releases for a while, all along building themes,&#8221; he said.</p>
<p>&#8220;However, a lot has changed in the theming world in just the past year. WordPress has added a lot of cool features for theme authors that were previously handled by Hybrid Core,&#8221; Tadlock said.</p>
<p>Tadlock wants the project to feel fresh and one way to do that is to remove features that are handled natively by WordPress. Features removed from Hybrid Core include:</p>
<ul>
<li>Atomic hooks functionality.</li>
<li>Random Custom Background extension.</li>
<li>Featured Header extension.</li>
<li>Cleaner Caption extension (handled in WP).</li>
<li>Loop title/description (replaced by WP).</li>
<li>Pagination (replaced by WP).</li>
</ul>
<p>It&#8217;s clear that the <a href="https://make.wordpress.org/core/2015/06/09/trust-live-preview-and-menus-in-the-customizer/">customizer in WordPress is here to stay</a> and will be an important part of the project&#8217;s future. Hybrid Core 3.0 adds a variety of enhancements that make the customizer more flexible, these include:</p>
<ul>
<li>Color Palette.</li>
<li>Multiple Checkbox.</li>
<li>Dropdown Terms.</li>
<li>Layout.</li>
<li>Radio Image.</li>
<li>Select Group.</li>
<li>Multiple Select.</li>
</ul>
<p>There&#8217;s also a few customizer setting classes:</p>
<ul>
<li>Array Map.</li>
<li>Image Data.</li>
</ul>
<h2>Tadlock Experiments with Community-driven Documentation</h2>
<p>One of the largest changes to the Hybrid project is opening up documentation to be community-driven. The <a href="https://github.com/justintadlock/hybrid-core/wiki">Hybrid Core wiki</a> hosted on Github is now open to contributions from the community.</p>
<p>Tadlock believes that this will drive adoption of the framework by more theme authors, &#8220;The more developers we have using and contributing to the project, the better,&#8221; he said.</p>
<p>If the community responds well to the experiment, it will allow Tadlock to focus on longer-form tutorials for club members, something he feels he&#8217;s better at doing than reference style documentation.</p>
<p>Hybrid Core 3.0 includes a number of features, bug fixes, and improvements. If you want to see all of the changes in 3.0, check out the <a href="https://github.com/justintadlock/hybrid-core/blob/master/changelog.md">lengthy changelog</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 19 Aug 2015 19:38:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"Matt: 1.6m Downloads in 23 Hours";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45306";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://ma.tt/2015/08/1-6m-downloads-in-23-hours/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:344:"<p></p>
<p>23 hours hours ago, WordPress 4.3 was released. <a href="https://wordpress.org/download/counter/">It&#8217;s already had 1.6 million downloads and counting</a>. For a look at what&#8217;s new in this version you can watch the quick video above, or <a href="https://wordpress.org/news/2015/08/billie/">check out the blog post</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 19 Aug 2015 18:01:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:101:"WPTavern: WordPress 4.3 “Billie” Named After Jazz Singer Billie Holiday Is Available for Download";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47803";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:105:"http://wptavern.com/wordpress-4-3-billie-named-after-jazz-singer-billie-holiday-is-available-for-download";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:10229:"<p>After four months of development led by <a href="http://konstantin.obenland.it/">Konstantin Obenland</a>, WordPress 4.3 &#8220;Billie&#8221; named after jazz singer <a href="http://www.billieholiday.com/">Billie Holiday</a>, is <a href="https://wordpress.org/news/2015/08/billie/">available for download</a>. This release features menus in the customizer, strong passwords by default, site icons, and variety of other improvements.</p>
<p></p>
<p></p>
<h2>Menus in the Customizer</h2>
<p>You can now create, add, and edit menus in the customizer while previewing changes to your site in real-time. Unlike other parts of the customizer, previewing menus should be fast as it uses a new hybrid transport layer. Weston Ruter, who contributed to fast previews in the customizer <a href="https://make.wordpress.org/core/2015/07/29/fast-previewing-changes-to-menus-in-the-customizer/">explains the approach</a>.</p>
<blockquote><p>We also wanted to enable fast previewing of menu changes by default. So we implemented a <code>postMessage</code>/<code>refresh</code> hybrid approach which uses <code>postMessage</code> to sync the menus settings to the preview, and then the preview does an Ajax request to render just the contents of the menu container, and this Ajax response is then inserted into the DOM to replace the previous menu container. The technical name for this approach we have been calling &#8216;partial refresh&#8217;, but you can call it fast preview.</p></blockquote>
<p>In general, previewing menus in most themes should be a fast experience.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/menu-customizer.png"><img class="size-full wp-image-47806" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/menu-customizer.png?resize=1010%2C568" alt="Menu Customizer" /></a>Menu Customizer
<h2>Strong Passwords by Default</h2>
<p>Mark Jaquith <a href="https://make.wordpress.org/core/2015/07/28/passwords-strong-by-default/">led the effort</a> to improve the way passwords are chosen and changed in WordPress. On the account management page, clicking the Generate Password button generates a strong password by default. The password strength meter is better integrated into the password field which lets users know immediately when their password is weak.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/better-passwords.png"><img class="size-full wp-image-47807" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/better-passwords.png?resize=1010%2C568" alt="Better Passwords in WordPress" /></a>Better Passwords in WordPress
<p>The same interface is on the add new user screen, the password reset screen, and the WordPress install screen. While WordPress doesn&#8217;t require users to have a strong password, it does everything it can to encourage users to choose one.</p>
<p>In addition, WordPress no longer emails passwords and password reset links expire after 24 hours. When your password or e-mail changes, WordPress sends you an email so if someone hijacks your browser session and changes these items, you’ll be notified that it happened, and you can take action. You can disable these e-mails via the <code>send_pass_change_email</code> and <code>send_email_change_email</code> filters by setting them to false.</p>
<h2>Site Icons</h2>
<p><a href="http://wptavern.com/wordpress-4-3-adds-new-site-icons-feature-and-a-text-editor-to-press-this">Site Icons</a> are images that represent a website across multiple platforms. You can configure your Site Icon in the Site Identity panel within the customizer where you can upload a 512X512 sized image. This image will be used for browsers, iOS, Android, and Microsoft devices when a visitor bookmarks your site.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/site-icon-customizer.png"><img class="size-full wp-image-47808" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/site-icon-customizer.png?resize=1010%2C568" alt="Site Icons in The Customizer" /></a>Site Icons in The Customizer
<h2>Text Patterns, Quick Link Toolbar, and Word Count Changes</h2>
<p>The editor in WordPress 4.3 has <a href="http://wptavern.com/text-patterns-and-the-quick-link-toolbar-in-wordpress-4-3">undergone more improvements</a> with text shortcuts, a quick link toolbar, and word count changes. Text patterns or text shortcuts allow you to quickly add unordered lists, ordered lists, headers, and blockquotes without having to use a mouse.</p>
<p>When starting a new paragraph with one of these formatting shortcuts followed by a space, the formatting will be applied automatically. Press Backspace or Escape to undo.</p>
<p>In the visual editor in WordPress 4.3, typing <code>*</code> or <code>-</code> and hitting the space bar will generate a bulleted list. Typing <code>1. </code> or  <code>1)</code> and hitting space will generate a numbered list. If you don’t want to create these lists or do so in error, clicking the undo button or hitting <code>ctrl/cmd+z</code> or <code>esc</code> will undo the text pattern.</p>
<p>Starting a paragraph with two to six number signs <code>#</code> will convert the paragraph to a heading. Similarly, the greater-than symbol <code>&gt;</code> will convert the paragraph to a blockquote.</p>
<ul>
<li>## = H2</li>
<li>### = H3</li>
<li>#### = H4</li>
<li>##### = H5</li>
<li>###### = H6</li>
</ul>
<h3>Quick Link Preview Toolbar</h3>
<p>When you click a link in the WordPress 4.3 visual editor, a small inline link toolbar displays the full URL with buttons to edit or remove it. This avoids having to use the Insert/edit link modal window.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/PreviewLinks.png"><img class="size-full wp-image-47792" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/PreviewLinks.png?resize=571%2C102" alt="Preview Links in The Visual Editor WordPress 4.3" /></a>Preview Links in The Visual Editor WordPress 4.3
<p>Word and character counts have also changed in WordPress 4.3. Instead of updating counts when pressing enter or return, it will refresh when you stop typing. A lot more characters that shouldn’t be counted as words are excluded. Ella Iseulde Van Dorpe, WordPress core contributor, <a href="https://make.wordpress.org/core/2015/07/23/wordcharacter-count-updates-in-4-3/">lists other notable changes</a>.</p>
<h2>Changes to the Admin Bar</h2>
<p>WordPress 4.3 moves the Customize link to the top-level menu of the admin bar. This link opens the customizer, allowing you to manage menus, appearance, and widgets through the customizer interface.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/WP42AdminBar.png"><img class="wp-image-46995 size-full" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/WP42AdminBar.png?resize=429%2C232" alt="WordPress 4.2 Admin Bar" /></a>WordPress 4.2 Admin Bar
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/WP43AdminBar.png"><img class="wp-image-46996 size-full" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/WP43AdminBar.png?resize=428%2C202" alt="WP43AdminBar" /></a>WordPress 4.3 Admin Bar
<p>The Dashboard, Themes, Widgets, and Menus links take users to their corresponding admin pages in the backend of WordPress. This makes it clear which interface users are about to enter. The enhancement is a result of <a href="https://core.trac.wordpress.org/ticket/32678">ticket #32678</a> where Helen Hou-Sandí and other WordPress core contributors discussed ways to improve the context of each link over the course of five weeks.</p>
<h2>Noteworthy Changes</h2>
<ul>
<li><a href="http://wptavern.com/wordpress-4-3-improves-user-search-and-turns-comments-off-on-pages-by-default">Comments are turned off on pages by default</a>.</li>
<li><a href="https://make.wordpress.org/core/2015/07/02/deprecating-php4-style-constructors-in-wordpress-4-3/">PHP-4 Style constructors have been deprecated</a> to prepare for the release of PHP 7.</li>
<li>Singular.php was added to the <a href="https://make.wordpress.org/core/2015/07/06/singular-php-new-theme-template-in-wordpress-4-3/">WordPress template hierarchy.</a></li>
<li>Changes to c<a href="https://make.wordpress.org/core/2015/07/27/changes-to-customizer-panels-and-sections-in-4-3/">ustomizer panels and sections.</a></li>
<li><a href="https://make.wordpress.org/core/2015/07/31/headings-in-admin-screens-change-in-wordpress-4-3/">Header tags were updated through the admin screens</a>. Plugin, theme, and framework developers, please change the main heading from an <code>&lt;h2&gt;</code> into an <code>&lt;h1&gt;</code>. Also, check the rest of your heading structure to ensure it’s semantic.</li>
<li><a href="https://make.wordpress.org/core/2015/07/24/multisite-focused-changes-in-4-3/">Multisite focused changes in 4.3</a> specifically, the introduction of get_main_network_id()</li>
<li><a href="https://make.wordpress.org/core/2015/07/30/get_transient-is-now-more-strict-in-4-3/">get_transient() is now more strict in 4.3</a></li>
<li>The old <a href="https://make.wordpress.org/core/2015/07/29/old-distraction-free-writing-code-removed-in-4-3/">Distraction Free Writing (DFW) code has been removed</a>.</li>
<li>The code that powered the <a href="https://make.wordpress.org/core/2015/07/30/legacy-theme-preview-removed-in-4-3/">old theme preview has been removed</a>.</li>
<li><a href="https://make.wordpress.org/core/2015/08/08/list-table-changes-in-4-3/">List tables have undergone API and UI changes</a>, with the introduction of a primary column concept and easier subclassing.</li>
</ul>
<p>WordPress 4.3 is the result of hundreds of paid and non-paid volunteers working tirelessly to improve the software used on more than 24% of the web. If you experience any issues with WordPress 4.3, please <a href="https://wordpress.org/support/">report them on the support forums</a>. Volunteers are watching support threads closely and if warranted, will create a thread listing known issues.</p>
<p>To enjoy the full upgrade experience, I encourage you to listen to Lady sings The Blues by Billie Holiday as you upgrade your WordPress sites.</p>
<p><span class="embed-youtube"></span></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Aug 2015 19:13:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Matt: Automattic is Hiring";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45297";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://ma.tt/2015/08/automattic-is-hiring-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:635:"<p>Do you know someone who is an amazing developer or designer? Someone who is passionate about helping people? An awesome lounge manager? Or maybe that person is you. <a href="https://automattic.com/work-with-us/">Automattic is hiring for a variety of positions</a>, and for all except two you can live and work wherever you like in the entire planet. There are also a number of other benefits; the main downside it&#8217;s a high performance culture and expectations are extremely high. Automattic hires the best folks regardless of geography, and we are <em>especially</em> looking for people right now outside of US timezones.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Aug 2015 16:05:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: Text Patterns and the Quick Link Toolbar in WordPress 4.3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=47790";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wptavern.com/text-patterns-and-the-quick-link-toolbar-in-wordpress-4-3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4590:"<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/QuickLinkToolbarFeaturedImage.png"><img class="size-full wp-image-47794" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/QuickLinkToolbarFeaturedImage.png?resize=675%2C209" alt="Quick Link Toolbar Featured Image" /></a>photo credit: <a href="http://www.flickr.com/photos/34547181@N00/4309431757">metal chain</a> &#8211; <a href="https://creativecommons.org/licenses/by-nd/2.0/">(license)</a>
<p>WordPress 4.3 is on schedule to be released <a href="https://make.wordpress.org/core/version-4-3-project-schedule/">August 18th</a> and contains a number of improvements. Among the enhancements to the visual editor are text patterns. Text patterns or text shortcuts allow you to quickly add unordered lists, ordered lists, headers, and blockquotes without having to use a mouse.</p>
<p>In the visual editor in WordPress 4.3, typing <code>*</code> or <code>-</code> and hitting the space bar will generate a bulleted list. Typing <code>1. </code> or  <code>1)</code> and hitting space will generate a numbered list. If you don&#8217;t want to create these lists or do so in error, clicking the undo button or hitting <code>ctrl/cmd+z</code> or <code>esc</code> will undo the text pattern.</p>
<p>Starting a paragraph with two to six number signs <code>#</code> will convert the paragraph to a heading. Similarly, the greater-than symbol <code>&gt;</code> will convert the paragraph to a blockquote.</p>
<ul>
<li>## = H2</li>
<li>### = H3</li>
<li>#### = H4</li>
<li>##### = H5</li>
<li>###### = H6</li>
</ul>
<p>It took a few tries to figure out but once I got the hang of it, I discovered that I prefer using text patterns versus clicking the appropriate button in the editor.</p>
<p>For example, the blockquote text pattern places text into a blockquote and automatically closes it while also starting a new paragraph. Traditionally, I highlight text and click on the blockquote button in the editor. Often times, I have to visit the text editor and close the blockquote to start a new paragraph.</p>
<p>Ryan Boren, WordPress core lead developer, created the <a href="https://make.wordpress.org/core/2015/08/01/editor-enhancements-in-4-3-%E2%9C%A8/">following video</a> which shows the text patterns in action on a mobile device.</p>
<h2>Quick Previews of Links</h2>
<p>WordPress 4.2 included a subtle but convenient feature for adding links to text. Pasting the URL to highlighted text automatically turns it into a link. The problem is that there isn&#8217;t an easy way to preview the URL without opening it in a new browser tab.</p>
<p>When you click a link in the WordPress 4.3 visual editor, a small inline link toolbar displays the full URL with buttons to edit or remove it. This avoids having to use the Insert/edit link modal window.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/PreviewLinks.png"><img class="size-full wp-image-47792" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/PreviewLinks.png?resize=571%2C102" alt="Preview Links in The Visual Editor WordPress 4.3" /></a>Preview Links in The WordPress 4.3 Visual Editor
<h2>Changes to Word and Character Counts</h2>
<p>Word and character counts have also changed in WordPress 4.3. Instead of updating counts when pressing enter or return, it will refresh when you stop typing. A lot more characters that shouldn&#8217;t be counted as words are excluded. Ella Iseulde Van Dorpe, WordPress core contributor, <a href="https://make.wordpress.org/core/2015/07/23/wordcharacter-count-updates-in-4-3/">lists other notable changes</a>.</p>
<ul>
<li>For <strong>character</strong> count, we no longer exclude any of these characters. This means that numbers and common western punctuation are no longer excluded compared to 4.2. Emoji and other astral characters are now counted as one character instead of two.</li>
<li>We added a new type <strong>all</strong>, in addition to words and characters, that will count characters including spaces. This seemed necessary for Japanese and maybe other languages. This is now <code>character_including_spaces</code> and <code>character_excluding_spaces</code>.</li>
<li>Shortcodes and HTML comments are now excluded.</li>
</ul>
<p>To view details and a summary of all the work that went into improving word counts, check out <a href="https://core.trac.wordpress.org/ticket/30966">ticket #30966</a> on trac. As someone who uses the WordPress content editor for a living, I&#8217;m anxiously looking forward to utilizing these enhancements on an everyday basis.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 17 Aug 2015 22:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"Post Status: A WordPress conference for higher education: coming to a campus near you?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"https://poststatus.com/?p=14001";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"https://poststatus.com/wordpress-higher-ed-conference-wordcampus/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8684:"<p><em><strong>Editor&#8217;s Note</strong>: Thus far, there have been numerous niche WordPress conferences aiming toward for-profit initiatives and geared toward businesses, marketers, or eCommerce site owners. But <a href="http://bamadesigner.com/">Rachel Carden</a>&#8216;s concept for a niche, education focused, non-profit event is unique and I&#8217;d love to see it happen.</em></p>
<p><em>As she notes, universities have unique challenges for managing websites and are also great candidates for utilizing WordPress to its full potential. What follows is her pitch and public brainstorming session on what a <a href="http://wordcampus.org/">higher education focused WordPress conference</a> might look like.</em></p>
<p>This all started with a tweet.</p>
<blockquote class="twitter-tweet" width="550"><p lang="en" dir="ltr">Ooh. Dream with me: "<a href="https://twitter.com/hashtag/WordCampus?src=hash">#WordCampus</a>: A WordCamp for folks using <a href="https://twitter.com/hashtag/WordPress?src=hash">#WordPress</a> in Higher Education." I like it. <a href="https://twitter.com/hashtag/heweb?src=hash">#heweb</a> <a href="https://t.co/m1zEkpkP4B">https://t.co/m1zEkpkP4B</a></p>
<p>&mdash; Rachel Carden (@bamadesigner) <a href="https://twitter.com/bamadesigner/status/628324358126235648">August 3, 2015</a></p></blockquote>
<p></p>
<p>WordCamp U.S. made a big announcement that was all over Twitter, Chris Lema tweeted what we were all thinking, and I couldn’t help but start daydreaming about the possibilities.</p>
<p>You see, I’m a web designer and developer with a passion for all things WordPress, especially using WordPress to build the world of higher ed web. Having spent the last 8 years working in higher education, I’m always looking for ways to utilize the power of WordPress to fulfill my campus’s needs and to help its communication grow, whether it’s using the powerful CMS to stretch limited resources or using its new API capabilities to share information, and break down silos, across campus departments.</p>
<p>I love attending WordCamps and other WordPress-related events, but the issues we generally encounter in higher ed are often overlooked.</p>
<p>Much like online businesses or blogging, higher ed is a world of its own with unique challenges, content, stakeholders, and target audiences. In our world, we don’t worry so much about which eCommerce plugin is best. Instead, we’re more concerned with things like how to manage a large-scale network of faculty blogs, making sure we’re abiding with FERPA regulations, or wondering how to best implement single sign-on that integrates with Active Directory.</p>
<p>That’s why I’m proposing a new event in the WordPress community: a conference focused on using WordPress in the world of higher education. I call the idea “WordCampus”. (Kind of a perfect name, right? How did nobody think of this before?)</p>
<p>The name “WordCampus” came to me from a tweet and does not, at this point, imply it would be an official WordCamp event. If needed, I’m open to organizing an event that is not affiliated with the WordPress Foundation. This is a detail that remains to be seen, but honestly, at this point, all details remain to be seen. A WordCamp representative has confirmed that a user group specific WordCamp is possible, but I would need to prove that it could draw a crowd. That’s why I need your help.</p>
<p>If a WordPress conference for higher ed is something you would be interested in (whether it’s as an attendee, speaker, planner, sponsor, or all of the above), I invite you to read a few of my thoughts, share yours in the comments, and visit <a href="http://wordcampus.org/">wordcampus.org</a> to show your support.</p>
<h3>Cost and fee consideration</h3>
<p>Much like your usual WordCamp, the goal for this event is to keep the costs and ticket price as low as possible. The point of this event is professional development and community, not profit. The phrases “big budget” and “higher ed” don’t generally appear in the same sentence anyway.</p>
<p>A lot of higher ed-oriented web conferences can run upwards of $500 so an inexpensive, but valuable, event would be attractive for most higher education web professionals.</p>
<h3>Unique sponsorship opportunity</h3>
<p>Having sponsors to help with costs would be crucial and I am open to all kinds of support, whether it’s monetary or in-kind. Sponsoring an event like WordCampus would be a unique way to get an organization’s name in front of one of the best communities <em>outside</em> of WordPress that <em>uses</em> WordPress all the time.</p>
<p>In the world of higher education, you often have limited resources, so there are plenty of opportunities for third party products or services like hosting, themes, plugins, custom design, accessibility consulting, and custom development, among others.</p>
<h3>Location is a factor</h3>
<p>The location could be a sticking point, as high travel costs might be a deal breaker for many WordCampus attendees. The beauty of local WordCamps is that they are tied to a geographical region and therefore, for most attendees, have limited travel requirements. This could be a problem for an event that is not tied to a specific region.</p>
<p>Venue wise, universities have beautiful facilities, so I’d love to host the event on an actual college campus and, if the hosting university could donate the space in kind, this would be a huge cost saver. The most preferable universities would also be located near a major airport to help reduce travel time.</p>
<p>If I’m really dreaming big, it would be great to find numerous universities that would be willing to host and, therefore, we could have regional WordCampus events spread across the country. I don’t think this is outside the realm of possibility, but would depend on interest and attendance. I&#8217;m certainly interested in hearing from anyone that may be interested in hosting WordCampus at their university.</p>
<h3>A big target audience</h3>
<p>There are a wide variety of WordPress users in higher ed, from the university-level WordPress developers and administrators, to the users who run WordPress for a college, to the faculty members using WordPress as a learning tool, and any students who’d love to learn a thing or two (they are our future, you know). That’s not even including content strategists, designers, social media managers, and more.</p>
<p>WordCampus has the potential to attract a variety of users who could inspire a multitude of topics and professional development.</p>
<h3>A broad variety of topics, even within the education umbrella</h3>
<p>Speaking of topics, these could also run the gamut from higher ed marketing and content strategy to infrastructure, managing multi-author blogs, and streamlining application processes. Accessibility should also be a featured topic as federally funded institutions are required by law to make their electronic and information technology accessible to people with disabilities.</p>
<p>Personally, I see the structure of higher ed as tailor-made for the open source mindset and would love to hear someone encourage collaboration and openness by comparing the ideologies of open source with the inner workings of higher education.</p>
<h3>Event timing</h3>
<p>As organizing something of this magnitude takes time, I’m looking at a 2016 booking. What time of the year in 2016, however, remains to be seen. There are obviously a lot of variables at play, from venue availability to which time of the year is best for our target attendees. In higher ed, you need time to clear your schedule and request funding, so I’d want to allow for that.</p>
<p>Usually, the middle of the semester is best for most higher ed professionals, but this can vary depending on their field. And if we’re being honest, the majority of fall might be out of the question because of football season. We’ve included a straw poll <a href="http://wordcampus.org">on the event landing page</a> to help us gauge which time of year might be best for those interested in attending.</p>
<p>Thank you for taking the time to read through my proposal and hopefully interested parties will have a few additional thoughts for the comments. If you would like be notified of any future developments, or show your support for the project, please visit <a href="http://wordcampus.org">wordcampus.org</a> to share a little bit of information. And don’t forget to tell your friends!</p>
<p>If you have any questions, or would like to chat, you can also find me on Twitter <a href="https://twitter.com/bamadesigner">@bamadesigner</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 17 Aug 2015 21:33:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Rachel Carden";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Matt: Artisanal Water";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=45285";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:27:"http://ma.tt/2015/08/water/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:301:"<p></p>
<p>Many of my friends know how obsessed I am with different types of water, from <a href="http://www.badoit.com/">Badoit</a> to <a href="https://www.drinkhint.com/">Hint Water (yum)</a> to <a href="http://delaubier.ca/site_en.html">De L&#8217;aubier</a>. This definitely hit close to home.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 17 Aug 2015 06:38:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Tue, 15 Sep 2015 20:10:42 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"202284";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Tue, 15 Sep 2015 19:45:16 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 250";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130911090210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (2672, '_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1442391042', 'no') ; 
INSERT INTO `wp_options` VALUES (2673, '_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1442347842', 'no') ; 
INSERT INTO `wp_options` VALUES (2674, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1442391043', 'no') ; 
INSERT INTO `wp_options` VALUES (2675, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:117:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"WordPress Plugins » View: Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"https://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:34:"WordPress Plugins » View: Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Sep 2015 19:38:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:30:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2082@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29832@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:138:"The Wordfence WordPress security plugin provides free enterprise-class WordPress security, protecting your website from hacks and malware.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Advanced Custom Fields";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/plugins/advanced-custom-fields/#post-25254";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Mar 2011 04:07:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"25254@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:68:"Customise WordPress with powerful, professional and intuitive fields";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"elliotcondon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"15@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"https://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"23862@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:28:"Your WordPress, Streamlined.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Really Simple CAPTCHA";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"https://wordpress.org/plugins/really-simple-captcha/#post-9542";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Mar 2009 02:17:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"9542@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:138:"Really Simple CAPTCHA is a CAPTCHA module intended to be called from other plugins. It is originally created for my Contact Form 7 plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WP Super Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/wp-super-cache/#post-2572";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Nov 2007 11:40:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2572@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:73:"A very fast caching engine for WordPress that produces static html files.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Donncha O Caoimh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"132@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Arne Brachhold";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"1169@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 13 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29860@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"WP-PageNavi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/wp-pagenavi/#post-363";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 23:17:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"363@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:49:"Adds a more advanced paging navigation interface.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Lester Chan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"753@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2141@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"W3 Total Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/plugins/w3-total-cache/#post-12073";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 29 Jul 2009 18:46:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"12073@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:132:"Easy Web Performance Optimization (WPO) using caching: browser, page, object, database, minify and content delivery network support.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"18101@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Google Analytics by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"https://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Sep 2007 12:15:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2316@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:124:"Track your WordPress site easily with the latest tracking codes and lots added data for search result pages and error pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Regenerate Thumbnails";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"https://wordpress.org/plugins/regenerate-thumbnails/#post-6743";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 23 Aug 2008 14:38:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"6743@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:76:"Allows you to regenerate your thumbnails after changing the thumbnail sizes.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:25:"Alex Mills (Viper007Bond)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:9:"Yoast SEO";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"https://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"8321@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:114:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast SEO plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Hello Dolly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"https://wordpress.org/plugins/hello-dolly/#post-5790";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 29 May 2008 22:11:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"5790@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Duplicate Post";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/duplicate-post/#post-2646";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 05 Dec 2007 17:40:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2646@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:22:"Clone posts and pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"lopo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Disable Comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"https://wordpress.org/plugins/disable-comments/#post-26907";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 May 2011 04:42:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"26907@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:134:"Allows administrators to globally disable comments on their site. Comments can be disabled according to post type. Multisite friendly.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Samir Shah";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WP Multibyte Patch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wp-multibyte-patch/#post-28395";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Jul 2011 12:22:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"28395@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Multibyte functionality enhancement for the WordPress Japanese package.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"plugin-master";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:27:"Black Studio TinyMCE Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"https://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Nov 2011 15:06:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"31973@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"The visual editor widget for Wordpress.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Marco Chiesi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"21738@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"Protect your WordPress site by hiding vital areas of your site, protecting access to important files, preventing brute-force login attempts, detecting";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Page Builder by SiteOrigin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/plugins/siteorigin-panels/#post-51888";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 11 Apr 2013 10:36:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"51888@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:111:"Build responsive page layouts using the widgets you know and love using this simple drag and drop page builder.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Greg Priday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Meta Slider";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/ml-slider/#post-49521";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Feb 2013 16:56:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"49521@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:145:"Easy to use WordPress slider plugin. Create SEO optimised responsive slideshows with Nivo Slider, Flex Slider, Coin Slider and Responsive Slides.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Matcha Labs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Google Analytics Dashboard for WP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"https://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Mar 2013 17:07:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"50539@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:127:"Displays Google Analytics reports in your WordPress Dashboard. Inserts the latest Google Analytics tracking code in your pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Alin Marcu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:10:"Duplicator";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"https://wordpress.org/plugins/duplicator/#post-26607";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 16 May 2011 12:15:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"26607@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:88:"Duplicate, clone, backup, move and transfer an entire site from one location to another.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Cory Lamle";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Google Analytics";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wordpress.org/plugins/googleanalytics/#post-11199";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 09 Jun 2009 22:09:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"11199@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:38:"Enables google analytics on all pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Kevin Sylvestre";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"UpdraftPlus Backup and Restoration";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/updraftplus/#post-38058";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 May 2012 15:14:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"38058@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Backup and restoration made easy. Complete backups; manual or scheduled (backup to S3, Dropbox, Google Drive, Rackspace, FTP, SFTP, email + others).";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"David Anderson";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:46:"https://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:12:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Tue, 15 Sep 2015 20:10:43 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:25:"strict-transport-security";s:11:"max-age=360";s:7:"expires";s:29:"Tue, 15 Sep 2015 20:13:29 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Tue, 15 Sep 2015 19:38:29 +0000";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911090210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (2676, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1442391043', 'no') ; 
INSERT INTO `wp_options` VALUES (2677, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1442347843', 'no') ; 
INSERT INTO `wp_options` VALUES (2678, '_transient_timeout_plugin_slugs', '1442434243', 'no') ; 
INSERT INTO `wp_options` VALUES (2679, '_transient_plugin_slugs', 'a:10:{i:0;s:33:"admin-menu-editor/menu-editor.php";i:1;s:34:"advanced-custom-fields-pro/acf.php";i:2;s:19:"akismet/akismet.php";i:3;s:35:"backupwordpress/backupwordpress.php";i:4;s:36:"contact-form-7/wp-contact-form-7.php";i:5;s:37:"custom-content-type-manager/index.php";i:6;s:45:"enable-media-replace/enable-media-replace.php";i:7;s:38:"post-duplicator/m4c-postduplicator.php";i:8;s:37:"post-types-order/post-types-order.php";i:9;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (2680, '_transient_timeout_dash_88ae138922fe95674369b1cb3d215a2b', '1442391044', 'no') ; 
INSERT INTO `wp_options` VALUES (2681, '_transient_dash_88ae138922fe95674369b1cb3d215a2b', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2015/09/wordpress-4-3-1/\'>WordPress 4.3.1 Security and Maintenance Release</a> <span class="rss-date">September 15, 2015</span><div class="rssSummary">WordPress 4.3.1 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. This release addresses three issues, including two cross-site scripting vulnerabilities and a potential privilege escalation. WordPress versions 4.3 and earlier are vulnerable to a cross-site scripting vulnerability when processing shortcode tags (CVE-2015-5714). Reported by [&hellip;]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://poststatus.com/gravity-flow-makes-custom-form-administrative-workflows-simple/\'>Post Status: Gravity Flow makes custom form administrative workflows simple</a></li><li><a class=\'rsswidget\' href=\'http://ma.tt/2015/09/long-days/\'>Matt: Long Days</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/a-recap-of-wordcamp-pune-india-by-topher-derosia\'>WPTavern: A Recap of WordCamp Pune, India, by Topher DeRosia</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'https://wordpress.org/plugins/black-studio-tinymce-widget/\' class=\'dashboard-news-plugin-link\'>Black Studio TinyMCE Widget</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=black-studio-tinymce-widget&amp;_wpnonce=0780e63539&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Black Studio TinyMCE Widget\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (2682, '_transient_timeout_hmbkp_directory_filesizes_running', '1442351486', 'no') ; 
INSERT INTO `wp_options` VALUES (2683, '_transient_hmbkp_directory_filesizes_running', '1', 'no') ; 
INSERT INTO `wp_options` VALUES (2684, '_transient_timeout_hm_backdrop-d8f333de92a5f61fa974a8383ccd', '1442348186', 'no') ; 
INSERT INTO `wp_options` VALUES (2685, '_transient_hm_backdrop-d8f333de92a5f61fa974a8383ccd', 'a:2:{s:8:"callback";a:2:{i:0;O:35:"HM\\BackUpWordPress\\Scheduled_Backup":4:{s:39:" HM\\BackUpWordPress\\Scheduled_Backup id";s:10:"1441997204";s:41:" HM\\BackUpWordPress\\Scheduled_Backup slug";s:0:"";s:44:" HM\\BackUpWordPress\\Scheduled_Backup options";a:7:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:5:"email";a:1:{s:5:"email";s:0:"";}s:19:"schedule_start_time";i:1442008800;s:11:"max_backups";i:7;s:14:"duration_total";i:2;s:16:"backup_run_count";i:1;}s:6:"backup";O:25:"HM\\BackUpWordPress\\Backup":22:{s:31:" HM\\BackUpWordPress\\Backup type";s:8:"database";s:43:" HM\\BackUpWordPress\\Backup archive_filename";s:59:"9zero7films-dev-1441997204-database-2015-09-15-20-11-26.zip";s:49:" HM\\BackUpWordPress\\Backup database_dump_filename";s:39:"database-9zero7films-dev-1441997204.sql";s:43:" HM\\BackUpWordPress\\Backup zip_command_path";N;s:49:" HM\\BackUpWordPress\\Backup mysqldump_command_path";N;s:52:" HM\\BackUpWordPress\\Backup existing_archive_filepath";s:0:"";s:35:" HM\\BackUpWordPress\\Backup excludes";a:14:{i:0;s:87:"/Users/Joshua/Work/9ZERO7 Films/dev/html/wp-content/backupwordpress-011083f724-backups/";i:1;s:5:".git/";i:2;s:5:".svn/";i:3;s:9:".DS_Store";i:4;s:6:".idea/";i:5;s:10:"backwpup-*";i:6;s:7:"updraft";i:7;s:12:"wp-snapshots";i:8;s:19:"backupbuddy_backups";i:9;s:14:"pb_backupbuddy";i:10;s:9:"backup-db";i:11;s:14:"Envato-backups";i:12;s:8:"managewp";i:13;s:25:"backupwordpress-*-backups";}s:31:" HM\\BackUpWordPress\\Backup root";s:40:"/Users/Joshua/Work/9ZERO7 Films/dev/html";s:29:" HM\\BackUpWordPress\\Backup db";N;s:32:" HM\\BackUpWordPress\\Backup files";a:0:{}s:41:" HM\\BackUpWordPress\\Backup excluded_files";a:0:{}s:43:" HM\\BackUpWordPress\\Backup unreadable_files";a:0:{}s:17:" * included_files";a:0:{}s:33:" HM\\BackUpWordPress\\Backup errors";a:0:{}s:35:" HM\\BackUpWordPress\\Backup warnings";a:0:{}s:41:" HM\\BackUpWordPress\\Backup archive_method";s:0:"";s:43:" HM\\BackUpWordPress\\Backup mysqldump_method";s:0:"";s:21:" * mysqldump_verified";b:0;s:19:" * archive_verified";b:0;s:16:"skip_zip_archive";b:0;s:18:" * action_callback";a:1:{i:10;a:1:{i:0;a:2:{i:0;r:3;i:1;s:9:"do_action";}}}s:19:" * default_excludes";a:13:{i:0;s:5:".git/";i:1;s:5:".svn/";i:2;s:9:".DS_Store";i:3;s:6:".idea/";i:4;s:10:"backwpup-*";i:5;s:7:"updraft";i:6;s:12:"wp-snapshots";i:7;s:19:"backupbuddy_backups";i:8;s:14:"pb_backupbuddy";i:9;s:9:"backup-db";i:10;s:14:"Envato-backups";i:11;s:8:"managewp";i:12;s:25:"backupwordpress-*-backups";}}}i:1;s:26:"recursive_filesize_scanner";}s:6:"params";a:0:{}}', 'no') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=874 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_postmeta (692 records)
#
 
INSERT INTO `wp_postmeta` VALUES (14, 10, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (15, 10, '_edit_lock', '1441943140:1') ; 
INSERT INTO `wp_postmeta` VALUES (16, 12, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (17, 12, '_edit_lock', '1390032912:1') ; 
INSERT INTO `wp_postmeta` VALUES (18, 14, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (19, 14, '_edit_lock', '1441592975:1') ; 
INSERT INTO `wp_postmeta` VALUES (20, 16, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (21, 16, '_edit_lock', '1442005241:1') ; 
INSERT INTO `wp_postmeta` VALUES (40, 20, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (41, 20, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (42, 20, '_menu_item_object_id', '12') ; 
INSERT INTO `wp_postmeta` VALUES (43, 20, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (44, 20, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (45, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (46, 20, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (47, 20, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (49, 21, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (50, 21, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (51, 21, '_menu_item_object_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (52, 21, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (53, 21, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (54, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (55, 21, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (56, 21, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (58, 22, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (59, 22, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (60, 22, '_menu_item_object_id', '16') ; 
INSERT INTO `wp_postmeta` VALUES (61, 22, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (62, 22, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (63, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (64, 22, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (65, 22, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (70, 24, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (72, 24, '_edit_lock', '1442008197:1') ; 
INSERT INTO `wp_postmeta` VALUES (73, 26, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (75, 26, '_edit_lock', '1441939513:1') ; 
INSERT INTO `wp_postmeta` VALUES (76, 28, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (78, 28, '_edit_lock', '1441939506:1') ; 
INSERT INTO `wp_postmeta` VALUES (79, 30, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (81, 30, '_edit_lock', '1441939500:1') ; 
INSERT INTO `wp_postmeta` VALUES (82, 32, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (84, 32, '_edit_lock', '1441939494:1') ; 
INSERT INTO `wp_postmeta` VALUES (85, 34, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (87, 34, '_edit_lock', '1441939487:1') ; 
INSERT INTO `wp_postmeta` VALUES (88, 36, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (90, 36, '_edit_lock', '1441939480:1') ; 
INSERT INTO `wp_postmeta` VALUES (91, 38, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (93, 38, '_edit_lock', '1441939475:1') ; 
INSERT INTO `wp_postmeta` VALUES (94, 40, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (96, 40, '_edit_lock', '1441939470:1') ; 
INSERT INTO `wp_postmeta` VALUES (97, 42, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (99, 42, '_edit_lock', '1441939463:1') ; 
INSERT INTO `wp_postmeta` VALUES (100, 44, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (102, 44, '_edit_lock', '1441939457:1') ; 
INSERT INTO `wp_postmeta` VALUES (103, 46, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (105, 46, '_edit_lock', '1441939449:1') ; 
INSERT INTO `wp_postmeta` VALUES (106, 49, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (108, 49, 'position', 'normal') ; 
INSERT INTO `wp_postmeta` VALUES (109, 49, 'layout', 'no_box') ; 
INSERT INTO `wp_postmeta` VALUES (110, 49, 'hide_on_screen', '') ; 
INSERT INTO `wp_postmeta` VALUES (111, 49, '_edit_lock', '1391149229:1') ; 
INSERT INTO `wp_postmeta` VALUES (112, 50, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (114, 50, 'position', 'normal') ; 
INSERT INTO `wp_postmeta` VALUES (115, 50, 'layout', 'no_box') ; 
INSERT INTO `wp_postmeta` VALUES (116, 50, 'hide_on_screen', '') ; 
INSERT INTO `wp_postmeta` VALUES (117, 50, '_edit_lock', '1391149030:1') ; 
INSERT INTO `wp_postmeta` VALUES (118, 51, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (120, 51, 'position', 'normal') ; 
INSERT INTO `wp_postmeta` VALUES (121, 51, 'layout', 'no_box') ; 
INSERT INTO `wp_postmeta` VALUES (122, 51, 'hide_on_screen', '') ; 
INSERT INTO `wp_postmeta` VALUES (123, 51, '_edit_lock', '1391149310:1') ; 
INSERT INTO `wp_postmeta` VALUES (124, 51, 'field_52d9034a109e5', 'a:14:{s:3:"key";s:19:"field_52d9034a109e5";s:5:"label";s:17:"Site Verification";s:4:"name";s:24:"google_site_verification";s:4:"type";s:4:"text";s:12:"instructions";s:67:"Add instructions here that better describes what this field offers.";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (125, 51, 'field_52d90387109e6', 'a:14:{s:3:"key";s:19:"field_52d90387109e6";s:5:"label";s:9:"Analytics";s:4:"name";s:16:"google_analytics";s:4:"type";s:4:"text";s:12:"instructions";s:67:"Add instructions here that better describes what this field offers.";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:12:"UA-XXXXXX-XX";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}') ; 
INSERT INTO `wp_postmeta` VALUES (129, 50, 'field_52d9041a331f8', 'a:14:{s:3:"key";s:19:"field_52d9041a331f8";s:5:"label";s:7:"Twitter";s:4:"name";s:14:"social_twitter";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}') ; 
INSERT INTO `wp_postmeta` VALUES (130, 50, 'field_52d9042c331f9', 'a:14:{s:3:"key";s:19:"field_52d9042c331f9";s:5:"label";s:8:"Facebook";s:4:"name";s:15:"social_facebook";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}') ; 
INSERT INTO `wp_postmeta` VALUES (131, 50, 'field_52d9044e331fa', 'a:14:{s:3:"key";s:19:"field_52d9044e331fa";s:5:"label";s:8:"LinkedIn";s:4:"name";s:15:"social_linkedin";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}') ; 
INSERT INTO `wp_postmeta` VALUES (132, 50, 'field_52d90475331fc', 'a:14:{s:3:"key";s:19:"field_52d90475331fc";s:5:"label";s:11:"Google Plus";s:4:"name";s:18:"social_google_plus";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}') ; 
INSERT INTO `wp_postmeta` VALUES (134, 50, 'field_52d904bb7e666', 'a:9:{s:3:"key";s:19:"field_52d904bb7e666";s:5:"label";s:12:"Instructions";s:4:"name";s:0:"";s:4:"type";s:7:"message";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:7:"message";s:67:"Add instructions here that better describes what this field offers.";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (135, 50, 'rule', 'a:5:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:24:"acf-options-social-media";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (136, 49, 'field_52eb3ffd2a2f5', 'a:14:{s:3:"key";s:19:"field_52eb3ffd2a2f5";s:5:"label";s:6:"Street";s:4:"name";s:14:"contact_street";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (137, 49, 'field_52eb40202a2f6', 'a:14:{s:3:"key";s:19:"field_52eb40202a2f6";s:5:"label";s:4:"City";s:4:"name";s:12:"contact_city";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}') ; 
INSERT INTO `wp_postmeta` VALUES (138, 49, 'field_52eb402a2a2f7', 'a:12:{s:3:"key";s:19:"field_52eb402a2a2f7";s:5:"label";s:5:"State";s:4:"name";s:13:"contact_state";s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:7:"choices";a:51:{s:7:"Alabama";s:7:"Alabama";s:6:"Alaska";s:6:"Alaska";s:7:"Arizona";s:7:"Arizona";s:8:"Arkansas";s:8:"Arkansas";s:10:"California";s:10:"California";s:8:"Colorado";s:8:"Colorado";s:11:"Connecticut";s:11:"Connecticut";s:8:"Delaware";s:8:"Delaware";s:20:"District Of Columbia";s:20:"District Of Columbia";s:7:"Florida";s:7:"Florida";s:7:"Georgia";s:7:"Georgia";s:6:"Hawaii";s:6:"Hawaii";s:5:"Idaho";s:5:"Idaho";s:8:"Illinois";s:8:"Illinois";s:7:"Indiana";s:7:"Indiana";s:4:"Iowa";s:4:"Iowa";s:6:"Kansas";s:6:"Kansas";s:8:"Kentucky";s:8:"Kentucky";s:9:"Louisiana";s:9:"Louisiana";s:5:"Maine";s:5:"Maine";s:8:"Maryland";s:8:"Maryland";s:13:"Massachusetts";s:13:"Massachusetts";s:8:"Michigan";s:8:"Michigan";s:9:"Minnesota";s:9:"Minnesota";s:11:"Mississippi";s:11:"Mississippi";s:8:"Missouri";s:8:"Missouri";s:7:"Montana";s:7:"Montana";s:8:"Nebraska";s:8:"Nebraska";s:6:"Nevada";s:6:"Nevada";s:13:"New Hampshire";s:13:"New Hampshire";s:10:"New Jersey";s:10:"New Jersey";s:10:"New Mexico";s:10:"New Mexico";s:8:"New York";s:8:"New York";s:14:"North Carolina";s:14:"North Carolina";s:12:"North Dakota";s:12:"North Dakota";s:4:"Ohio";s:4:"Ohio";s:8:"Oklahoma";s:8:"Oklahoma";s:6:"Oregon";s:6:"Oregon";s:12:"Pennsylvania";s:12:"Pennsylvania";s:12:"Rhode Island";s:12:"Rhode Island";s:14:"South Carolina";s:14:"South Carolina";s:12:"South Dakota";s:12:"South Dakota";s:9:"Tennessee";s:9:"Tennessee";s:5:"Texas";s:5:"Texas";s:4:"Utah";s:4:"Utah";s:7:"Vermont";s:7:"Vermont";s:8:"Virginia";s:8:"Virginia";s:10:"Washington";s:10:"Washington";s:13:"West Virginia";s:13:"West Virginia";s:9:"Wisconsin";s:9:"Wisconsin";s:7:"Wyoming";s:7:"Wyoming";}s:13:"default_value";s:0:"";s:10:"allow_null";s:1:"0";s:8:"multiple";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}') ; 
INSERT INTO `wp_postmeta` VALUES (139, 49, 'field_52eb406f2a2f8', 'a:14:{s:3:"key";s:19:"field_52eb406f2a2f8";s:5:"label";s:7:"Zipcode";s:4:"name";s:15:"contact_zipcode";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_52eb402a2a2f7";s:8:"operator";s:2:"==";s:5:"value";s:7:"Alabama";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}') ; 
INSERT INTO `wp_postmeta` VALUES (140, 49, 'field_52eb40812a2f9', 'a:14:{s:3:"key";s:19:"field_52eb40812a2f9";s:5:"label";s:5:"Phone";s:4:"name";s:13:"contact_phone";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_52eb402a2a2f7";s:8:"operator";s:2:"==";s:5:"value";s:7:"Alabama";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}') ; 
INSERT INTO `wp_postmeta` VALUES (141, 49, 'field_52eb40902a2fa', 'a:14:{s:3:"key";s:19:"field_52eb40902a2fa";s:5:"label";s:5:"Email";s:4:"name";s:13:"contact_email";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_52eb402a2a2f7";s:8:"operator";s:2:"==";s:5:"value";s:7:"Alabama";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:5;}') ; 
INSERT INTO `wp_postmeta` VALUES (142, 49, 'rule', 'a:5:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:24:"acf-options-contact-info";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (143, 51, 'rule', 'a:5:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:24:"acf-options-google-tools";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (144, 56, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (145, 56, 'field_52eb41a4a47b8', 'a:11:{s:3:"key";s:19:"field_52eb41a4a47b8";s:5:"label";s:7:"Excerpt";s:4:"name";s:15:"article_excerpt";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:5:"basic";s:12:"media_upload";s:2:"no";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (146, 56, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (147, 56, 'position', 'acf_after_title') ; 
INSERT INTO `wp_postmeta` VALUES (148, 56, 'layout', 'no_box') ; 
INSERT INTO `wp_postmeta` VALUES (149, 56, 'hide_on_screen', '') ; 
INSERT INTO `wp_postmeta` VALUES (150, 56, '_edit_lock', '1404257412:1') ; 
INSERT INTO `wp_postmeta` VALUES (153, 62, '_edit_lock', '1442000773:1') ; 
INSERT INTO `wp_postmeta` VALUES (154, 62, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (155, 69, '_edit_lock', '1404837315:1') ; 
INSERT INTO `wp_postmeta` VALUES (156, 69, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (157, 79, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (158, 79, '_edit_lock', '1441592981:1') ; 
INSERT INTO `wp_postmeta` VALUES (159, 81, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (160, 81, '_edit_lock', '1442005471:1') ; 
INSERT INTO `wp_postmeta` VALUES (161, 83, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (162, 83, '_edit_lock', '1442003956:1') ; 
INSERT INTO `wp_postmeta` VALUES (163, 85, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (164, 85, '_edit_lock', '1441592950:1') ; 
INSERT INTO `wp_postmeta` VALUES (165, 87, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (166, 87, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (167, 87, '_menu_item_object_id', '85') ; 
INSERT INTO `wp_postmeta` VALUES (168, 87, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (169, 87, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (170, 87, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (171, 87, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (172, 87, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (174, 88, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (175, 88, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (176, 88, '_menu_item_object_id', '79') ; 
INSERT INTO `wp_postmeta` VALUES (177, 88, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (178, 88, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (179, 88, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (180, 88, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (181, 88, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (184, 90, 'article_excerpt', '') ; 
INSERT INTO `wp_postmeta` VALUES (185, 90, '_article_excerpt', 'field_52eb41a4a47b8') ; 
INSERT INTO `wp_postmeta` VALUES (186, 24, 'article_excerpt', '') ; 
INSERT INTO `wp_postmeta` VALUES (187, 24, '_article_excerpt', 'field_52eb41a4a47b8') ; 
INSERT INTO `wp_postmeta` VALUES (189, 91, 'article_excerpt', '') ; 
INSERT INTO `wp_postmeta` VALUES (190, 91, '_article_excerpt', 'field_52eb41a4a47b8') ; 
INSERT INTO `wp_postmeta` VALUES (192, 92, 'article_excerpt', '') ; 
INSERT INTO `wp_postmeta` VALUES (193, 92, '_article_excerpt', 'field_52eb41a4a47b8') ; 
INSERT INTO `wp_postmeta` VALUES (195, 93, 'article_excerpt', '') ; 
INSERT INTO `wp_postmeta` VALUES (196, 93, '_article_excerpt', 'field_52eb41a4a47b8') ; 
INSERT INTO `wp_postmeta` VALUES (198, 94, 'article_excerpt', '') ; 
INSERT INTO `wp_postmeta` VALUES (199, 94, '_article_excerpt', 'field_52eb41a4a47b8') ; 
INSERT INTO `wp_postmeta` VALUES (200, 95, '_form', '<ol>

	<li><label for="name">Name</label>[text name id:name]</li>

	<li><label for="email-address">Email Address <span class="required">*</span></label>[email* email-address id:email-address]</li>

	<li><label for="subject">Subject</label>[select subject id:subject include_blank "Subject Item One" "Subject Item Two" "Subject Item Three"]</li>

	<li><label for="message">Message <span class="required">*</span></label>[textarea* message id:message]</li>

</ol>

<div class="submit">[submit "Send Message"]</div>') ; 
INSERT INTO `wp_postmeta` VALUES (201, 95, '_mail', 'a:8:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:39:"[your-name] <wordpress@9zero7films.dev>";s:4:"body";s:172:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on 9ZERO7 Films (http://9zero7films.dev)";s:9:"recipient";s:15:"jlcolema@me.com";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (202, 95, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:40:"9ZERO7 Films <wordpress@9zero7films.dev>";s:4:"body";s:114:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on 9ZERO7 Films (http://9zero7films.dev)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:25:"Reply-To: jlcolema@me.com";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (203, 95, '_messages', 'a:23:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:34:"Please fill in the required field.";s:16:"invalid_too_long";s:23:"This input is too long.";s:17:"invalid_too_short";s:24:"This input is too short.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";}') ; 
INSERT INTO `wp_postmeta` VALUES (204, 95, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (205, 95, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (206, 96, '_form', '<ol>

	<li><label for="name">Name <span class="required">*</span></label>[text* name id:name placeholder "Name"]</li>

	<li><label for="email-address">Email Address <span class="required">*</span></label>[email* email-address id:email-address placeholder "Email Address"]</li>

</ol>

<div class="submit">[submit "Sign Up"]</div>') ; 
INSERT INTO `wp_postmeta` VALUES (207, 96, '_mail', 'a:8:{s:7:"subject";s:17:"Newsletter Signup";s:6:"sender";s:34:"[name] <wordpress@9zero7films.dev>";s:4:"body";s:94:"From: [name] <[email-address]>


--

This e-mail was sent from a contact form on 9ZERO7 Films.";s:9:"recipient";s:15:"jlcolema@me.com";s:18:"additional_headers";s:16:"Reply-To: [name]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (208, 96, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:40:"9ZERO7 Films <wordpress@9zero7films.dev>";s:4:"body";s:114:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on 9ZERO7 Films (http://9zero7films.dev)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:25:"Reply-To: jlcolema@me.com";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (209, 96, '_messages', 'a:23:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:34:"Please fill in the required field.";s:16:"invalid_too_long";s:23:"This input is too long.";s:17:"invalid_too_short";s:24:"This input is too short.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";}') ; 
INSERT INTO `wp_postmeta` VALUES (210, 96, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (211, 96, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (212, 97, '_form', '<ol>

	<li><label for="name">Name</label>[text name id:name]</li>

	<li><label for="email-address">Email Address <span class="required">*</span></label>[email* email-address id:email-address]</li>

</ol>

<div class="submit">[submit "Send"]</div>') ; 
INSERT INTO `wp_postmeta` VALUES (213, 97, '_mail', 'a:8:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:39:"[your-name] <wordpress@9zero7films.dev>";s:4:"body";s:172:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on 9ZERO7 Films (http://9zero7films.dev)";s:9:"recipient";s:15:"jlcolema@me.com";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (214, 97, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:40:"9ZERO7 Films <wordpress@9zero7films.dev>";s:4:"body";s:114:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on 9ZERO7 Films (http://9zero7films.dev)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:25:"Reply-To: jlcolema@me.com";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (215, 97, '_messages', 'a:23:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:34:"Please fill in the required field.";s:16:"invalid_too_long";s:23:"This input is too long.";s:17:"invalid_too_short";s:24:"This input is too short.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";}') ; 
INSERT INTO `wp_postmeta` VALUES (216, 97, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (217, 97, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (218, 98, '_form', '<ol>

	<li><label for="company-name">Company Name</label>[text name id:company-name]</li>

	<li><label for="primary-contact">Primary Contact</label>[text name id:primary-contact]</li>

	<li><label for="phone-number">Phone Number <span class="required">*</span></label>[tel* phone-number id:phone-number]</li>

	<li><label for="email-address">Email Address <span class="required">*</span></label>[email* email-address id:email-address]</li>

</ol>

<div class="submit">[submit "Send"]</div>') ; 
INSERT INTO `wp_postmeta` VALUES (219, 98, '_mail', 'a:8:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:39:"[your-name] <wordpress@9zero7films.dev>";s:4:"body";s:172:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on 9ZERO7 Films (http://9zero7films.dev)";s:9:"recipient";s:15:"jlcolema@me.com";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (220, 98, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:40:"9ZERO7 Films <wordpress@9zero7films.dev>";s:4:"body";s:114:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on 9ZERO7 Films (http://9zero7films.dev)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:25:"Reply-To: jlcolema@me.com";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (221, 98, '_messages', 'a:23:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:34:"Please fill in the required field.";s:16:"invalid_too_long";s:23:"This input is too long.";s:17:"invalid_too_short";s:24:"This input is too short.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";}') ; 
INSERT INTO `wp_postmeta` VALUES (222, 98, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (223, 98, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (224, 99, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (225, 99, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (226, 99, '_menu_item_object_id', '10') ; 
INSERT INTO `wp_postmeta` VALUES (227, 99, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (228, 99, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (229, 99, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (230, 99, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (231, 99, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (232, 99, '_menu_item_orphaned', '1441610253') ; 
INSERT INTO `wp_postmeta` VALUES (233, 100, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (234, 100, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (235, 100, '_menu_item_object_id', '12') ; 
INSERT INTO `wp_postmeta` VALUES (236, 100, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (237, 100, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (238, 100, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (239, 100, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (240, 100, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (242, 101, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (243, 101, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (244, 101, '_menu_item_object_id', '85') ; 
INSERT INTO `wp_postmeta` VALUES (245, 101, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (246, 101, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (247, 101, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (248, 101, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (249, 101, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (251, 102, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (252, 102, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (253, 102, '_menu_item_object_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (254, 102, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (255, 102, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (256, 102, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (257, 102, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (258, 102, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (260, 103, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (261, 103, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (262, 103, '_menu_item_object_id', '79') ; 
INSERT INTO `wp_postmeta` VALUES (263, 103, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (264, 103, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (265, 103, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (266, 103, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (267, 103, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (269, 104, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (270, 104, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (271, 104, '_menu_item_object_id', '81') ; 
INSERT INTO `wp_postmeta` VALUES (272, 104, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (273, 104, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (274, 104, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (275, 104, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (276, 104, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (278, 105, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (279, 105, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (280, 105, '_menu_item_object_id', '83') ; 
INSERT INTO `wp_postmeta` VALUES (281, 105, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (282, 105, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (283, 105, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (284, 105, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (285, 105, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (287, 106, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (288, 106, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (289, 106, '_menu_item_object_id', '16') ; 
INSERT INTO `wp_postmeta` VALUES (290, 106, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (291, 106, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (292, 106, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (293, 106, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (294, 106, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (296, 72, '_edit_lock', '1442001408:1') ; 
INSERT INTO `wp_postmeta` VALUES (297, 72, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (298, 113, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (299, 113, '_edit_lock', '1441937447:1') ; 
INSERT INTO `wp_postmeta` VALUES (300, 114, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (301, 114, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (302, 114, '_menu_item_object_id', '81') ; 
INSERT INTO `wp_postmeta` VALUES (303, 114, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (304, 114, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (305, 114, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (306, 114, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (307, 114, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (309, 60, '_edit_lock', '1442026807:1') ; 
INSERT INTO `wp_postmeta` VALUES (310, 60, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (311, 136, '_wp_attached_file', 'article-image-float-left.png') ; 
INSERT INTO `wp_postmeta` VALUES (312, 136, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:240;s:6:"height";i:210;s:4:"file";s:28:"article-image-float-left.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:36:"article-image-float-left-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (313, 137, '_wp_attached_file', 'article-image-float-right.png') ; 
INSERT INTO `wp_postmeta` VALUES (314, 137, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:240;s:6:"height";i:210;s:4:"file";s:29:"article-image-float-right.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:37:"article-image-float-right-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (315, 138, '_wp_attached_file', 'article-thumbnail.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (316, 138, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:520;s:6:"height";i:360;s:4:"file";s:21:"article-thumbnail.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"article-thumbnail-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"article-thumbnail-300x208.jpg";s:5:"width";i:300;s:6:"height";i:208;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (317, 135, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (319, 139, 'article_thumbnail', '138') ; 
INSERT INTO `wp_postmeta` VALUES (320, 139, '_article_thumbnail', 'field_55f1eca1428f9') ; 
INSERT INTO `wp_postmeta` VALUES (321, 139, 'article_excerpt', 'Mauris non tempor quam, et lacinia sapien. Mauris accumsan eros eget li.') ; 
INSERT INTO `wp_postmeta` VALUES (322, 139, '_article_excerpt', 'field_55f1e92e49b8f') ; 
INSERT INTO `wp_postmeta` VALUES (323, 139, 'article_categories', 'a:4:{i:0;s:2:"10";i:1;s:1:"9";i:2;s:1:"5";i:3;s:1:"6";}') ; 
INSERT INTO `wp_postmeta` VALUES (324, 139, '_article_categories', 'field_55f1ece32ad0d') ; 
INSERT INTO `wp_postmeta` VALUES (325, 139, 'content_0_article_text', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam feugiat lorem at justo pellentesque, ac molestie nisi scelerisque. <a href="http://9zero7films.dev/">Malesuada eu sapien</a>. Maecenas id pulvinar sapien, sit amet porttitor enim. Pellentesque augue ligula, dapibus id interdum at, tempor ut diam. Aenean elit sapien, vestibulum egestas lorem vitae, ultricies finibus neque.
<ol>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ol>
Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam aliquet, dui vitae eleifend commodo, odio lectus euismod purus, at suscipit urna dui vel urna.
<h2>Sed eget sagittis ex, quis fermentum nibh pellentesque eleifend lectus id lacinia venenatis.</h2>
Suspendisse egestas nisi et fermentum luctus. Mauris sit amet nunc at sem auctor aliquam at a orci. Etiam vel nisi ultricies urna placerat faucibus at vitae diam. Duis sed cursus diam. Maecenas non tempus erat. Sed ut semper ante. Proin dignissim, est vitae ullamcorper blandit, erat nulla laoreet erat, quis euismod nulla augue vel velit.

Sed rutrum nibh ut viverra semper. Quisque lobortis ultricies facilisis. Nulla mauris neque, luctus sed sapien vitae, imperdiet laoreet lacus. Vivamus ex lectus, porta a velit a, ullamcorper auctor massa. Aenean vulputate erat at congue efficitur. Nullam varius egestas ex. <em>Fusce imperdiet tellus et luctus suscipit</em>. Nulla ut dui a massa mollis tincidunt. Pellentesque eu sem eu purus pellentesque feugiat non quis est. Nulla pretium, eros et faucibus molestie, nisi justo faucibus lacus, et venenatis ex augue nec nunc. Nunc id nunc massa.
<ul>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ul>
Nulla venenatis condimentum est, sed efficitur purus congue id. Vivamus a malesuada augue. Donec consequat interdum nisi nec laoreet. Morbi ultrices varius dui, vitae pulvinar nibh ornare sed. Donec semper gravida neque scelerisque bibendum. In eu rutrum mi. Quisque luctus tellus ut sem maximus vehicula. Nunc vel varius nisi, vitae venenatis erat. Cras mollis interdum enim, ac pretium ligula feugiat eu. In sed lectus ut ipsum euismod sodales eget sed augue.
<h3>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (326, 139, '_content_0_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (327, 139, 'content_1_article_image', '136') ; 
INSERT INTO `wp_postmeta` VALUES (328, 139, '_content_1_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (329, 139, 'content_1_article_image_alignment', 'Float Left') ; 
INSERT INTO `wp_postmeta` VALUES (330, 139, '_content_1_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (331, 139, 'content_2_article_text', 'Ut mattis non enim quis pretium. Suspendisse blandit mollis libero sit amet commodo. Quisque sagittis iaculis risus congue rhoncus. Mauris fermentum elit sit amet nunc ullamcorper, non iaculis eros suscipit. Ut facilisis accumsan nunc. Vivamus finibus ut erat ut mollis. Quisque sed lacus enim. Nulla facilisi. Suspendisse non faucibus neque. Quisque lacus elit, sodales a laoreet sollicitudin, elementum sit amet tellus. Quisque metus lorem, ornare non aliquam sit amet, gravida et est. Maecenas quis malesuada ante. Mauris ac neque sit amet justo varius pulvinar quis et enim. Proin aliquet eget enim non ornare. Suspendisse cursus risus nec enim suscipit commodo ac a ligula.

Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean congue erat in mauris viverra eleifend in eget nunc. Aliquam orci erat, blandit quis lorem quis, pellentesque placerat justo. Sed arcu nunc, lacinia quis magna vel, tempor tempus urna. In sit amet mi dapibus, consectetur lorem ac, aliquet metus. Morbi faucibus vitae purus sit amet varius.

Etiam ut tincidunt sapien, eu gravida enim vivamus congue leo tellus, id pellentesque justo finibus at. Maecenas rhoncus magna eget quam bibendum, ut iaculis massa facilisis. Sed sed condimentum tortor, eget tristique mauris. Morbi eu imperdiet nunc. In interdum non ipsum sit amet molestie. Aenean vel eros ornare, ornare elit et, tincidunt quam. Sed ac erat et nulla aliquam euismod eget eget quam. Quisque eget quam ligula. Suspendisse euismod dui vitae euismod tincidunt. Morbi accumsan purus sit amet mattis laoreet.

Suspendisse vitae nibh elementum sapien cursus hendrerit. Mauris varius tortor maximus, gravida lorem nec, commodo massa. Pellentesque malesuada erat quis lacus aliquet lacinia. Quisque vel est a augue porta scelerisque vitae vel risus. Pellentesque nec nisl luctus, dapibus orci a, ornare est.') ; 
INSERT INTO `wp_postmeta` VALUES (332, 139, '_content_2_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (333, 139, 'content_3_article_video', 'https://www.youtube.com/watch?v=6FN1Y-Mbsr4') ; 
INSERT INTO `wp_postmeta` VALUES (334, 139, '_content_3_article_video', 'field_55f1eb8549b96') ; 
INSERT INTO `wp_postmeta` VALUES (335, 139, 'content_3_article_video_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (336, 139, '_content_3_article_video_alignment', 'field_55f1eba549b97') ; 
INSERT INTO `wp_postmeta` VALUES (337, 139, 'content_4_article_text', 'Duis eu pellentesque neque, non ullamcorper lectus. Etiam ut tellus congue turpis bibendum accumsan. Etiam non condimentum neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean tempus ipsum purus, vel consequat sapien feugiat ac. Maecenas vestibulum est vel arcu vestibulum, a tempor nulla maximus. Vivamus hendrerit dolor consequat dignissim dignissim.

Maecenas eu fringilla nisl, nec hendrerit est. Maecenas quis nibh eget ipsum bibendum facilisis. Proin dapibus diam eget rhoncus efficitur. Duis mollis ante at bibendum pharetra. Praesent ultricies mollis accumsan. Nunc feugiat quis velit eget commodo. Praesent ultricies iaculis erat, nec fermentum est pharetra non. Nulla facilisi. Sed sollicitudin mauris ac magna scelerisque vulputate. Etiam sit amet nisi vel eros finibus sodales. Nullam egestas fringilla eros a aliquet. Mauris et mollis erat, in eleifend turpis.') ; 
INSERT INTO `wp_postmeta` VALUES (338, 139, '_content_4_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (339, 139, 'content_5_article_image', '137') ; 
INSERT INTO `wp_postmeta` VALUES (340, 139, '_content_5_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (341, 139, 'content_5_article_image_alignment', 'Float Right') ; 
INSERT INTO `wp_postmeta` VALUES (342, 139, '_content_5_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (343, 139, 'content_6_article_text', 'Vivamus sit amet neque ut arcu maximus gravida. Mauris sodales quam vel finibus auctor. Vestibulum eget nulla turpis. Cras eros augue, semper nec malesuada vel, elementum sed sem. Aenean ac maximus ex, mattis dictum enim. Sed ultrices leo in tellus iaculis imperdiet. Morbi auctor arcu nec elit interdum dapibus. Integer sed leo odio. Aliquam nec ultricies risus, vel porta lectus. Sed accumsan placerat leo, at aliquam felis rhoncus aliquam. Curabitur in sodales massa. Aenean dui est, commodo ac venenatis et, aliquam eu neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse interdum enim quis volutpat sollicitudin. Morbi bibendum est non egestas rhoncus. Cras tempor sagittis nibh sit amet pharetra.

Quisque sagittis, libero in sagittis imperdiet, magna felis tincidunt erat, sit amet sagittis libero risus sed diam. Etiam vestibulum non purus in gravida. Nulla facilisi. Nunc lectus purus, gravida quis ligula vehicula, pulvinar venenatis nibh. Aenean hendrerit eleifend lacus, vel ultrices nisi ultricies eget. Mauris neque quam, laoreet varius maximus id, auctor sit amet ante. Maecenas sed felis sit amet risus varius rutrum nec eu enim. Ut commodo sollicitudin purus ut auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras volutpat tristique neque sit amet pulvinar. Cras sed sem ac dolor ornare sagittis. Morbi augue augue, gravida vitae mi sit amet, ornare tempor libero. Donec sagittis fermentum magna eget aliquam. Etiam fermentum mi a lacinia varius.

Morbi venenatis velit non interdum bibendum. Phasellus iaculis ornare elementum. Vivamus ac imperdiet ligula, eget ultrices diam. Vivamus sed tincidunt turpis. Integer eu auctor eros. Nullam finibus laoreet venenatis. Nunc ac sem cursus, faucibus sem a, aliquam turpis. Praesent bibendum magna vitae pulvinar fermentum. Mauris at sollicitudin orci, sed tempus leo. Fusce quis magna tristique, eleifend metus sed, sodales sapien. Suspendisse sit amet massa consequat nulla lacinia sagittis.') ; 
INSERT INTO `wp_postmeta` VALUES (344, 139, '_content_6_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (345, 139, 'content_7_article_video', 'https://www.youtube.com/watch?v=6FN1Y-Mbsr4') ; 
INSERT INTO `wp_postmeta` VALUES (346, 139, '_content_7_article_video', 'field_55f1eb8549b96') ; 
INSERT INTO `wp_postmeta` VALUES (347, 139, 'content_7_article_video_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (348, 139, '_content_7_article_video_alignment', 'field_55f1eba549b97') ; 
INSERT INTO `wp_postmeta` VALUES (349, 139, 'content_8_article_text', 'In ullamcorper ac eros eu efficitur. Donec a orci orci. Suspendisse egestas lacus in risus feugiat, eget maximus mauris condimentum. Duis ut ante et diam feugiat tincidunt. Morbi nec velit vitae sapien elementum sagittis. Fusce sed luctus massa, quis mollis dolor. Suspendisse facilisis orci et maximus feugiat. Sed quis congue erat. Cras porta efficitur magna, dictum sagittis urna laoreet semper. Etiam ac nunc orci.
<h4>VESTIBULUM ANTE IPSUM PRIMIS IN FAUCIBUS ORCI LUCTUS ET ULTRICES POSUERE CUBILIA CURAE.</h4>
Vestibulum eget pretium elit. Pellentesque nec tempor augue. In velit ipsum, porttitor et vulputate et, sollicitudin ac mi. Aliquam placerat non magna quis auctor. Sed sagittis nisi vitae lectus semper, id semper quam consequat. Nulla posuere, ex in iaculis ultricies, nulla libero sollicitudin dui, ut tristique orci leo ut tortor. Fusce laoreet tincidunt lacus id posuere. Donec et metus sit amet diam lobortis aliquet. Aenean eget vestibulum mauris. Sed id est lacus. Aenean sed congue diam. Nullam pretium dictum elit non tempus. Suspendisse potenti. Pellentesque mattis lorem vitae dolor porttitor, vitae condimentum magna vulputate. Pellentesque bibendum lorem ut lorem dictum, ut venenatis orci tempus.

Aliquam id augue lobortis, pellentesque leo sit amet, bibendum est. Morbi quis ex nec eros efficitur imperdiet vitae id dolor. Pellentesque et lectus vitae augue pretium lobortis. Fusce ante orci, rutrum non ultrices sit amet, pellentesque vitae lacus. Proin at mattis risus. Suspendisse sem magna, ultrices at lectus at, laoreet lobortis tortor. Fusce viverra vestibulum dui id ultrices. Suspendisse eu rhoncus massa, eget sodales elit. Proin gravida dolor at sapien congue, sed vehicula nisi rutrum.') ; 
INSERT INTO `wp_postmeta` VALUES (350, 139, '_content_8_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (351, 139, 'content', 'a:9:{i:0;s:18:"article_text_block";i:1;s:19:"article_image_block";i:2;s:18:"article_text_block";i:3;s:19:"article_video_block";i:4;s:18:"article_text_block";i:5;s:19:"article_image_block";i:6;s:18:"article_text_block";i:7;s:19:"article_video_block";i:8;s:18:"article_text_block";}') ; 
INSERT INTO `wp_postmeta` VALUES (352, 139, '_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (353, 135, 'article_thumbnail', '138') ; 
INSERT INTO `wp_postmeta` VALUES (354, 135, '_article_thumbnail', 'field_55f1eca1428f9') ; 
INSERT INTO `wp_postmeta` VALUES (355, 135, 'article_excerpt', 'Mauris non tempor quam, et lacinia sapien. Mauris accumsan eros eget li.') ; 
INSERT INTO `wp_postmeta` VALUES (356, 135, '_article_excerpt', 'field_55f1e92e49b8f') ; 
INSERT INTO `wp_postmeta` VALUES (357, 135, 'article_categories', 'a:4:{i:0;s:2:"10";i:1;s:1:"9";i:2;s:1:"5";i:3;s:1:"6";}') ; 
INSERT INTO `wp_postmeta` VALUES (358, 135, '_article_categories', 'field_55f1ece32ad0d') ; 
INSERT INTO `wp_postmeta` VALUES (359, 135, 'content_0_article_text', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam feugiat lorem at justo pellentesque, ac molestie nisi scelerisque. <a href="http://9zero7films.dev/">Malesuada eu sapien</a>. Maecenas id pulvinar sapien, sit amet porttitor enim. Pellentesque augue ligula, dapibus id interdum at, tempor ut diam. Aenean elit sapien, vestibulum egestas lorem vitae, ultricies finibus neque.
<ol>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ol>
Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam aliquet, dui vitae eleifend commodo, odio lectus euismod purus, at suscipit urna dui vel urna.
<h2>Sed eget sagittis ex, quis fermentum nibh pellentesque eleifend lectus id lacinia venenatis.</h2>
Suspendisse egestas nisi et fermentum luctus. Mauris sit amet nunc at sem auctor aliquam at a orci. Etiam vel nisi ultricies urna placerat faucibus at vitae diam. Duis sed cursus diam. Maecenas non tempus erat. Sed ut semper ante. Proin dignissim, est vitae ullamcorper blandit, erat nulla laoreet erat, quis euismod nulla augue vel velit.

Sed rutrum nibh ut viverra semper. Quisque lobortis ultricies facilisis. Nulla mauris neque, luctus sed sapien vitae, imperdiet laoreet lacus. Vivamus ex lectus, porta a velit a, ullamcorper auctor massa. Aenean vulputate erat at congue efficitur. Nullam varius egestas ex. <em>Fusce imperdiet tellus et luctus suscipit</em>. Nulla ut dui a massa mollis tincidunt. Pellentesque eu sem eu purus pellentesque feugiat non quis est. Nulla pretium, eros et faucibus molestie, nisi justo faucibus lacus, et venenatis ex augue nec nunc. Nunc id nunc massa.
<ul>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ul>
Nulla venenatis condimentum est, sed efficitur purus congue id. Vivamus a malesuada augue. Donec consequat interdum nisi nec laoreet. Morbi ultrices varius dui, vitae pulvinar nibh ornare sed. Donec semper gravida neque scelerisque bibendum. In eu rutrum mi. Quisque luctus tellus ut sem maximus vehicula. Nunc vel varius nisi, vitae venenatis erat. Cras mollis interdum enim, ac pretium ligula feugiat eu. In sed lectus ut ipsum euismod sodales eget sed augue.
<h3>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (360, 135, '_content_0_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (361, 135, 'content_1_article_image', '136') ; 
INSERT INTO `wp_postmeta` VALUES (362, 135, '_content_1_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (363, 135, 'content_1_article_image_alignment', 'Float Left') ; 
INSERT INTO `wp_postmeta` VALUES (364, 135, '_content_1_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (365, 135, 'content_2_article_text', 'Ut mattis non enim quis pretium. Suspendisse blandit mollis libero sit amet commodo. Quisque sagittis iaculis risus congue rhoncus. Mauris fermentum elit sit amet nunc ullamcorper, non iaculis eros suscipit. Ut facilisis accumsan nunc. Vivamus finibus ut erat ut mollis. Quisque sed lacus enim. Nulla facilisi. Suspendisse non faucibus neque. Quisque lacus elit, sodales a laoreet sollicitudin, elementum sit amet tellus. Quisque metus lorem, ornare non aliquam sit amet, gravida et est. Maecenas quis malesuada ante. Mauris ac neque sit amet justo varius pulvinar quis et enim. Proin aliquet eget enim non ornare. Suspendisse cursus risus nec enim suscipit commodo ac a ligula.

Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean congue erat in mauris viverra eleifend in eget nunc. Aliquam orci erat, blandit quis lorem quis, pellentesque placerat justo. Sed arcu nunc, lacinia quis magna vel, tempor tempus urna. In sit amet mi dapibus, consectetur lorem ac, aliquet metus. Morbi faucibus vitae purus sit amet varius.

Etiam ut tincidunt sapien, eu gravida enim vivamus congue leo tellus, id pellentesque justo finibus at. Maecenas rhoncus magna eget quam bibendum, ut iaculis massa facilisis. Sed sed condimentum tortor, eget tristique mauris. Morbi eu imperdiet nunc. In interdum non ipsum sit amet molestie. Aenean vel eros ornare, ornare elit et, tincidunt quam. Sed ac erat et nulla aliquam euismod eget eget quam. Quisque eget quam ligula. Suspendisse euismod dui vitae euismod tincidunt. Morbi accumsan purus sit amet mattis laoreet.

Suspendisse vitae nibh elementum sapien cursus hendrerit. Mauris varius tortor maximus, gravida lorem nec, commodo massa. Pellentesque malesuada erat quis lacus aliquet lacinia. Quisque vel est a augue porta scelerisque vitae vel risus. Pellentesque nec nisl luctus, dapibus orci a, ornare est.') ; 
INSERT INTO `wp_postmeta` VALUES (366, 135, '_content_2_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (367, 135, 'content_3_article_video', 'https://www.youtube.com/watch?v=6FN1Y-Mbsr4') ; 
INSERT INTO `wp_postmeta` VALUES (368, 135, '_content_3_article_video', 'field_55f1eb8549b96') ; 
INSERT INTO `wp_postmeta` VALUES (369, 135, 'content_3_article_video_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (370, 135, '_content_3_article_video_alignment', 'field_55f1eba549b97') ; 
INSERT INTO `wp_postmeta` VALUES (371, 135, 'content_4_article_text', 'Duis eu pellentesque neque, non ullamcorper lectus. Etiam ut tellus congue turpis bibendum accumsan. Etiam non condimentum neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean tempus ipsum purus, vel consequat sapien feugiat ac. Maecenas vestibulum est vel arcu vestibulum, a tempor nulla maximus. Vivamus hendrerit dolor consequat dignissim dignissim.

Maecenas eu fringilla nisl, nec hendrerit est. Maecenas quis nibh eget ipsum bibendum facilisis. Proin dapibus diam eget rhoncus efficitur. Duis mollis ante at bibendum pharetra. Praesent ultricies mollis accumsan. Nunc feugiat quis velit eget commodo. Praesent ultricies iaculis erat, nec fermentum est pharetra non. Nulla facilisi. Sed sollicitudin mauris ac magna scelerisque vulputate. Etiam sit amet nisi vel eros finibus sodales. Nullam egestas fringilla eros a aliquet. Mauris et mollis erat, in eleifend turpis.') ; 
INSERT INTO `wp_postmeta` VALUES (372, 135, '_content_4_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (373, 135, 'content_5_article_image', '137') ; 
INSERT INTO `wp_postmeta` VALUES (374, 135, '_content_5_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (375, 135, 'content_5_article_image_alignment', 'Float Right') ; 
INSERT INTO `wp_postmeta` VALUES (376, 135, '_content_5_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (377, 135, 'content_6_article_text', 'Vivamus sit amet neque ut arcu maximus gravida. Mauris sodales quam vel finibus auctor. Vestibulum eget nulla turpis. Cras eros augue, semper nec malesuada vel, elementum sed sem. Aenean ac maximus ex, mattis dictum enim. Sed ultrices leo in tellus iaculis imperdiet. Morbi auctor arcu nec elit interdum dapibus. Integer sed leo odio. Aliquam nec ultricies risus, vel porta lectus. Sed accumsan placerat leo, at aliquam felis rhoncus aliquam. Curabitur in sodales massa. Aenean dui est, commodo ac venenatis et, aliquam eu neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse interdum enim quis volutpat sollicitudin. Morbi bibendum est non egestas rhoncus. Cras tempor sagittis nibh sit amet pharetra.

Quisque sagittis, libero in sagittis imperdiet, magna felis tincidunt erat, sit amet sagittis libero risus sed diam. Etiam vestibulum non purus in gravida. Nulla facilisi. Nunc lectus purus, gravida quis ligula vehicula, pulvinar venenatis nibh. Aenean hendrerit eleifend lacus, vel ultrices nisi ultricies eget. Mauris neque quam, laoreet varius maximus id, auctor sit amet ante. Maecenas sed felis sit amet risus varius rutrum nec eu enim. Ut commodo sollicitudin purus ut auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras volutpat tristique neque sit amet pulvinar. Cras sed sem ac dolor ornare sagittis. Morbi augue augue, gravida vitae mi sit amet, ornare tempor libero. Donec sagittis fermentum magna eget aliquam. Etiam fermentum mi a lacinia varius.

Morbi venenatis velit non interdum bibendum. Phasellus iaculis ornare elementum. Vivamus ac imperdiet ligula, eget ultrices diam. Vivamus sed tincidunt turpis. Integer eu auctor eros. Nullam finibus laoreet venenatis. Nunc ac sem cursus, faucibus sem a, aliquam turpis. Praesent bibendum magna vitae pulvinar fermentum. Mauris at sollicitudin orci, sed tempus leo. Fusce quis magna tristique, eleifend metus sed, sodales sapien. Suspendisse sit amet massa consequat nulla lacinia sagittis.') ; 
INSERT INTO `wp_postmeta` VALUES (378, 135, '_content_6_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (379, 135, 'content_7_article_video', 'https://www.youtube.com/watch?v=6FN1Y-Mbsr4') ; 
INSERT INTO `wp_postmeta` VALUES (380, 135, '_content_7_article_video', 'field_55f1eb8549b96') ; 
INSERT INTO `wp_postmeta` VALUES (381, 135, 'content_7_article_video_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (382, 135, '_content_7_article_video_alignment', 'field_55f1eba549b97') ; 
INSERT INTO `wp_postmeta` VALUES (383, 135, 'content_8_article_text', 'In ullamcorper ac eros eu efficitur. Donec a orci orci. Suspendisse egestas lacus in risus feugiat, eget maximus mauris condimentum. Duis ut ante et diam feugiat tincidunt. Morbi nec velit vitae sapien elementum sagittis. Fusce sed luctus massa, quis mollis dolor. Suspendisse facilisis orci et maximus feugiat. Sed quis congue erat. Cras porta efficitur magna, dictum sagittis urna laoreet semper. Etiam ac nunc orci.
<h4>VESTIBULUM ANTE IPSUM PRIMIS IN FAUCIBUS ORCI LUCTUS ET ULTRICES POSUERE CUBILIA CURAE.</h4>
Vestibulum eget pretium elit. Pellentesque nec tempor augue. In velit ipsum, porttitor et vulputate et, sollicitudin ac mi. Aliquam placerat non magna quis auctor. Sed sagittis nisi vitae lectus semper, id semper quam consequat. Nulla posuere, ex in iaculis ultricies, nulla libero sollicitudin dui, ut tristique orci leo ut tortor. Fusce laoreet tincidunt lacus id posuere. Donec et metus sit amet diam lobortis aliquet. Aenean eget vestibulum mauris. Sed id est lacus. Aenean sed congue diam. Nullam pretium dictum elit non tempus. Suspendisse potenti. Pellentesque mattis lorem vitae dolor porttitor, vitae condimentum magna vulputate. Pellentesque bibendum lorem ut lorem dictum, ut venenatis orci tempus.

Aliquam id augue lobortis, pellentesque leo sit amet, bibendum est. Morbi quis ex nec eros efficitur imperdiet vitae id dolor. Pellentesque et lectus vitae augue pretium lobortis. Fusce ante orci, rutrum non ultrices sit amet, pellentesque vitae lacus. Proin at mattis risus. Suspendisse sem magna, ultrices at lectus at, laoreet lobortis tortor. Fusce viverra vestibulum dui id ultrices. Suspendisse eu rhoncus massa, eget sodales elit. Proin gravida dolor at sapien congue, sed vehicula nisi rutrum.') ; 
INSERT INTO `wp_postmeta` VALUES (384, 135, '_content_8_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (385, 135, 'content', 'a:10:{i:0;s:19:"article_image_block";i:1;s:18:"article_text_block";i:2;s:19:"article_image_block";i:3;s:18:"article_text_block";i:4;s:25:"article_testimonial_block";i:5;s:18:"article_text_block";i:6;s:19:"article_image_block";i:7;s:18:"article_text_block";i:8;s:19:"article_video_block";i:9;s:18:"article_text_block";}') ; 
INSERT INTO `wp_postmeta` VALUES (386, 135, '_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (387, 135, '_edit_lock', '1442008211:1') ; 
INSERT INTO `wp_postmeta` VALUES (389, 140, 'article_thumbnail', '138') ; 
INSERT INTO `wp_postmeta` VALUES (390, 140, '_article_thumbnail', 'field_55f1eca1428f9') ; 
INSERT INTO `wp_postmeta` VALUES (391, 140, 'article_excerpt', 'Mauris non tempor quam, et lacinia sapien. Mauris accumsan eros eget li.') ; 
INSERT INTO `wp_postmeta` VALUES (392, 140, '_article_excerpt', 'field_55f1e92e49b8f') ; 
INSERT INTO `wp_postmeta` VALUES (393, 140, 'article_categories', 'a:4:{i:0;s:2:"10";i:1;s:1:"9";i:2;s:1:"5";i:3;s:1:"6";}') ; 
INSERT INTO `wp_postmeta` VALUES (394, 140, '_article_categories', 'field_55f1ece32ad0d') ; 
INSERT INTO `wp_postmeta` VALUES (395, 140, 'content_0_article_text', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam feugiat lorem at justo pellentesque, ac molestie nisi scelerisque. <a href="http://9zero7films.dev/">Malesuada eu sapien</a>. Maecenas id pulvinar sapien, sit amet porttitor enim. Pellentesque augue ligula, dapibus id interdum at, tempor ut diam. Aenean elit sapien, vestibulum egestas lorem vitae, ultricies finibus neque.
<ol>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ol>
Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam aliquet, dui vitae eleifend commodo, odio lectus euismod purus, at suscipit urna dui vel urna.
<h2>Sed eget sagittis ex, quis fermentum nibh pellentesque eleifend lectus id lacinia venenatis.</h2>
Suspendisse egestas nisi et fermentum luctus. Mauris sit amet nunc at sem auctor aliquam at a orci. Etiam vel nisi ultricies urna placerat faucibus at vitae diam. Duis sed cursus diam. Maecenas non tempus erat. Sed ut semper ante. Proin dignissim, est vitae ullamcorper blandit, erat nulla laoreet erat, quis euismod nulla augue vel velit.

Sed rutrum nibh ut viverra semper. Quisque lobortis ultricies facilisis. Nulla mauris neque, luctus sed sapien vitae, imperdiet laoreet lacus. Vivamus ex lectus, porta a velit a, ullamcorper auctor massa. Aenean vulputate erat at congue efficitur. Nullam varius egestas ex. <em>Fusce imperdiet tellus et luctus suscipit</em>. Nulla ut dui a massa mollis tincidunt. Pellentesque eu sem eu purus pellentesque feugiat non quis est. Nulla pretium, eros et faucibus molestie, nisi justo faucibus lacus, et venenatis ex augue nec nunc. Nunc id nunc massa.
<ul>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ul>
Nulla venenatis condimentum est, sed efficitur purus congue id. Vivamus a malesuada augue. Donec consequat interdum nisi nec laoreet. Morbi ultrices varius dui, vitae pulvinar nibh ornare sed. Donec semper gravida neque scelerisque bibendum. In eu rutrum mi. Quisque luctus tellus ut sem maximus vehicula. Nunc vel varius nisi, vitae venenatis erat. Cras mollis interdum enim, ac pretium ligula feugiat eu. In sed lectus ut ipsum euismod sodales eget sed augue.
<h3>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (396, 140, '_content_0_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (397, 140, 'content_1_article_image', '136') ; 
INSERT INTO `wp_postmeta` VALUES (398, 140, '_content_1_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (399, 140, 'content_1_article_image_alignment', 'Float Left') ; 
INSERT INTO `wp_postmeta` VALUES (400, 140, '_content_1_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (401, 140, 'content_2_article_text', 'Ut mattis non enim quis pretium. Suspendisse blandit mollis libero sit amet commodo. Quisque sagittis iaculis risus congue rhoncus. Mauris fermentum elit sit amet nunc ullamcorper, non iaculis eros suscipit. Ut facilisis accumsan nunc. Vivamus finibus ut erat ut mollis. Quisque sed lacus enim. Nulla facilisi. Suspendisse non faucibus neque. Quisque lacus elit, sodales a laoreet sollicitudin, elementum sit amet tellus. Quisque metus lorem, ornare non aliquam sit amet, gravida et est. Maecenas quis malesuada ante. Mauris ac neque sit amet justo varius pulvinar quis et enim. Proin aliquet eget enim non ornare. Suspendisse cursus risus nec enim suscipit commodo ac a ligula.

Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean congue erat in mauris viverra eleifend in eget nunc. Aliquam orci erat, blandit quis lorem quis, pellentesque placerat justo. Sed arcu nunc, lacinia quis magna vel, tempor tempus urna. In sit amet mi dapibus, consectetur lorem ac, aliquet metus. Morbi faucibus vitae purus sit amet varius.

Etiam ut tincidunt sapien, eu gravida enim vivamus congue leo tellus, id pellentesque justo finibus at. Maecenas rhoncus magna eget quam bibendum, ut iaculis massa facilisis. Sed sed condimentum tortor, eget tristique mauris. Morbi eu imperdiet nunc. In interdum non ipsum sit amet molestie. Aenean vel eros ornare, ornare elit et, tincidunt quam. Sed ac erat et nulla aliquam euismod eget eget quam. Quisque eget quam ligula. Suspendisse euismod dui vitae euismod tincidunt. Morbi accumsan purus sit amet mattis laoreet.

Suspendisse vitae nibh elementum sapien cursus hendrerit. Mauris varius tortor maximus, gravida lorem nec, commodo massa. Pellentesque malesuada erat quis lacus aliquet lacinia. Quisque vel est a augue porta scelerisque vitae vel risus. Pellentesque nec nisl luctus, dapibus orci a, ornare est.') ; 
INSERT INTO `wp_postmeta` VALUES (402, 140, '_content_2_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (403, 140, 'content_3_article_video', 'https://www.youtube.com/watch?v=6FN1Y-Mbsr4') ; 
INSERT INTO `wp_postmeta` VALUES (404, 140, '_content_3_article_video', 'field_55f1eb8549b96') ; 
INSERT INTO `wp_postmeta` VALUES (405, 140, 'content_3_article_video_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (406, 140, '_content_3_article_video_alignment', 'field_55f1eba549b97') ; 
INSERT INTO `wp_postmeta` VALUES (407, 140, 'content_4_article_text', 'Duis eu pellentesque neque, non ullamcorper lectus. Etiam ut tellus congue turpis bibendum accumsan. Etiam non condimentum neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean tempus ipsum purus, vel consequat sapien feugiat ac. Maecenas vestibulum est vel arcu vestibulum, a tempor nulla maximus. Vivamus hendrerit dolor consequat dignissim dignissim.

Maecenas eu fringilla nisl, nec hendrerit est. Maecenas quis nibh eget ipsum bibendum facilisis. Proin dapibus diam eget rhoncus efficitur. Duis mollis ante at bibendum pharetra. Praesent ultricies mollis accumsan. Nunc feugiat quis velit eget commodo. Praesent ultricies iaculis erat, nec fermentum est pharetra non. Nulla facilisi. Sed sollicitudin mauris ac magna scelerisque vulputate. Etiam sit amet nisi vel eros finibus sodales. Nullam egestas fringilla eros a aliquet. Mauris et mollis erat, in eleifend turpis.') ; 
INSERT INTO `wp_postmeta` VALUES (408, 140, '_content_4_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (409, 140, 'content_5_article_image', '137') ; 
INSERT INTO `wp_postmeta` VALUES (410, 140, '_content_5_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (411, 140, 'content_5_article_image_alignment', 'Float Right') ; 
INSERT INTO `wp_postmeta` VALUES (412, 140, '_content_5_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (413, 140, 'content_6_article_text', 'Vivamus sit amet neque ut arcu maximus gravida. Mauris sodales quam vel finibus auctor. Vestibulum eget nulla turpis. Cras eros augue, semper nec malesuada vel, elementum sed sem. Aenean ac maximus ex, mattis dictum enim. Sed ultrices leo in tellus iaculis imperdiet. Morbi auctor arcu nec elit interdum dapibus. Integer sed leo odio. Aliquam nec ultricies risus, vel porta lectus. Sed accumsan placerat leo, at aliquam felis rhoncus aliquam. Curabitur in sodales massa. Aenean dui est, commodo ac venenatis et, aliquam eu neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse interdum enim quis volutpat sollicitudin. Morbi bibendum est non egestas rhoncus. Cras tempor sagittis nibh sit amet pharetra.

Quisque sagittis, libero in sagittis imperdiet, magna felis tincidunt erat, sit amet sagittis libero risus sed diam. Etiam vestibulum non purus in gravida. Nulla facilisi. Nunc lectus purus, gravida quis ligula vehicula, pulvinar venenatis nibh. Aenean hendrerit eleifend lacus, vel ultrices nisi ultricies eget. Mauris neque quam, laoreet varius maximus id, auctor sit amet ante. Maecenas sed felis sit amet risus varius rutrum nec eu enim. Ut commodo sollicitudin purus ut auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras volutpat tristique neque sit amet pulvinar. Cras sed sem ac dolor ornare sagittis. Morbi augue augue, gravida vitae mi sit amet, ornare tempor libero. Donec sagittis fermentum magna eget aliquam. Etiam fermentum mi a lacinia varius.

Morbi venenatis velit non interdum bibendum. Phasellus iaculis ornare elementum. Vivamus ac imperdiet ligula, eget ultrices diam. Vivamus sed tincidunt turpis. Integer eu auctor eros. Nullam finibus laoreet venenatis. Nunc ac sem cursus, faucibus sem a, aliquam turpis. Praesent bibendum magna vitae pulvinar fermentum. Mauris at sollicitudin orci, sed tempus leo. Fusce quis magna tristique, eleifend metus sed, sodales sapien. Suspendisse sit amet massa consequat nulla lacinia sagittis.') ; 
INSERT INTO `wp_postmeta` VALUES (414, 140, '_content_6_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (415, 140, 'content_7_article_video', 'https://www.youtube.com/watch?v=6FN1Y-Mbsr4') ; 
INSERT INTO `wp_postmeta` VALUES (416, 140, '_content_7_article_video', 'field_55f1eb8549b96') ; 
INSERT INTO `wp_postmeta` VALUES (417, 140, 'content_7_article_video_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (418, 140, '_content_7_article_video_alignment', 'field_55f1eba549b97') ; 
INSERT INTO `wp_postmeta` VALUES (419, 140, 'content_8_article_text', 'In ullamcorper ac eros eu efficitur. Donec a orci orci. Suspendisse egestas lacus in risus feugiat, eget maximus mauris condimentum. Duis ut ante et diam feugiat tincidunt. Morbi nec velit vitae sapien elementum sagittis. Fusce sed luctus massa, quis mollis dolor. Suspendisse facilisis orci et maximus feugiat. Sed quis congue erat. Cras porta efficitur magna, dictum sagittis urna laoreet semper. Etiam ac nunc orci.
<h4>VESTIBULUM ANTE IPSUM PRIMIS IN FAUCIBUS ORCI LUCTUS ET ULTRICES POSUERE CUBILIA CURAE.</h4>
Vestibulum eget pretium elit. Pellentesque nec tempor augue. In velit ipsum, porttitor et vulputate et, sollicitudin ac mi. Aliquam placerat non magna quis auctor. Sed sagittis nisi vitae lectus semper, id semper quam consequat. Nulla posuere, ex in iaculis ultricies, nulla libero sollicitudin dui, ut tristique orci leo ut tortor. Fusce laoreet tincidunt lacus id posuere. Donec et metus sit amet diam lobortis aliquet. Aenean eget vestibulum mauris. Sed id est lacus. Aenean sed congue diam. Nullam pretium dictum elit non tempus. Suspendisse potenti. Pellentesque mattis lorem vitae dolor porttitor, vitae condimentum magna vulputate. Pellentesque bibendum lorem ut lorem dictum, ut venenatis orci tempus.

Aliquam id augue lobortis, pellentesque leo sit amet, bibendum est. Morbi quis ex nec eros efficitur imperdiet vitae id dolor. Pellentesque et lectus vitae augue pretium lobortis. Fusce ante orci, rutrum non ultrices sit amet, pellentesque vitae lacus. Proin at mattis risus. Suspendisse sem magna, ultrices at lectus at, laoreet lobortis tortor. Fusce viverra vestibulum dui id ultrices. Suspendisse eu rhoncus massa, eget sodales elit. Proin gravida dolor at sapien congue, sed vehicula nisi rutrum.') ; 
INSERT INTO `wp_postmeta` VALUES (420, 140, '_content_8_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (421, 140, 'content', 'a:9:{i:0;s:18:"article_text_block";i:1;s:19:"article_image_block";i:2;s:18:"article_text_block";i:3;s:19:"article_video_block";i:4;s:18:"article_text_block";i:5;s:19:"article_image_block";i:6;s:18:"article_text_block";i:7;s:19:"article_video_block";i:8;s:18:"article_text_block";}') ; 
INSERT INTO `wp_postmeta` VALUES (422, 140, '_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (423, 135, '_wp_old_slug', '135') ; 
INSERT INTO `wp_postmeta` VALUES (424, 141, '_wp_attached_file', 'article-image-full-width.png') ; 
INSERT INTO `wp_postmeta` VALUES (425, 141, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:900;s:6:"height";i:506;s:4:"file";s:28:"article-image-full-width.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:36:"article-image-full-width-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:36:"article-image-full-width-300x169.png";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (427, 142, 'article_thumbnail', '138') ; 
INSERT INTO `wp_postmeta` VALUES (428, 142, '_article_thumbnail', 'field_55f1eca1428f9') ; 
INSERT INTO `wp_postmeta` VALUES (429, 142, 'article_excerpt', 'Mauris non tempor quam, et lacinia sapien. Mauris accumsan eros eget li.') ; 
INSERT INTO `wp_postmeta` VALUES (430, 142, '_article_excerpt', 'field_55f1e92e49b8f') ; 
INSERT INTO `wp_postmeta` VALUES (431, 142, 'article_categories', 'a:4:{i:0;s:2:"10";i:1;s:1:"9";i:2;s:1:"5";i:3;s:1:"6";}') ; 
INSERT INTO `wp_postmeta` VALUES (432, 142, '_article_categories', 'field_55f1ece32ad0d') ; 
INSERT INTO `wp_postmeta` VALUES (433, 142, 'content_0_article_image', '141') ; 
INSERT INTO `wp_postmeta` VALUES (434, 142, '_content_0_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (435, 142, 'content_0_article_image_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (436, 142, '_content_0_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (437, 142, 'content_1_article_text', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam feugiat lorem at justo pellentesque, ac molestie nisi scelerisque. <a href="http://9zero7films.dev/">Malesuada eu sapien</a>. Maecenas id pulvinar sapien, sit amet porttitor enim. Pellentesque augue ligula, dapibus id interdum at, tempor ut diam. Aenean elit sapien, vestibulum egestas lorem vitae, ultricies finibus neque.
<ol>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ol>
Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam aliquet, dui vitae eleifend commodo, odio lectus euismod purus, at suscipit urna dui vel urna.
<h2>Sed eget sagittis ex, quis fermentum nibh pellentesque eleifend lectus id lacinia venenatis.</h2>
Suspendisse egestas nisi et fermentum luctus. Mauris sit amet nunc at sem auctor aliquam at a orci. Etiam vel nisi ultricies urna placerat faucibus at vitae diam. Duis sed cursus diam. Maecenas non tempus erat. Sed ut semper ante. Proin dignissim, est vitae ullamcorper blandit, erat nulla laoreet erat, quis euismod nulla augue vel velit.

Sed rutrum nibh ut viverra semper. Quisque lobortis ultricies facilisis. Nulla mauris neque, luctus sed sapien vitae, imperdiet laoreet lacus. Vivamus ex lectus, porta a velit a, ullamcorper auctor massa. Aenean vulputate erat at congue efficitur. Nullam varius egestas ex. <em>Fusce imperdiet tellus et luctus suscipit</em>. Nulla ut dui a massa mollis tincidunt. Pellentesque eu sem eu purus pellentesque feugiat non quis est. Nulla pretium, eros et faucibus molestie, nisi justo faucibus lacus, et venenatis ex augue nec nunc. Nunc id nunc massa.
<ul>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ul>
Nulla venenatis condimentum est, sed efficitur purus congue id. Vivamus a malesuada augue. Donec consequat interdum nisi nec laoreet. Morbi ultrices varius dui, vitae pulvinar nibh ornare sed. Donec semper gravida neque scelerisque bibendum. In eu rutrum mi. Quisque luctus tellus ut sem maximus vehicula. Nunc vel varius nisi, vitae venenatis erat. Cras mollis interdum enim, ac pretium ligula feugiat eu. In sed lectus ut ipsum euismod sodales eget sed augue.
<h3>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (438, 142, '_content_1_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (439, 142, 'content_2_article_image', '136') ; 
INSERT INTO `wp_postmeta` VALUES (440, 142, '_content_2_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (441, 142, 'content_2_article_image_alignment', 'Float Left') ; 
INSERT INTO `wp_postmeta` VALUES (442, 142, '_content_2_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (443, 142, 'content_3_article_text', 'Ut mattis non enim quis pretium. Suspendisse blandit mollis libero sit amet commodo. Quisque sagittis iaculis risus congue rhoncus. Mauris fermentum elit sit amet nunc ullamcorper, non iaculis eros suscipit. Ut facilisis accumsan nunc. Vivamus finibus ut erat ut mollis. Quisque sed lacus enim. Nulla facilisi. Suspendisse non faucibus neque. Quisque lacus elit, sodales a laoreet sollicitudin, elementum sit amet tellus. Quisque metus lorem, ornare non aliquam sit amet, gravida et est. Maecenas quis malesuada ante. Mauris ac neque sit amet justo varius pulvinar quis et enim. Proin aliquet eget enim non ornare. Suspendisse cursus risus nec enim suscipit commodo ac a ligula.

Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean congue erat in mauris viverra eleifend in eget nunc. Aliquam orci erat, blandit quis lorem quis, pellentesque placerat justo. Sed arcu nunc, lacinia quis magna vel, tempor tempus urna. In sit amet mi dapibus, consectetur lorem ac, aliquet metus. Morbi faucibus vitae purus sit amet varius.

Etiam ut tincidunt sapien, eu gravida enim vivamus congue leo tellus, id pellentesque justo finibus at. Maecenas rhoncus magna eget quam bibendum, ut iaculis massa facilisis. Sed sed condimentum tortor, eget tristique mauris. Morbi eu imperdiet nunc. In interdum non ipsum sit amet molestie. Aenean vel eros ornare, ornare elit et, tincidunt quam. Sed ac erat et nulla aliquam euismod eget eget quam. Quisque eget quam ligula. Suspendisse euismod dui vitae euismod tincidunt. Morbi accumsan purus sit amet mattis laoreet.

Suspendisse vitae nibh elementum sapien cursus hendrerit. Mauris varius tortor maximus, gravida lorem nec, commodo massa. Pellentesque malesuada erat quis lacus aliquet lacinia. Quisque vel est a augue porta scelerisque vitae vel risus. Pellentesque nec nisl luctus, dapibus orci a, ornare est.') ; 
INSERT INTO `wp_postmeta` VALUES (444, 142, '_content_3_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (445, 142, 'content_4_article_video', 'https://www.youtube.com/watch?v=6FN1Y-Mbsr4') ; 
INSERT INTO `wp_postmeta` VALUES (446, 142, '_content_4_article_video', 'field_55f1eb8549b96') ; 
INSERT INTO `wp_postmeta` VALUES (447, 142, 'content_4_article_video_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (448, 142, '_content_4_article_video_alignment', 'field_55f1eba549b97') ; 
INSERT INTO `wp_postmeta` VALUES (449, 142, 'content_5_article_text', 'Duis eu pellentesque neque, non ullamcorper lectus. Etiam ut tellus congue turpis bibendum accumsan. Etiam non condimentum neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean tempus ipsum purus, vel consequat sapien feugiat ac. Maecenas vestibulum est vel arcu vestibulum, a tempor nulla maximus. Vivamus hendrerit dolor consequat dignissim dignissim.

Maecenas eu fringilla nisl, nec hendrerit est. Maecenas quis nibh eget ipsum bibendum facilisis. Proin dapibus diam eget rhoncus efficitur. Duis mollis ante at bibendum pharetra. Praesent ultricies mollis accumsan. Nunc feugiat quis velit eget commodo. Praesent ultricies iaculis erat, nec fermentum est pharetra non. Nulla facilisi. Sed sollicitudin mauris ac magna scelerisque vulputate. Etiam sit amet nisi vel eros finibus sodales. Nullam egestas fringilla eros a aliquet. Mauris et mollis erat, in eleifend turpis.') ; 
INSERT INTO `wp_postmeta` VALUES (450, 142, '_content_5_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (451, 142, 'content_6_article_image', '137') ; 
INSERT INTO `wp_postmeta` VALUES (452, 142, '_content_6_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (453, 142, 'content_6_article_image_alignment', 'Float Right') ; 
INSERT INTO `wp_postmeta` VALUES (454, 142, '_content_6_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (455, 142, 'content_7_article_text', 'Vivamus sit amet neque ut arcu maximus gravida. Mauris sodales quam vel finibus auctor. Vestibulum eget nulla turpis. Cras eros augue, semper nec malesuada vel, elementum sed sem. Aenean ac maximus ex, mattis dictum enim. Sed ultrices leo in tellus iaculis imperdiet. Morbi auctor arcu nec elit interdum dapibus. Integer sed leo odio. Aliquam nec ultricies risus, vel porta lectus. Sed accumsan placerat leo, at aliquam felis rhoncus aliquam. Curabitur in sodales massa. Aenean dui est, commodo ac venenatis et, aliquam eu neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse interdum enim quis volutpat sollicitudin. Morbi bibendum est non egestas rhoncus. Cras tempor sagittis nibh sit amet pharetra.

Quisque sagittis, libero in sagittis imperdiet, magna felis tincidunt erat, sit amet sagittis libero risus sed diam. Etiam vestibulum non purus in gravida. Nulla facilisi. Nunc lectus purus, gravida quis ligula vehicula, pulvinar venenatis nibh. Aenean hendrerit eleifend lacus, vel ultrices nisi ultricies eget. Mauris neque quam, laoreet varius maximus id, auctor sit amet ante. Maecenas sed felis sit amet risus varius rutrum nec eu enim. Ut commodo sollicitudin purus ut auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras volutpat tristique neque sit amet pulvinar. Cras sed sem ac dolor ornare sagittis. Morbi augue augue, gravida vitae mi sit amet, ornare tempor libero. Donec sagittis fermentum magna eget aliquam. Etiam fermentum mi a lacinia varius.

Morbi venenatis velit non interdum bibendum. Phasellus iaculis ornare elementum. Vivamus ac imperdiet ligula, eget ultrices diam. Vivamus sed tincidunt turpis. Integer eu auctor eros. Nullam finibus laoreet venenatis. Nunc ac sem cursus, faucibus sem a, aliquam turpis. Praesent bibendum magna vitae pulvinar fermentum. Mauris at sollicitudin orci, sed tempus leo. Fusce quis magna tristique, eleifend metus sed, sodales sapien. Suspendisse sit amet massa consequat nulla lacinia sagittis.') ; 
INSERT INTO `wp_postmeta` VALUES (456, 142, '_content_7_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (457, 142, 'content_8_article_video', 'https://www.youtube.com/watch?v=6FN1Y-Mbsr4') ; 
INSERT INTO `wp_postmeta` VALUES (458, 142, '_content_8_article_video', 'field_55f1eb8549b96') ; 
INSERT INTO `wp_postmeta` VALUES (459, 142, 'content_8_article_video_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (460, 142, '_content_8_article_video_alignment', 'field_55f1eba549b97') ; 
INSERT INTO `wp_postmeta` VALUES (461, 142, 'content_9_article_text', 'In ullamcorper ac eros eu efficitur. Donec a orci orci. Suspendisse egestas lacus in risus feugiat, eget maximus mauris condimentum. Duis ut ante et diam feugiat tincidunt. Morbi nec velit vitae sapien elementum sagittis. Fusce sed luctus massa, quis mollis dolor. Suspendisse facilisis orci et maximus feugiat. Sed quis congue erat. Cras porta efficitur magna, dictum sagittis urna laoreet semper. Etiam ac nunc orci.
<h4>VESTIBULUM ANTE IPSUM PRIMIS IN FAUCIBUS ORCI LUCTUS ET ULTRICES POSUERE CUBILIA CURAE.</h4>
Vestibulum eget pretium elit. Pellentesque nec tempor augue. In velit ipsum, porttitor et vulputate et, sollicitudin ac mi. Aliquam placerat non magna quis auctor. Sed sagittis nisi vitae lectus semper, id semper quam consequat. Nulla posuere, ex in iaculis ultricies, nulla libero sollicitudin dui, ut tristique orci leo ut tortor. Fusce laoreet tincidunt lacus id posuere. Donec et metus sit amet diam lobortis aliquet. Aenean eget vestibulum mauris. Sed id est lacus. Aenean sed congue diam. Nullam pretium dictum elit non tempus. Suspendisse potenti. Pellentesque mattis lorem vitae dolor porttitor, vitae condimentum magna vulputate. Pellentesque bibendum lorem ut lorem dictum, ut venenatis orci tempus.

Aliquam id augue lobortis, pellentesque leo sit amet, bibendum est. Morbi quis ex nec eros efficitur imperdiet vitae id dolor. Pellentesque et lectus vitae augue pretium lobortis. Fusce ante orci, rutrum non ultrices sit amet, pellentesque vitae lacus. Proin at mattis risus. Suspendisse sem magna, ultrices at lectus at, laoreet lobortis tortor. Fusce viverra vestibulum dui id ultrices. Suspendisse eu rhoncus massa, eget sodales elit. Proin gravida dolor at sapien congue, sed vehicula nisi rutrum.') ; 
INSERT INTO `wp_postmeta` VALUES (462, 142, '_content_9_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (463, 142, 'content', 'a:10:{i:0;s:19:"article_image_block";i:1;s:18:"article_text_block";i:2;s:19:"article_image_block";i:3;s:18:"article_text_block";i:4;s:19:"article_video_block";i:5;s:18:"article_text_block";i:6;s:19:"article_image_block";i:7;s:18:"article_text_block";i:8;s:19:"article_video_block";i:9;s:18:"article_text_block";}') ; 
INSERT INTO `wp_postmeta` VALUES (464, 142, '_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (465, 135, 'content_0_article_image', '141') ; 
INSERT INTO `wp_postmeta` VALUES (466, 135, '_content_0_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (467, 135, 'content_0_article_image_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (468, 135, '_content_0_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (469, 135, 'content_1_article_text', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam feugiat lorem at justo pellentesque, ac molestie nisi scelerisque. <a href="http://9zero7films.dev/">Malesuada eu sapien</a>. Maecenas id pulvinar sapien, sit amet porttitor enim. Pellentesque augue ligula, dapibus id interdum at, tempor ut diam. Aenean elit sapien, vestibulum egestas lorem vitae, ultricies finibus neque.
<ol>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ol>
Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam aliquet, dui vitae eleifend commodo, odio lectus euismod purus, at suscipit urna dui vel urna.
<h2>Sed eget sagittis ex, quis fermentum nibh pellentesque eleifend lectus id lacinia venenatis.</h2>
Suspendisse egestas nisi et fermentum luctus. Mauris sit amet nunc at sem auctor aliquam at a orci. Etiam vel nisi ultricies urna placerat faucibus at vitae diam. Duis sed cursus diam. Maecenas non tempus erat. Sed ut semper ante. Proin dignissim, est vitae ullamcorper blandit, erat nulla laoreet erat, quis euismod nulla augue vel velit.

Sed rutrum nibh ut viverra semper. Quisque lobortis ultricies facilisis. Nulla mauris neque, luctus sed sapien vitae, imperdiet laoreet lacus. Vivamus ex lectus, porta a velit a, ullamcorper auctor massa. Aenean vulputate erat at congue efficitur. Nullam varius egestas ex. <em>Fusce imperdiet tellus et luctus suscipit</em>. Nulla ut dui a massa mollis tincidunt. Pellentesque eu sem eu purus pellentesque feugiat non quis est. Nulla pretium, eros et faucibus molestie, nisi justo faucibus lacus, et venenatis ex augue nec nunc. Nunc id nunc massa.
<ul>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ul>
Nulla venenatis condimentum est, sed efficitur purus congue id. Vivamus a malesuada augue. Donec consequat interdum nisi nec laoreet. Morbi ultrices varius dui, vitae pulvinar nibh ornare sed. Donec semper gravida neque scelerisque bibendum. In eu rutrum mi. Quisque luctus tellus ut sem maximus vehicula. Nunc vel varius nisi, vitae venenatis erat. Cras mollis interdum enim, ac pretium ligula feugiat eu. In sed lectus ut ipsum euismod sodales eget sed augue.
<h3>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (470, 135, '_content_1_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (471, 135, 'content_2_article_image', '136') ; 
INSERT INTO `wp_postmeta` VALUES (472, 135, '_content_2_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (473, 135, 'content_2_article_image_alignment', 'Float Left') ; 
INSERT INTO `wp_postmeta` VALUES (474, 135, '_content_2_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (475, 135, 'content_3_article_text', 'Ut mattis non enim quis pretium. Suspendisse blandit mollis libero sit amet commodo. Quisque sagittis iaculis risus congue rhoncus. Mauris fermentum elit sit amet nunc ullamcorper, non iaculis eros suscipit. Ut facilisis accumsan nunc. Vivamus finibus ut erat ut mollis. Quisque sed lacus enim. Nulla facilisi. Suspendisse non faucibus neque. Quisque lacus elit, sodales a laoreet sollicitudin, elementum sit amet tellus. Quisque metus lorem, ornare non aliquam sit amet, gravida et est. Maecenas quis malesuada ante. Mauris ac neque sit amet justo varius pulvinar quis et enim. Proin aliquet eget enim non ornare. Suspendisse cursus risus nec enim suscipit commodo ac a ligula.

Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean congue erat in mauris viverra eleifend in eget nunc. Aliquam orci erat, blandit quis lorem quis, pellentesque placerat justo. Sed arcu nunc, lacinia quis magna vel, tempor tempus urna. In sit amet mi dapibus, consectetur lorem ac, aliquet metus. Morbi faucibus vitae purus sit amet varius.

Etiam ut tincidunt sapien, eu gravida enim vivamus congue leo tellus, id pellentesque justo finibus at. Maecenas rhoncus magna eget quam bibendum, ut iaculis massa facilisis. Sed sed condimentum tortor, eget tristique mauris. Morbi eu imperdiet nunc. In interdum non ipsum sit amet molestie. Aenean vel eros ornare, ornare elit et, tincidunt quam. Sed ac erat et nulla aliquam euismod eget eget quam. Quisque eget quam ligula. Suspendisse euismod dui vitae euismod tincidunt. Morbi accumsan purus sit amet mattis laoreet.

Suspendisse vitae nibh elementum sapien cursus hendrerit. Mauris varius tortor maximus, gravida lorem nec, commodo massa. Pellentesque malesuada erat quis lacus aliquet lacinia. Quisque vel est a augue porta scelerisque vitae vel risus. Pellentesque nec nisl luctus, dapibus orci a, ornare est.') ; 
INSERT INTO `wp_postmeta` VALUES (476, 135, '_content_3_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (477, 135, 'content_4_article_video', 'https://www.youtube.com/watch?v=6FN1Y-Mbsr4') ; 
INSERT INTO `wp_postmeta` VALUES (478, 135, '_content_4_article_video', 'field_55f1eb8549b96') ; 
INSERT INTO `wp_postmeta` VALUES (479, 135, 'content_4_article_video_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (480, 135, '_content_4_article_video_alignment', 'field_55f1eba549b97') ; 
INSERT INTO `wp_postmeta` VALUES (481, 135, 'content_5_article_text', 'Duis eu pellentesque neque, non ullamcorper lectus. Etiam ut tellus congue turpis bibendum accumsan. Etiam non condimentum neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean tempus ipsum purus, vel consequat sapien feugiat ac. Maecenas vestibulum est vel arcu vestibulum, a tempor nulla maximus. Vivamus hendrerit dolor consequat dignissim dignissim.

Maecenas eu fringilla nisl, nec hendrerit est. Maecenas quis nibh eget ipsum bibendum facilisis. Proin dapibus diam eget rhoncus efficitur. Duis mollis ante at bibendum pharetra. Praesent ultricies mollis accumsan. Nunc feugiat quis velit eget commodo. Praesent ultricies iaculis erat, nec fermentum est pharetra non. Nulla facilisi. Sed sollicitudin mauris ac magna scelerisque vulputate. Etiam sit amet nisi vel eros finibus sodales. Nullam egestas fringilla eros a aliquet. Mauris et mollis erat, in eleifend turpis.') ; 
INSERT INTO `wp_postmeta` VALUES (482, 135, '_content_5_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (483, 135, 'content_6_article_image', '137') ; 
INSERT INTO `wp_postmeta` VALUES (484, 135, '_content_6_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (485, 135, 'content_6_article_image_alignment', 'Float Right') ; 
INSERT INTO `wp_postmeta` VALUES (486, 135, '_content_6_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (487, 135, 'content_7_article_text', 'Vivamus sit amet neque ut arcu maximus gravida. Mauris sodales quam vel finibus auctor. Vestibulum eget nulla turpis. Cras eros augue, semper nec malesuada vel, elementum sed sem. Aenean ac maximus ex, mattis dictum enim. Sed ultrices leo in tellus iaculis imperdiet. Morbi auctor arcu nec elit interdum dapibus. Integer sed leo odio. Aliquam nec ultricies risus, vel porta lectus. Sed accumsan placerat leo, at aliquam felis rhoncus aliquam. Curabitur in sodales massa. Aenean dui est, commodo ac venenatis et, aliquam eu neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse interdum enim quis volutpat sollicitudin. Morbi bibendum est non egestas rhoncus. Cras tempor sagittis nibh sit amet pharetra.

Quisque sagittis, libero in sagittis imperdiet, magna felis tincidunt erat, sit amet sagittis libero risus sed diam. Etiam vestibulum non purus in gravida. Nulla facilisi. Nunc lectus purus, gravida quis ligula vehicula, pulvinar venenatis nibh. Aenean hendrerit eleifend lacus, vel ultrices nisi ultricies eget. Mauris neque quam, laoreet varius maximus id, auctor sit amet ante. Maecenas sed felis sit amet risus varius rutrum nec eu enim. Ut commodo sollicitudin purus ut auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras volutpat tristique neque sit amet pulvinar. Cras sed sem ac dolor ornare sagittis. Morbi augue augue, gravida vitae mi sit amet, ornare tempor libero. Donec sagittis fermentum magna eget aliquam. Etiam fermentum mi a lacinia varius.

Morbi venenatis velit non interdum bibendum. Phasellus iaculis ornare elementum. Vivamus ac imperdiet ligula, eget ultrices diam. Vivamus sed tincidunt turpis. Integer eu auctor eros. Nullam finibus laoreet venenatis. Nunc ac sem cursus, faucibus sem a, aliquam turpis. Praesent bibendum magna vitae pulvinar fermentum. Mauris at sollicitudin orci, sed tempus leo. Fusce quis magna tristique, eleifend metus sed, sodales sapien. Suspendisse sit amet massa consequat nulla lacinia sagittis.') ; 
INSERT INTO `wp_postmeta` VALUES (488, 135, '_content_7_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (489, 135, 'content_8_article_video', 'https://www.youtube.com/watch?v=6FN1Y-Mbsr4') ; 
INSERT INTO `wp_postmeta` VALUES (490, 135, '_content_8_article_video', 'field_55f1eb8549b96') ; 
INSERT INTO `wp_postmeta` VALUES (491, 135, 'content_8_article_video_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (492, 135, '_content_8_article_video_alignment', 'field_55f1eba549b97') ; 
INSERT INTO `wp_postmeta` VALUES (493, 135, 'content_9_article_text', 'In ullamcorper ac eros eu efficitur. Donec a orci orci. Suspendisse egestas lacus in risus feugiat, eget maximus mauris condimentum. Duis ut ante et diam feugiat tincidunt. Morbi nec velit vitae sapien elementum sagittis. Fusce sed luctus massa, quis mollis dolor. Suspendisse facilisis orci et maximus feugiat. Sed quis congue erat. Cras porta efficitur magna, dictum sagittis urna laoreet semper. Etiam ac nunc orci.
<h4>VESTIBULUM ANTE IPSUM PRIMIS IN FAUCIBUS ORCI LUCTUS ET ULTRICES POSUERE CUBILIA CURAE.</h4>
Vestibulum eget pretium elit. Pellentesque nec tempor augue. In velit ipsum, porttitor et vulputate et, sollicitudin ac mi. Aliquam placerat non magna quis auctor. Sed sagittis nisi vitae lectus semper, id semper quam consequat. Nulla posuere, ex in iaculis ultricies, nulla libero sollicitudin dui, ut tristique orci leo ut tortor. Fusce laoreet tincidunt lacus id posuere. Donec et metus sit amet diam lobortis aliquet. Aenean eget vestibulum mauris. Sed id est lacus. Aenean sed congue diam. Nullam pretium dictum elit non tempus. Suspendisse potenti. Pellentesque mattis lorem vitae dolor porttitor, vitae condimentum magna vulputate. Pellentesque bibendum lorem ut lorem dictum, ut venenatis orci tempus.

Aliquam id augue lobortis, pellentesque leo sit amet, bibendum est. Morbi quis ex nec eros efficitur imperdiet vitae id dolor. Pellentesque et lectus vitae augue pretium lobortis. Fusce ante orci, rutrum non ultrices sit amet, pellentesque vitae lacus. Proin at mattis risus. Suspendisse sem magna, ultrices at lectus at, laoreet lobortis tortor. Fusce viverra vestibulum dui id ultrices. Suspendisse eu rhoncus massa, eget sodales elit. Proin gravida dolor at sapien congue, sed vehicula nisi rutrum.') ; 
INSERT INTO `wp_postmeta` VALUES (494, 135, '_content_9_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (495, 143, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (496, 143, '_edit_lock', '1441919592:1') ; 
INSERT INTO `wp_postmeta` VALUES (497, 144, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (498, 144, '_edit_lock', '1442006022:1') ; 
INSERT INTO `wp_postmeta` VALUES (499, 145, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (500, 145, '_edit_lock', '1441920226:1') ; 
INSERT INTO `wp_postmeta` VALUES (501, 146, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (502, 146, '_edit_lock', '1441920123:1') ; 
INSERT INTO `wp_postmeta` VALUES (503, 149, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (504, 149, '_edit_lock', '1441920134:1') ; 
INSERT INTO `wp_postmeta` VALUES (505, 149, 'testimonial_title', 'Student') ; 
INSERT INTO `wp_postmeta` VALUES (506, 149, '_testimonial_title', 'field_55f1f31db6da0') ; 
INSERT INTO `wp_postmeta` VALUES (507, 149, 'testimonial_quote', 'Nam porttitor blandit accumsan. Ut vel dictum sem, a pretium dui. In malesuada enim in dolor euismod, id commodo mi consectetur. Curabitur at vestibulum nisi. Nullam vehicula nisi velit.') ; 
INSERT INTO `wp_postmeta` VALUES (508, 149, '_testimonial_quote', 'field_55f1f2d0b6d9f') ; 
INSERT INTO `wp_postmeta` VALUES (510, 150, 'article_thumbnail', '138') ; 
INSERT INTO `wp_postmeta` VALUES (511, 150, '_article_thumbnail', 'field_55f1eca1428f9') ; 
INSERT INTO `wp_postmeta` VALUES (512, 150, 'article_excerpt', 'Mauris non tempor quam, et lacinia sapien. Mauris accumsan eros eget li.') ; 
INSERT INTO `wp_postmeta` VALUES (513, 150, '_article_excerpt', 'field_55f1e92e49b8f') ; 
INSERT INTO `wp_postmeta` VALUES (514, 150, 'article_categories', 'a:4:{i:0;s:2:"10";i:1;s:1:"9";i:2;s:1:"5";i:3;s:1:"6";}') ; 
INSERT INTO `wp_postmeta` VALUES (515, 150, '_article_categories', 'field_55f1ece32ad0d') ; 
INSERT INTO `wp_postmeta` VALUES (516, 150, 'content_0_article_image', '141') ; 
INSERT INTO `wp_postmeta` VALUES (517, 150, '_content_0_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (518, 150, 'content_0_article_image_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (519, 150, '_content_0_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (520, 150, 'content_1_article_text', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam feugiat lorem at justo pellentesque, ac molestie nisi scelerisque. <a href="http://9zero7films.dev/">Malesuada eu sapien</a>. Maecenas id pulvinar sapien, sit amet porttitor enim. Pellentesque augue ligula, dapibus id interdum at, tempor ut diam. Aenean elit sapien, vestibulum egestas lorem vitae, ultricies finibus neque.
<ol>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ol>
Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam aliquet, dui vitae eleifend commodo, odio lectus euismod purus, at suscipit urna dui vel urna.
<h2>Sed eget sagittis ex, quis fermentum nibh pellentesque eleifend lectus id lacinia venenatis.</h2>
Suspendisse egestas nisi et fermentum luctus. Mauris sit amet nunc at sem auctor aliquam at a orci. Etiam vel nisi ultricies urna placerat faucibus at vitae diam. Duis sed cursus diam. Maecenas non tempus erat. Sed ut semper ante. Proin dignissim, est vitae ullamcorper blandit, erat nulla laoreet erat, quis euismod nulla augue vel velit.

Sed rutrum nibh ut viverra semper. Quisque lobortis ultricies facilisis. Nulla mauris neque, luctus sed sapien vitae, imperdiet laoreet lacus. Vivamus ex lectus, porta a velit a, ullamcorper auctor massa. Aenean vulputate erat at congue efficitur. Nullam varius egestas ex. <em>Fusce imperdiet tellus et luctus suscipit</em>. Nulla ut dui a massa mollis tincidunt. Pellentesque eu sem eu purus pellentesque feugiat non quis est. Nulla pretium, eros et faucibus molestie, nisi justo faucibus lacus, et venenatis ex augue nec nunc. Nunc id nunc massa.
<ul>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ul>
Nulla venenatis condimentum est, sed efficitur purus congue id. Vivamus a malesuada augue. Donec consequat interdum nisi nec laoreet. Morbi ultrices varius dui, vitae pulvinar nibh ornare sed. Donec semper gravida neque scelerisque bibendum. In eu rutrum mi. Quisque luctus tellus ut sem maximus vehicula. Nunc vel varius nisi, vitae venenatis erat. Cras mollis interdum enim, ac pretium ligula feugiat eu. In sed lectus ut ipsum euismod sodales eget sed augue.
<h3>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h3>') ; 
INSERT INTO `wp_postmeta` VALUES (521, 150, '_content_1_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (522, 150, 'content_2_article_image', '136') ; 
INSERT INTO `wp_postmeta` VALUES (523, 150, '_content_2_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (524, 150, 'content_2_article_image_alignment', 'Float Left') ; 
INSERT INTO `wp_postmeta` VALUES (525, 150, '_content_2_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (526, 150, 'content_3_article_text', 'Ut mattis non enim quis pretium. Suspendisse blandit mollis libero sit amet commodo. Quisque sagittis iaculis risus congue rhoncus. Mauris fermentum elit sit amet nunc ullamcorper, non iaculis eros suscipit. Ut facilisis accumsan nunc. Vivamus finibus ut erat ut mollis. Quisque sed lacus enim. Nulla facilisi. Suspendisse non faucibus neque. Quisque lacus elit, sodales a laoreet sollicitudin, elementum sit amet tellus. Quisque metus lorem, ornare non aliquam sit amet, gravida et est. Maecenas quis malesuada ante. Mauris ac neque sit amet justo varius pulvinar quis et enim. Proin aliquet eget enim non ornare. Suspendisse cursus risus nec enim suscipit commodo ac a ligula.

Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean congue erat in mauris viverra eleifend in eget nunc. Aliquam orci erat, blandit quis lorem quis, pellentesque placerat justo. Sed arcu nunc, lacinia quis magna vel, tempor tempus urna. In sit amet mi dapibus, consectetur lorem ac, aliquet metus. Morbi faucibus vitae purus sit amet varius.

Etiam ut tincidunt sapien, eu gravida enim vivamus congue leo tellus, id pellentesque justo finibus at. Maecenas rhoncus magna eget quam bibendum, ut iaculis massa facilisis. Sed sed condimentum tortor, eget tristique mauris. Morbi eu imperdiet nunc. In interdum non ipsum sit amet molestie. Aenean vel eros ornare, ornare elit et, tincidunt quam. Sed ac erat et nulla aliquam euismod eget eget quam. Quisque eget quam ligula. Suspendisse euismod dui vitae euismod tincidunt. Morbi accumsan purus sit amet mattis laoreet.

Suspendisse vitae nibh elementum sapien cursus hendrerit. Mauris varius tortor maximus, gravida lorem nec, commodo massa. Pellentesque malesuada erat quis lacus aliquet lacinia. Quisque vel est a augue porta scelerisque vitae vel risus. Pellentesque nec nisl luctus, dapibus orci a, ornare est.') ; 
INSERT INTO `wp_postmeta` VALUES (527, 150, '_content_3_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (528, 150, 'content_4_article_testimonial', 'a:1:{i:0;s:3:"149";}') ; 
INSERT INTO `wp_postmeta` VALUES (529, 150, '_content_4_article_testimonial', 'field_55f1ebf149b99') ; 
INSERT INTO `wp_postmeta` VALUES (530, 150, 'content_5_article_text', 'Duis eu pellentesque neque, non ullamcorper lectus. Etiam ut tellus congue turpis bibendum accumsan. Etiam non condimentum neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean tempus ipsum purus, vel consequat sapien feugiat ac. Maecenas vestibulum est vel arcu vestibulum, a tempor nulla maximus. Vivamus hendrerit dolor consequat dignissim dignissim.

Maecenas eu fringilla nisl, nec hendrerit est. Maecenas quis nibh eget ipsum bibendum facilisis. Proin dapibus diam eget rhoncus efficitur. Duis mollis ante at bibendum pharetra. Praesent ultricies mollis accumsan. Nunc feugiat quis velit eget commodo. Praesent ultricies iaculis erat, nec fermentum est pharetra non. Nulla facilisi. Sed sollicitudin mauris ac magna scelerisque vulputate. Etiam sit amet nisi vel eros finibus sodales. Nullam egestas fringilla eros a aliquet. Mauris et mollis erat, in eleifend turpis.') ; 
INSERT INTO `wp_postmeta` VALUES (531, 150, '_content_5_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (532, 150, 'content_6_article_image', '137') ; 
INSERT INTO `wp_postmeta` VALUES (533, 150, '_content_6_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (534, 150, 'content_6_article_image_alignment', 'Float Right') ; 
INSERT INTO `wp_postmeta` VALUES (535, 150, '_content_6_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (536, 150, 'content_7_article_text', 'Vivamus sit amet neque ut arcu maximus gravida. Mauris sodales quam vel finibus auctor. Vestibulum eget nulla turpis. Cras eros augue, semper nec malesuada vel, elementum sed sem. Aenean ac maximus ex, mattis dictum enim. Sed ultrices leo in tellus iaculis imperdiet. Morbi auctor arcu nec elit interdum dapibus. Integer sed leo odio. Aliquam nec ultricies risus, vel porta lectus. Sed accumsan placerat leo, at aliquam felis rhoncus aliquam. Curabitur in sodales massa. Aenean dui est, commodo ac venenatis et, aliquam eu neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse interdum enim quis volutpat sollicitudin. Morbi bibendum est non egestas rhoncus. Cras tempor sagittis nibh sit amet pharetra.

Quisque sagittis, libero in sagittis imperdiet, magna felis tincidunt erat, sit amet sagittis libero risus sed diam. Etiam vestibulum non purus in gravida. Nulla facilisi. Nunc lectus purus, gravida quis ligula vehicula, pulvinar venenatis nibh. Aenean hendrerit eleifend lacus, vel ultrices nisi ultricies eget. Mauris neque quam, laoreet varius maximus id, auctor sit amet ante. Maecenas sed felis sit amet risus varius rutrum nec eu enim. Ut commodo sollicitudin purus ut auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras volutpat tristique neque sit amet pulvinar. Cras sed sem ac dolor ornare sagittis. Morbi augue augue, gravida vitae mi sit amet, ornare tempor libero. Donec sagittis fermentum magna eget aliquam. Etiam fermentum mi a lacinia varius.

Morbi venenatis velit non interdum bibendum. Phasellus iaculis ornare elementum. Vivamus ac imperdiet ligula, eget ultrices diam. Vivamus sed tincidunt turpis. Integer eu auctor eros. Nullam finibus laoreet venenatis. Nunc ac sem cursus, faucibus sem a, aliquam turpis. Praesent bibendum magna vitae pulvinar fermentum. Mauris at sollicitudin orci, sed tempus leo. Fusce quis magna tristique, eleifend metus sed, sodales sapien. Suspendisse sit amet massa consequat nulla lacinia sagittis.') ; 
INSERT INTO `wp_postmeta` VALUES (537, 150, '_content_7_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (538, 150, 'content_8_article_video', 'https://www.youtube.com/watch?v=6FN1Y-Mbsr4') ; 
INSERT INTO `wp_postmeta` VALUES (539, 150, '_content_8_article_video', 'field_55f1eb8549b96') ; 
INSERT INTO `wp_postmeta` VALUES (540, 150, 'content_8_article_video_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (541, 150, '_content_8_article_video_alignment', 'field_55f1eba549b97') ; 
INSERT INTO `wp_postmeta` VALUES (542, 150, 'content_9_article_text', 'In ullamcorper ac eros eu efficitur. Donec a orci orci. Suspendisse egestas lacus in risus feugiat, eget maximus mauris condimentum. Duis ut ante et diam feugiat tincidunt. Morbi nec velit vitae sapien elementum sagittis. Fusce sed luctus massa, quis mollis dolor. Suspendisse facilisis orci et maximus feugiat. Sed quis congue erat. Cras porta efficitur magna, dictum sagittis urna laoreet semper. Etiam ac nunc orci.
<h4>VESTIBULUM ANTE IPSUM PRIMIS IN FAUCIBUS ORCI LUCTUS ET ULTRICES POSUERE CUBILIA CURAE.</h4>
Vestibulum eget pretium elit. Pellentesque nec tempor augue. In velit ipsum, porttitor et vulputate et, sollicitudin ac mi. Aliquam placerat non magna quis auctor. Sed sagittis nisi vitae lectus semper, id semper quam consequat. Nulla posuere, ex in iaculis ultricies, nulla libero sollicitudin dui, ut tristique orci leo ut tortor. Fusce laoreet tincidunt lacus id posuere. Donec et metus sit amet diam lobortis aliquet. Aenean eget vestibulum mauris. Sed id est lacus. Aenean sed congue diam. Nullam pretium dictum elit non tempus. Suspendisse potenti. Pellentesque mattis lorem vitae dolor porttitor, vitae condimentum magna vulputate. Pellentesque bibendum lorem ut lorem dictum, ut venenatis orci tempus.

Aliquam id augue lobortis, pellentesque leo sit amet, bibendum est. Morbi quis ex nec eros efficitur imperdiet vitae id dolor. Pellentesque et lectus vitae augue pretium lobortis. Fusce ante orci, rutrum non ultrices sit amet, pellentesque vitae lacus. Proin at mattis risus. Suspendisse sem magna, ultrices at lectus at, laoreet lobortis tortor. Fusce viverra vestibulum dui id ultrices. Suspendisse eu rhoncus massa, eget sodales elit. Proin gravida dolor at sapien congue, sed vehicula nisi rutrum.') ; 
INSERT INTO `wp_postmeta` VALUES (543, 150, '_content_9_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (544, 150, 'content', 'a:10:{i:0;s:19:"article_image_block";i:1;s:18:"article_text_block";i:2;s:19:"article_image_block";i:3;s:18:"article_text_block";i:4;s:25:"article_testimonial_block";i:5;s:18:"article_text_block";i:6;s:19:"article_image_block";i:7;s:18:"article_text_block";i:8;s:19:"article_video_block";i:9;s:18:"article_text_block";}') ; 
INSERT INTO `wp_postmeta` VALUES (545, 150, '_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (546, 135, 'content_4_article_testimonial', 'a:1:{i:0;s:3:"149";}') ; 
INSERT INTO `wp_postmeta` VALUES (547, 135, '_content_4_article_testimonial', 'field_55f1ebf149b99') ; 
INSERT INTO `wp_postmeta` VALUES (548, 152, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (549, 152, 'sponsor_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (550, 152, '_sponsor_url', 'field_55f1f4cad113a') ; 
INSERT INTO `wp_postmeta` VALUES (551, 152, '_edit_lock', '1441920245:1') ; 
INSERT INTO `wp_postmeta` VALUES (552, 153, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (553, 153, 'sponsor_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (554, 153, '_sponsor_url', 'field_55f1f4cad113a') ; 
INSERT INTO `wp_postmeta` VALUES (555, 153, '_edit_lock', '1441920260:1') ; 
INSERT INTO `wp_postmeta` VALUES (556, 154, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (557, 154, 'sponsor_url', 'http://www.9zero7films.com') ; 
INSERT INTO `wp_postmeta` VALUES (558, 154, '_sponsor_url', 'field_55f1f4cad113a') ; 
INSERT INTO `wp_postmeta` VALUES (559, 154, '_edit_lock', '1442005761:1') ; 
INSERT INTO `wp_postmeta` VALUES (560, 155, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (561, 155, 'sponsor_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (562, 155, '_sponsor_url', 'field_55f1f4cad113a') ; 
INSERT INTO `wp_postmeta` VALUES (563, 155, '_edit_lock', '1441920301:1') ; 
INSERT INTO `wp_postmeta` VALUES (564, 156, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (565, 156, 'sponsor_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (566, 156, '_sponsor_url', 'field_55f1f4cad113a') ; 
INSERT INTO `wp_postmeta` VALUES (567, 156, '_edit_lock', '1441920315:1') ; 
INSERT INTO `wp_postmeta` VALUES (568, 157, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (569, 157, 'sponsor_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (570, 157, '_sponsor_url', 'field_55f1f4cad113a') ; 
INSERT INTO `wp_postmeta` VALUES (571, 157, '_edit_lock', '1441920335:1') ; 
INSERT INTO `wp_postmeta` VALUES (572, 158, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (573, 158, 'sponsor_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (574, 158, '_sponsor_url', 'field_55f1f4cad113a') ; 
INSERT INTO `wp_postmeta` VALUES (575, 158, '_edit_lock', '1441920351:1') ; 
INSERT INTO `wp_postmeta` VALUES (576, 159, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (577, 159, 'sponsor_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (578, 159, '_sponsor_url', 'field_55f1f4cad113a') ; 
INSERT INTO `wp_postmeta` VALUES (579, 159, '_edit_lock', '1441920365:1') ; 
INSERT INTO `wp_postmeta` VALUES (580, 160, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (581, 160, 'sponsor_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (582, 160, '_sponsor_url', 'field_55f1f4cad113a') ; 
INSERT INTO `wp_postmeta` VALUES (583, 160, '_edit_lock', '1441920381:1') ; 
INSERT INTO `wp_postmeta` VALUES (584, 161, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (585, 161, '_edit_lock', '1442005445:1') ; 
INSERT INTO `wp_postmeta` VALUES (599, 135, '_wp_old_slug', 'example-article-one') ; 
INSERT INTO `wp_postmeta` VALUES (600, 165, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (602, 166, 'article_thumbnail', '') ; 
INSERT INTO `wp_postmeta` VALUES (603, 166, '_article_thumbnail', 'field_55f1eca1428f9') ; 
INSERT INTO `wp_postmeta` VALUES (604, 166, 'article_excerpt', '') ; 
INSERT INTO `wp_postmeta` VALUES (605, 166, '_article_excerpt', 'field_55f1e92e49b8f') ; 
INSERT INTO `wp_postmeta` VALUES (606, 166, 'article_categories', '') ; 
INSERT INTO `wp_postmeta` VALUES (607, 166, '_article_categories', 'field_55f1ece32ad0d') ; 
INSERT INTO `wp_postmeta` VALUES (608, 166, 'content', '') ; 
INSERT INTO `wp_postmeta` VALUES (609, 166, '_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (610, 165, 'article_thumbnail', '') ; 
INSERT INTO `wp_postmeta` VALUES (611, 165, '_article_thumbnail', 'field_55f1eca1428f9') ; 
INSERT INTO `wp_postmeta` VALUES (612, 165, 'article_excerpt', 'Mauris non tempor quam, et lacinia sapien. Mauris accumsan eros eget li.') ; 
INSERT INTO `wp_postmeta` VALUES (613, 165, '_article_excerpt', 'field_55f1e92e49b8f') ; 
INSERT INTO `wp_postmeta` VALUES (614, 165, 'article_categories', 'a:5:{i:0;s:2:"11";i:1;s:1:"9";i:2;s:1:"7";i:3;s:1:"5";i:4;s:1:"4";}') ; 
INSERT INTO `wp_postmeta` VALUES (615, 165, '_article_categories', 'field_55f1ece32ad0d') ; 
INSERT INTO `wp_postmeta` VALUES (616, 165, 'content', '') ; 
INSERT INTO `wp_postmeta` VALUES (617, 165, '_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (618, 165, '_edit_lock', '1442007563:1') ; 
INSERT INTO `wp_postmeta` VALUES (619, 167, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (621, 168, 'article_thumbnail', '') ; 
INSERT INTO `wp_postmeta` VALUES (622, 168, '_article_thumbnail', 'field_55f1eca1428f9') ; 
INSERT INTO `wp_postmeta` VALUES (623, 168, 'article_excerpt', '') ; 
INSERT INTO `wp_postmeta` VALUES (624, 168, '_article_excerpt', 'field_55f1e92e49b8f') ; 
INSERT INTO `wp_postmeta` VALUES (625, 168, 'article_categories', '') ; 
INSERT INTO `wp_postmeta` VALUES (626, 168, '_article_categories', 'field_55f1ece32ad0d') ; 
INSERT INTO `wp_postmeta` VALUES (627, 168, 'content', '') ; 
INSERT INTO `wp_postmeta` VALUES (628, 168, '_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (629, 167, 'article_thumbnail', '138') ; 
INSERT INTO `wp_postmeta` VALUES (630, 167, '_article_thumbnail', 'field_55f1eca1428f9') ; 
INSERT INTO `wp_postmeta` VALUES (631, 167, 'article_excerpt', 'Mauris non tempor quam, et lacinia sapien. Mauris accumsan eros eget li.') ; 
INSERT INTO `wp_postmeta` VALUES (632, 167, '_article_excerpt', 'field_55f1e92e49b8f') ; 
INSERT INTO `wp_postmeta` VALUES (633, 167, 'article_categories', 'a:5:{i:0;s:2:"11";i:1;s:1:"9";i:2;s:1:"7";i:3;s:1:"5";i:4;s:1:"4";}') ; 
INSERT INTO `wp_postmeta` VALUES (634, 167, '_article_categories', 'field_55f1ece32ad0d') ; 
INSERT INTO `wp_postmeta` VALUES (635, 167, 'content', '') ; 
INSERT INTO `wp_postmeta` VALUES (636, 167, '_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (637, 167, '_edit_lock', '1442027370:1') ; 
INSERT INTO `wp_postmeta` VALUES (638, 113, '_wp_old_slug', 'example-class') ; 
INSERT INTO `wp_postmeta` VALUES (639, 169, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (640, 169, '_edit_lock', '1441937460:1') ; 
INSERT INTO `wp_postmeta` VALUES (641, 170, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (642, 170, '_edit_lock', '1441937473:1') ; 
INSERT INTO `wp_postmeta` VALUES (643, 171, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (644, 171, '_edit_lock', '1442006066:1') ; 
INSERT INTO `wp_postmeta` VALUES (645, 172, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (646, 172, '_edit_lock', '1442006111:1') ; 
INSERT INTO `wp_postmeta` VALUES (647, 173, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (648, 173, '_edit_lock', '1442006179:1') ; 
INSERT INTO `wp_postmeta` VALUES (649, 174, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (650, 174, 'testimonial_title', '') ; 
INSERT INTO `wp_postmeta` VALUES (651, 174, '_testimonial_title', 'field_55f1f31db6da0') ; 
INSERT INTO `wp_postmeta` VALUES (652, 174, 'testimonial_quote', 'Message.') ; 
INSERT INTO `wp_postmeta` VALUES (653, 174, '_testimonial_quote', 'field_55f1f2d0b6d9f') ; 
INSERT INTO `wp_postmeta` VALUES (654, 174, '_edit_lock', '1441937564:1') ; 
INSERT INTO `wp_postmeta` VALUES (655, 175, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (656, 175, '_edit_lock', '1441937588:1') ; 
INSERT INTO `wp_postmeta` VALUES (657, 175, 'testimonial_title', '') ; 
INSERT INTO `wp_postmeta` VALUES (658, 175, '_testimonial_title', 'field_55f1f31db6da0') ; 
INSERT INTO `wp_postmeta` VALUES (659, 175, 'testimonial_quote', 'Message.') ; 
INSERT INTO `wp_postmeta` VALUES (660, 175, '_testimonial_quote', 'field_55f1f2d0b6d9f') ; 
INSERT INTO `wp_postmeta` VALUES (742, 176, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (743, 176, '_edit_lock', '1441943130:1') ; 
INSERT INTO `wp_postmeta` VALUES (744, 177, '_wp_attached_file', 'home-hero.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (745, 177, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:900;s:6:"height";i:506;s:4:"file";s:13:"home-hero.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"home-hero-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"home-hero-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:1;}}') ; 
INSERT INTO `wp_postmeta` VALUES (746, 183, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (747, 183, '_edit_lock', '1442002370:1') ; 
INSERT INTO `wp_postmeta` VALUES (748, 186, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (749, 186, '_edit_lock', '1442005040:1') ; 
INSERT INTO `wp_postmeta` VALUES (750, 189, 'donate_content', '9ZERO7 Films Young Filmmakers Workshops are made possible through the generous support of individuals like you. Donations may be made by secure online transfer using the button below.') ; 
INSERT INTO `wp_postmeta` VALUES (751, 189, '_donate_content', 'field_55f33b3bb883b') ; 
INSERT INTO `wp_postmeta` VALUES (752, 189, 'donate_accepted_cards', 'a:4:{i:0;s:4:"Visa";i:1;s:10:"MasterCard";i:2;s:16:"American Express";i:3;s:8:"Discover";}') ; 
INSERT INTO `wp_postmeta` VALUES (753, 189, '_donate_accepted_cards', 'field_55f33b77b883c') ; 
INSERT INTO `wp_postmeta` VALUES (754, 83, 'donate_content', '9ZERO7 Films Young Filmmakers Workshops are made possible through the generous support of individuals like you. Donations may be made by secure online transfer using the button below.') ; 
INSERT INTO `wp_postmeta` VALUES (755, 83, '_donate_content', 'field_55f33b3bb883b') ; 
INSERT INTO `wp_postmeta` VALUES (756, 83, 'donate_accepted_cards', 'a:4:{i:0;s:4:"Visa";i:1;s:10:"MasterCard";i:2;s:16:"American Express";i:3;s:8:"Discover";}') ; 
INSERT INTO `wp_postmeta` VALUES (757, 83, '_donate_accepted_cards', 'field_55f33b77b883c') ; 
INSERT INTO `wp_postmeta` VALUES (758, 190, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (759, 190, '_edit_lock', '1442005214:1') ; 
INSERT INTO `wp_postmeta` VALUES (760, 192, 'contact_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pretium pretium tempor. Ut eget imperdiet neque. In volutpat ante semper diam molestie, et aliquam erat laoreet.') ; 
INSERT INTO `wp_postmeta` VALUES (761, 192, '_contact_content', 'field_55f340c5500ff') ; 
INSERT INTO `wp_postmeta` VALUES (762, 16, 'contact_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pretium pretium tempor. Ut eget imperdiet neque. In volutpat ante semper diam molestie, et aliquam erat laoreet.') ; 
INSERT INTO `wp_postmeta` VALUES (763, 16, '_contact_content', 'field_55f340c5500ff') ; 
INSERT INTO `wp_postmeta` VALUES (764, 194, 'sponsors_content', '9ZERO7 Films would like to thank the following organizations for their generous support. These supporters, in addition to our committed individual donors, make our work possible.') ; 
INSERT INTO `wp_postmeta` VALUES (765, 194, '_sponsors_content', 'field_55f3415b1542c') ; 
INSERT INTO `wp_postmeta` VALUES (766, 81, 'sponsors_content', '9ZERO7 Films would like to thank the following organizations for their generous support. These supporters, in addition to our committed individual donors, make our work possible.') ; 
INSERT INTO `wp_postmeta` VALUES (767, 81, '_sponsors_content', 'field_55f3415b1542c') ; 
INSERT INTO `wp_postmeta` VALUES (768, 171, 'faq_question', 'What is your teaching philosophy?') ; 
INSERT INTO `wp_postmeta` VALUES (769, 171, '_faq_question', 'field_55f343cf09257') ; 
INSERT INTO `wp_postmeta` VALUES (770, 171, 'faq_answer', 'Students will learn by doing. Rather than taking a chance that your child will lose interest by front-loading their experience with fundamentals and theory (which is certainly important) we get students making films as quickly as possible. Eventually they begin asking questions about the fundamentals and theory. When their curiosity has been piqued, they are much more receptive to learning.') ; 
INSERT INTO `wp_postmeta` VALUES (771, 171, '_faq_answer', 'field_55f343ea09258') ; 
INSERT INTO `wp_postmeta` VALUES (772, 172, 'faq_question', 'What is your teaching style?') ; 
INSERT INTO `wp_postmeta` VALUES (773, 172, '_faq_question', 'field_55f343cf09257') ; 
INSERT INTO `wp_postmeta` VALUES (774, 172, 'faq_answer', 'Children respond to learning in different ways. With filmmaking, it usually requires teaching in different styles depending on the content. As an example, when teaching lighting techniques, a demonstrator style of teaching would be used to show the student where to place lights. When writing scripts, the style would take on a more facilitator approach to spark the students creativity and get them writing on their own. When a professional project is brought in and the students have the opportunity to get some hands-on experience, a delegator style would be used.

All classes will have a fun laid-back feel. Actually it won\'t feel much like a class at all! Your child will be challenged to do things she or he has never tried and to venture outside their comfort zone, but always with a spirit of encouragement.') ; 
INSERT INTO `wp_postmeta` VALUES (775, 172, '_faq_answer', 'field_55f343ea09258') ; 
INSERT INTO `wp_postmeta` VALUES (776, 173, 'faq_question', 'Are there other benefits besides learning to making documentary films?') ; 
INSERT INTO `wp_postmeta` VALUES (777, 173, '_faq_question', 'field_55f343cf09257') ; 
INSERT INTO `wp_postmeta` VALUES (778, 173, 'faq_answer', 'Besides learning how to make documentary films, your child will:
<ul>
	<li>Begin to think about who they are and what they have to offer the world.</li>
	<li>They will thrive through self-expression.</li>
	<li>It will develop their creativity.</li>
	<li>They will learn how to work alongside others.</li>
</ul>') ; 
INSERT INTO `wp_postmeta` VALUES (779, 173, '_faq_answer', 'field_55f343ea09258') ; 
INSERT INTO `wp_postmeta` VALUES (781, 197, 'article_thumbnail', '') ; 
INSERT INTO `wp_postmeta` VALUES (782, 197, '_article_thumbnail', 'field_55f1eca1428f9') ; 
INSERT INTO `wp_postmeta` VALUES (783, 197, 'article_excerpt', 'Mauris non tempor quam, et lacinia sapien. Mauris accumsan eros eget li.') ; 
INSERT INTO `wp_postmeta` VALUES (784, 197, '_article_excerpt', 'field_55f1e92e49b8f') ; 
INSERT INTO `wp_postmeta` VALUES (785, 197, 'article_categories', 'a:5:{i:0;s:2:"11";i:1;s:1:"9";i:2;s:1:"7";i:3;s:1:"5";i:4;s:1:"4";}') ; 
INSERT INTO `wp_postmeta` VALUES (786, 197, '_article_categories', 'field_55f1ece32ad0d') ; 
INSERT INTO `wp_postmeta` VALUES (787, 197, 'content', '') ; 
INSERT INTO `wp_postmeta` VALUES (788, 197, '_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (790, 198, 'article_thumbnail', '') ; 
INSERT INTO `wp_postmeta` VALUES (791, 198, '_article_thumbnail', 'field_55f1eca1428f9') ; 
INSERT INTO `wp_postmeta` VALUES (792, 198, 'article_excerpt', 'Mauris non tempor quam, et lacinia sapien. Mauris accumsan eros eget li.') ; 
INSERT INTO `wp_postmeta` VALUES (793, 198, '_article_excerpt', 'field_55f1e92e49b8f') ; 
INSERT INTO `wp_postmeta` VALUES (794, 198, 'article_categories', 'a:5:{i:0;s:2:"11";i:1;s:1:"9";i:2;s:1:"7";i:3;s:1:"5";i:4;s:1:"4";}') ; 
INSERT INTO `wp_postmeta` VALUES (795, 198, '_article_categories', 'field_55f1ece32ad0d') ; 
INSERT INTO `wp_postmeta` VALUES (796, 198, 'content', '') ; 
INSERT INTO `wp_postmeta` VALUES (797, 198, '_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (799, 199, 'article_thumbnail', '138') ; 
INSERT INTO `wp_postmeta` VALUES (800, 199, '_article_thumbnail', 'field_55f1eca1428f9') ; 
INSERT INTO `wp_postmeta` VALUES (801, 199, 'article_excerpt', 'Mauris non tempor quam, et lacinia sapien. Mauris accumsan eros eget li.') ; 
INSERT INTO `wp_postmeta` VALUES (802, 199, '_article_excerpt', 'field_55f1e92e49b8f') ; 
INSERT INTO `wp_postmeta` VALUES (803, 199, 'article_categories', 'a:5:{i:0;s:2:"11";i:1;s:1:"9";i:2;s:1:"7";i:3;s:1:"5";i:4;s:1:"4";}') ; 
INSERT INTO `wp_postmeta` VALUES (804, 199, '_article_categories', 'field_55f1ece32ad0d') ; 
INSERT INTO `wp_postmeta` VALUES (805, 199, 'content', '') ; 
INSERT INTO `wp_postmeta` VALUES (806, 199, '_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (808, 200, 'article_thumbnail', '138') ; 
INSERT INTO `wp_postmeta` VALUES (809, 200, '_article_thumbnail', 'field_55f1eca1428f9') ; 
INSERT INTO `wp_postmeta` VALUES (810, 200, 'article_excerpt', 'Mauris non tempor quam, et lacinia sapien. Mauris accumsan eros eget li.') ; 
INSERT INTO `wp_postmeta` VALUES (811, 200, '_article_excerpt', 'field_55f1e92e49b8f') ; 
INSERT INTO `wp_postmeta` VALUES (812, 200, 'article_categories', 'a:5:{i:0;s:2:"11";i:1;s:1:"9";i:2;s:1:"7";i:3;s:1:"5";i:4;s:1:"4";}') ; 
INSERT INTO `wp_postmeta` VALUES (813, 200, '_article_categories', 'field_55f1ece32ad0d') ; 
INSERT INTO `wp_postmeta` VALUES (814, 200, 'article_content_0_article_text', 'Text block.') ; 
INSERT INTO `wp_postmeta` VALUES (815, 200, '_article_content_0_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (816, 200, 'article_content_1_article_image', '141') ; 
INSERT INTO `wp_postmeta` VALUES (817, 200, '_article_content_1_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (818, 200, 'article_content_1_article_image_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (819, 200, '_article_content_1_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (820, 200, 'article_content_2_article_text', 'Text') ; 
INSERT INTO `wp_postmeta` VALUES (821, 200, '_article_content_2_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (822, 200, 'article_content_3_article_image', '136') ; 
INSERT INTO `wp_postmeta` VALUES (823, 200, '_article_content_3_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (824, 200, 'article_content_3_article_image_alignment', 'Float Left') ; 
INSERT INTO `wp_postmeta` VALUES (825, 200, '_article_content_3_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (826, 200, 'article_content_4_article_image', '137') ; 
INSERT INTO `wp_postmeta` VALUES (827, 200, '_article_content_4_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (828, 200, 'article_content_4_article_image_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (829, 200, '_article_content_4_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (830, 200, 'article_content_5_article_video', 'https://www.youtube.com/watch?v=6FN1Y-Mbsr4') ; 
INSERT INTO `wp_postmeta` VALUES (831, 200, '_article_content_5_article_video', 'field_55f1eb8549b96') ; 
INSERT INTO `wp_postmeta` VALUES (832, 200, 'article_content_5_article_video_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (833, 200, '_article_content_5_article_video_alignment', 'field_55f1eba549b97') ; 
INSERT INTO `wp_postmeta` VALUES (834, 200, 'article_content_6_article_testimonial', 'a:1:{i:0;s:3:"174";}') ; 
INSERT INTO `wp_postmeta` VALUES (835, 200, '_article_content_6_article_testimonial', 'field_55f1ebf149b99') ; 
INSERT INTO `wp_postmeta` VALUES (836, 200, 'article_content', 'a:7:{i:0;s:18:"article_text_block";i:1;s:19:"article_image_block";i:2;s:18:"article_text_block";i:3;s:19:"article_image_block";i:4;s:19:"article_image_block";i:5;s:19:"article_video_block";i:6;s:25:"article_testimonial_block";}') ; 
INSERT INTO `wp_postmeta` VALUES (837, 200, '_article_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (838, 167, 'article_content_0_article_text', 'Text block.') ; 
INSERT INTO `wp_postmeta` VALUES (839, 167, '_article_content_0_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (840, 167, 'article_content_1_article_image', '141') ; 
INSERT INTO `wp_postmeta` VALUES (841, 167, '_article_content_1_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (842, 167, 'article_content_1_article_image_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (843, 167, '_article_content_1_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (844, 167, 'article_content_2_article_text', 'Text') ; 
INSERT INTO `wp_postmeta` VALUES (845, 167, '_article_content_2_article_text', 'field_55f1e9ef49b91') ; 
INSERT INTO `wp_postmeta` VALUES (846, 167, 'article_content_3_article_image', '136') ; 
INSERT INTO `wp_postmeta` VALUES (847, 167, '_article_content_3_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (848, 167, 'article_content_3_article_image_alignment', 'Float Left') ; 
INSERT INTO `wp_postmeta` VALUES (849, 167, '_article_content_3_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (850, 167, 'article_content_4_article_image', '137') ; 
INSERT INTO `wp_postmeta` VALUES (851, 167, '_article_content_4_article_image', 'field_55f1ea8149b93') ; 
INSERT INTO `wp_postmeta` VALUES (852, 167, 'article_content_4_article_image_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (853, 167, '_article_content_4_article_image_alignment', 'field_55f1ead349b94') ; 
INSERT INTO `wp_postmeta` VALUES (854, 167, 'article_content_5_article_video', 'https://www.youtube.com/watch?v=6FN1Y-Mbsr4') ; 
INSERT INTO `wp_postmeta` VALUES (855, 167, '_article_content_5_article_video', 'field_55f1eb8549b96') ; 
INSERT INTO `wp_postmeta` VALUES (856, 167, 'article_content_5_article_video_alignment', 'Full Width') ; 
INSERT INTO `wp_postmeta` VALUES (857, 167, '_article_content_5_article_video_alignment', 'field_55f1eba549b97') ; 
INSERT INTO `wp_postmeta` VALUES (858, 167, 'article_content_6_article_testimonial', 'a:1:{i:0;s:3:"174";}') ; 
INSERT INTO `wp_postmeta` VALUES (859, 167, '_article_content_6_article_testimonial', 'field_55f1ebf149b99') ; 
INSERT INTO `wp_postmeta` VALUES (860, 167, 'article_content', '') ; 
INSERT INTO `wp_postmeta` VALUES (861, 167, '_article_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (866, 203, 'article_content', '') ; 
INSERT INTO `wp_postmeta` VALUES (867, 203, '_article_content', 'field_55f1e9b549b90') ; 
INSERT INTO `wp_postmeta` VALUES (868, 203, 'article_excerpt', 'Mauris non tempor quam, et lacinia sapien. Mauris accumsan eros eget li.') ; 
INSERT INTO `wp_postmeta` VALUES (869, 203, '_article_excerpt', 'field_55f1e92e49b8f') ; 
INSERT INTO `wp_postmeta` VALUES (870, 203, 'article_categories', 'a:5:{i:0;s:2:"11";i:1;s:1:"9";i:2;s:1:"7";i:3;s:1:"5";i:4;s:1:"4";}') ; 
INSERT INTO `wp_postmeta` VALUES (871, 203, '_article_categories', 'field_55f1ece32ad0d') ; 
INSERT INTO `wp_postmeta` VALUES (872, 203, 'article_thumbnail', '138') ; 
INSERT INTO `wp_postmeta` VALUES (873, 203, '_article_thumbnail', 'field_55f1eca1428f9') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=204 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_posts (177 records)
#
 
INSERT INTO `wp_posts` VALUES (10, 1, '2014-01-17 09:59:53', '2014-01-17 09:59:53', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2014-01-18 08:15:15', '2014-01-18 08:15:15', '', 0, 'http://9zero7films.dev/?page_id=10', 1, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2014-01-17 09:59:53', '2014-01-17 09:59:53', '', 'Home', '', 'inherit', 'open', 'open', '', '10-revision-v1', '', '', '2014-01-17 09:59:53', '2014-01-17 09:59:53', '', 10, 'http://9zero7films.dev/2014/01/10-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2014-01-17 10:00:06', '2014-01-17 10:00:06', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In adipiscing hendrerit risus vitae tincidunt. Morbi vel ultrices nisi. Etiam quis malesuada nunc. Vivamus in elit et nisi sagittis feugiat. Quisque dictum sapien nec quam consectetur, id ullamcorper arcu consequat. Nulla a ipsum non leo elementum consequat in eu erat. Curabitur ornare risus sed arcu vulputate, id elementum nibh tincidunt. Suspendisse potenti. Praesent lobortis nisi pellentesque lacus pellentesque sagittis. Quisque non imperdiet libero. Nullam bibendum purus at tellus molestie, eget pretium neque vestibulum. Aliquam aliquam varius fermentum.

Phasellus sed lectus mauris. Morbi nec lacinia nunc. Nulla at massa varius, consectetur libero dignissim, vehicula lacus. Mauris dignissim aliquet enim, quis imperdiet orci faucibus a. Phasellus quis tellus eu dui dictum suscipit. Donec venenatis, sem vitae auctor consequat, leo enim consectetur felis, ut mattis nisl dolor sed odio. Quisque tempus odio a aliquet ornare.

Donec feugiat orci eget molestie tristique. Nam suscipit orci vel elit tristique pulvinar. Duis dignissim urna eget erat feugiat commodo id non tellus. Proin ac diam egestas, pellentesque lorem non, vulputate dolor. Suspendisse elit felis, interdum cursus iaculis nec, pellentesque a nibh. Suspendisse blandit quam et nunc venenatis, id tincidunt lorem ornare. Donec pharetra felis nulla, id dignissim tellus feugiat eget. Praesent rutrum nisl a adipiscing elementum. Donec erat nulla, condimentum sed eros non, rutrum egestas orci.', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2014-01-18 08:15:12', '2014-01-18 08:15:12', '', 0, 'http://9zero7films.dev/?page_id=12', 2, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2014-01-17 10:00:06', '2014-01-17 10:00:06', '', 'About', '', 'inherit', 'open', 'open', '', '12-revision-v1', '', '', '2014-01-17 10:00:06', '2014-01-17 10:00:06', '', 12, 'http://9zero7films.dev/2014/01/12-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2014-01-17 10:00:15', '2014-01-17 10:00:15', '', 'News', '', 'publish', 'closed', 'closed', '', 'news', '', '', '2015-09-07 02:29:35', '2015-09-07 02:29:35', '', 0, 'http://9zero7films.dev/?page_id=14', 4, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (15, 1, '2014-01-17 10:00:15', '2014-01-17 10:00:15', '', 'News', '', 'inherit', 'open', 'open', '', '14-revision-v1', '', '', '2014-01-17 10:00:15', '2014-01-17 10:00:15', '', 14, 'http://9zero7films.dev/2014/01/14-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (16, 1, '2014-01-17 10:00:25', '2014-01-17 10:00:25', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In adipiscing hendrerit risus vitae tincidunt. Morbi vel ultrices nisi. Etiam quis malesuada nunc. Vivamus in elit et nisi sagittis feugiat. Quisque dictum sapien nec quam consectetur, id ullamcorper arcu consequat. Nulla a ipsum non leo elementum consequat in eu erat. Curabitur ornare risus sed arcu vulputate, id elementum nibh tincidunt. Suspendisse potenti. Praesent lobortis nisi pellentesque lacus pellentesque sagittis. Quisque non imperdiet libero. Nullam bibendum purus at tellus molestie, eget pretium neque vestibulum. Aliquam aliquam varius fermentum.', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2015-09-11 21:00:39', '2015-09-11 21:00:39', '', 0, 'http://9zero7films.dev/?page_id=16', 8, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (17, 1, '2014-01-17 10:00:25', '2014-01-17 10:00:25', '', 'Contact', '', 'inherit', 'open', 'open', '', '16-revision-v1', '', '', '2014-01-17 10:00:25', '2014-01-17 10:00:25', '', 16, 'http://9zero7films.dev/2014/01/16-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (20, 1, '2014-01-17 10:00:52', '2014-01-17 10:00:52', ' ', '', '', 'publish', 'open', 'closed', '', '20', '', '', '2015-09-11 20:14:00', '2015-09-11 20:14:00', '', 0, 'http://9zero7films.dev/?p=20', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (21, 1, '2014-01-17 10:00:52', '2014-01-17 10:00:52', ' ', '', '', 'publish', 'open', 'closed', '', '21', '', '', '2015-09-11 20:14:00', '2015-09-11 20:14:00', '', 0, 'http://9zero7films.dev/?p=21', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (22, 1, '2014-01-17 10:00:52', '2014-01-17 10:00:52', ' ', '', '', 'publish', 'open', 'closed', '', '22', '', '', '2015-09-11 20:14:00', '2015-09-11 20:14:00', '', 0, 'http://9zero7films.dev/?p=22', 6, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (24, 1, '2015-08-01 10:02:35', '2015-08-01 10:02:35', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam feugiat lorem at justo pellentesque, ac molestie nisi scelerisque. <a href="http://9zero7films.dev/">http://9zero7films.dev/</a> malesuada eu sapien. Maecenas id pulvinar sapien, sit amet porttitor enim. Pellentesque augue ligula, dapibus id interdum at, tempor ut diam. Aenean elit sapien, vestibulum egestas lorem vitae, ultricies finibus neque.
<ol>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ol>
Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam aliquet, dui vitae eleifend commodo, odio lectus euismod purus, at suscipit urna dui vel urna.
<h2>Sed eget sagittis ex, quis fermentum nibh pellentesque eleifend lectus id lacinia venenatis.</h2>
Suspendisse egestas nisi et fermentum luctus. Mauris sit amet nunc at sem auctor aliquam at a orci. Etiam vel nisi ultricies urna placerat faucibus at vitae diam. Duis sed cursus diam. Maecenas non tempus erat. Sed ut semper ante. <strong>Proin dignissim, est vitae ullamcorper blandit</strong>, erat nulla laoreet erat, quis euismod nulla augue vel velit.

Sed rutrum nibh ut viverra semper. Quisque lobortis ultricies facilisis. Nulla mauris neque, luctus sed sapien vitae, imperdiet laoreet lacus. Vivamus ex lectus, porta a velit a, ullamcorper auctor massa. Aenean vulputate erat at congue efficitur. Nullam varius egestas ex. <em>Fusce imperdiet tellus et luctus suscipit</em>. Nulla ut dui a massa mollis tincidunt. Pellentesque eu sem eu purus pellentesque feugiat non quis est. Nulla pretium, eros et faucibus molestie, nisi justo faucibus lacus, et venenatis ex augue nec nunc. Nunc id nunc massa.
<ul>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ul>
Nulla venenatis condimentum est, sed efficitur purus congue id. Vivamus a malesuada augue. Donec consequat interdum nisi nec laoreet. Morbi ultrices varius dui, vitae pulvinar nibh ornare sed. Donec semper gravida neque scelerisque bibendum. In eu rutrum mi. Quisque luctus tellus ut sem maximus vehicula. Nunc vel varius nisi, vitae venenatis erat. Cras mollis interdum enim, ac pretium ligula feugiat eu. In sed lectus ut ipsum euismod sodales eget sed augue.
<h3>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h3>
Ut mattis non enim quis pretium. Suspendisse blandit mollis libero sit amet commodo. Quisque sagittis iaculis risus congue rhoncus. Mauris fermentum elit sit amet nunc ullamcorper, non iaculis eros suscipit. Ut facilisis accumsan nunc. Vivamus finibus ut erat ut mollis. Quisque sed lacus enim. Nulla facilisi. Suspendisse non faucibus neque. Quisque lacus elit, sodales a laoreet sollicitudin, elementum sit amet tellus. Quisque metus lorem, ornare non aliquam sit amet, gravida et est. Maecenas quis malesuada ante. Mauris ac neque sit amet justo varius pulvinar quis et enim. Proin aliquet eget enim non ornare. Suspendisse cursus risus nec enim suscipit commodo ac a ligula.

Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean congue erat in mauris viverra eleifend in eget nunc. Aliquam orci erat, blandit quis lorem quis, pellentesque placerat justo. Sed arcu nunc, lacinia quis magna vel, tempor tempus urna. In sit amet mi dapibus, consectetur lorem ac, aliquet metus. Morbi faucibus vitae purus sit amet varius.

Etiam ut tincidunt sapien, eu gravida enim vivamus congue leo tellus, id pellentesque justo finibus at. Maecenas rhoncus magna eget quam bibendum, ut iaculis massa facilisis. Sed sed condimentum tortor, eget tristique mauris. Morbi eu imperdiet nunc. In interdum non ipsum sit amet molestie. Aenean vel eros ornare, ornare elit et, tincidunt quam. Sed ac erat et nulla aliquam euismod eget eget quam. Quisque eget quam ligula. Suspendisse euismod dui vitae euismod tincidunt. Morbi accumsan purus sit amet mattis laoreet.

Suspendisse vitae nibh elementum sapien cursus hendrerit. Mauris varius tortor maximus, gravida lorem nec, commodo massa. Pellentesque malesuada erat quis lacus aliquet lacinia. Quisque vel est a augue porta scelerisque vitae vel risus. Pellentesque nec nisl luctus, dapibus orci a, ornare est.
<blockquote>Duis finibus, ante eu laoreet pulvinar, mauris nulla vulputate neque, nec lacinia mauris est in ipsum. Proin vestibulum blandit odio a pharetra. Pellentesque sed nulla ut arcu vestibulum facilisis. Ut vitae congue risus. Quisque mattis leo non ornare viverra. Aliquam eget massa neque. Cras nec placerat magna.</blockquote>
Duis eu pellentesque neque, non ullamcorper lectus. Etiam ut tellus congue turpis bibendum accumsan. Etiam non condimentum neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean tempus ipsum purus, vel consequat sapien feugiat ac. Maecenas vestibulum est vel arcu vestibulum, a tempor nulla maximus. Vivamus hendrerit dolor consequat dignissim dignissim.

Maecenas eu fringilla nisl, nec hendrerit est. Maecenas quis nibh eget ipsum bibendum facilisis. Proin dapibus diam eget rhoncus efficitur. Duis mollis ante at bibendum pharetra. Praesent ultricies mollis accumsan. Nunc feugiat quis velit eget commodo. Praesent ultricies iaculis erat, nec fermentum est pharetra non. Nulla facilisi. Sed sollicitudin mauris ac magna scelerisque vulputate. Etiam sit amet nisi vel eros finibus sodales. Nullam egestas fringilla eros a aliquet. Mauris et mollis erat, in eleifend turpis.

Vivamus sit amet neque ut arcu maximus gravida. Mauris sodales quam vel finibus auctor. Vestibulum eget nulla turpis. Cras eros augue, semper nec malesuada vel, elementum sed sem. Aenean ac maximus ex, mattis dictum enim. Sed ultrices leo in tellus iaculis imperdiet. Morbi auctor arcu nec elit interdum dapibus. Integer sed leo odio. Aliquam nec ultricies risus, vel porta lectus. Sed accumsan placerat leo, at aliquam felis rhoncus aliquam. Curabitur in sodales massa. Aenean dui est, commodo ac venenatis et, aliquam eu neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse interdum enim quis volutpat sollicitudin. Morbi bibendum est non egestas rhoncus. Cras tempor sagittis nibh sit amet pharetra.

Quisque sagittis, libero in sagittis imperdiet, magna felis tincidunt erat, sit amet sagittis libero risus sed diam. Etiam vestibulum non purus in gravida. Nulla facilisi. Nunc lectus purus, gravida quis ligula vehicula, pulvinar venenatis nibh. Aenean hendrerit eleifend lacus, vel ultrices nisi ultricies eget. Mauris neque quam, laoreet varius maximus id, auctor sit amet ante. Maecenas sed felis sit amet risus varius rutrum nec eu enim. Ut commodo sollicitudin purus ut auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras volutpat tristique neque sit amet pulvinar. Cras sed sem ac dolor ornare sagittis. Morbi augue augue, gravida vitae mi sit amet, ornare tempor libero. Donec sagittis fermentum magna eget aliquam. Etiam fermentum mi a lacinia varius.

Morbi venenatis velit non interdum bibendum. Phasellus iaculis ornare elementum. Vivamus ac imperdiet ligula, eget ultrices diam. Vivamus sed tincidunt turpis. Integer eu auctor eros. Nullam finibus laoreet venenatis. Nunc ac sem cursus, faucibus sem a, aliquam turpis. Praesent bibendum magna vitae pulvinar fermentum. Mauris at sollicitudin orci, sed tempus leo. Fusce quis magna tristique, eleifend metus sed, sodales sapien. Suspendisse sit amet massa consequat nulla lacinia sagittis.

In ullamcorper ac eros eu efficitur. Donec a orci orci. Suspendisse egestas lacus in risus feugiat, eget maximus mauris condimentum. Duis ut ante et diam feugiat tincidunt. Morbi nec velit vitae sapien elementum sagittis. Fusce sed luctus massa, quis mollis dolor. Suspendisse facilisis orci et maximus feugiat. Sed quis congue erat. Cras porta efficitur magna, dictum sagittis urna laoreet semper. Etiam ac nunc orci.
<h6>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.</h6>
Vestibulum eget pretium elit. Pellentesque nec tempor augue. In velit ipsum, porttitor et vulputate et, sollicitudin ac mi. Aliquam placerat non magna quis auctor. Sed sagittis nisi vitae lectus semper, id semper quam consequat. Nulla posuere, ex in iaculis ultricies, nulla libero sollicitudin dui, ut tristique orci leo ut tortor. Fusce laoreet tincidunt lacus id posuere. Donec et metus sit amet diam lobortis aliquet. Aenean eget vestibulum mauris. Sed id est lacus. Aenean sed congue diam. Nullam pretium dictum elit non tempus. Suspendisse potenti. Pellentesque mattis lorem vitae dolor porttitor, vitae condimentum magna vulputate. Pellentesque bibendum lorem ut lorem dictum, ut venenatis orci tempus.

Aliquam id augue lobortis, pellentesque leo sit amet, bibendum est. Morbi quis ex nec eros efficitur imperdiet vitae id dolor. Pellentesque et lectus vitae augue pretium lobortis. Fusce ante orci, rutrum non ultrices sit amet, pellentesque vitae lacus. Proin at mattis risus. Suspendisse sem magna, ultrices at lectus at, laoreet lobortis tortor. Fusce viverra vestibulum dui id ultrices. Suspendisse eu rhoncus massa, eget sodales elit. Proin gravida dolor at sapien congue, sed vehicula nisi rutrum.', 'Article One', '', 'publish', 'closed', 'closed', '', 'article-one', '', '', '2015-09-11 02:45:21', '2015-09-11 02:45:21', '', 0, 'http://9zero7films.dev/?p=24', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (25, 1, '2014-01-17 10:02:35', '2014-01-17 10:02:35', '', 'Article One', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2014-01-17 10:02:35', '2014-01-17 10:02:35', '', 24, 'http://9zero7films.dev/2014/01/24-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (26, 1, '2015-08-02 10:02:45', '2015-08-02 10:02:45', '', 'Article Two', '', 'publish', 'closed', 'closed', '', 'article-two', '', '', '2015-09-11 02:45:13', '2015-09-11 02:45:13', '', 0, 'http://9zero7films.dev/?p=26', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (27, 1, '2014-01-17 10:02:45', '2014-01-17 10:02:45', '', 'Article Two', '', 'inherit', 'open', 'open', '', '26-revision-v1', '', '', '2014-01-17 10:02:45', '2014-01-17 10:02:45', '', 26, 'http://9zero7films.dev/2014/01/26-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (28, 1, '2015-08-03 10:02:55', '2015-08-03 10:02:55', '', 'Article Three', '', 'publish', 'closed', 'closed', '', 'article-three', '', '', '2015-09-11 02:45:06', '2015-09-11 02:45:06', '', 0, 'http://9zero7films.dev/?p=28', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (29, 1, '2014-01-17 10:02:55', '2014-01-17 10:02:55', '', 'Article Three', '', 'inherit', 'open', 'open', '', '28-revision-v1', '', '', '2014-01-17 10:02:55', '2014-01-17 10:02:55', '', 28, 'http://9zero7films.dev/2014/01/28-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (30, 1, '2015-08-04 10:03:04', '2015-08-04 10:03:04', '', 'Article Four', '', 'publish', 'closed', 'closed', '', 'article-four', '', '', '2015-09-11 02:45:00', '2015-09-11 02:45:00', '', 0, 'http://9zero7films.dev/?p=30', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2014-01-17 10:03:04', '2014-01-17 10:03:04', '', 'Article Four', '', 'inherit', 'open', 'open', '', '30-revision-v1', '', '', '2014-01-17 10:03:04', '2014-01-17 10:03:04', '', 30, 'http://9zero7films.dev/2014/01/30-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (32, 1, '2015-08-05 10:03:13', '2015-08-05 10:03:13', '', 'Article Five', '', 'publish', 'closed', 'closed', '', 'article-five', '', '', '2015-09-11 02:44:54', '2015-09-11 02:44:54', '', 0, 'http://9zero7films.dev/?p=32', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (33, 1, '2014-01-17 10:03:13', '2014-01-17 10:03:13', '', 'Article Five', '', 'inherit', 'open', 'open', '', '32-revision-v1', '', '', '2014-01-17 10:03:13', '2014-01-17 10:03:13', '', 32, 'http://9zero7films.dev/2014/01/32-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (34, 1, '2015-08-06 10:03:21', '2015-08-06 10:03:21', '', 'Article Six', '', 'publish', 'closed', 'closed', '', 'article-six', '', '', '2015-09-11 02:44:47', '2015-09-11 02:44:47', '', 0, 'http://9zero7films.dev/?p=34', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (35, 1, '2014-01-17 10:03:21', '2014-01-17 10:03:21', '', 'Article Six', '', 'inherit', 'open', 'open', '', '34-revision-v1', '', '', '2014-01-17 10:03:21', '2014-01-17 10:03:21', '', 34, 'http://9zero7films.dev/2014/01/34-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (36, 1, '2015-08-07 10:03:31', '2015-08-07 10:03:31', '', 'Article Seven', '', 'publish', 'closed', 'closed', '', 'article-seven', '', '', '2015-09-11 02:44:40', '2015-09-11 02:44:40', '', 0, 'http://9zero7films.dev/?p=36', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (37, 1, '2014-01-17 10:03:31', '2014-01-17 10:03:31', '', 'Article Seven', '', 'inherit', 'open', 'open', '', '36-revision-v1', '', '', '2014-01-17 10:03:31', '2014-01-17 10:03:31', '', 36, 'http://9zero7films.dev/2014/01/36-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (38, 1, '2015-08-08 10:03:40', '2015-08-08 10:03:40', '', 'Article Eight', '', 'publish', 'closed', 'closed', '', 'article-eight', '', '', '2015-09-11 02:44:35', '2015-09-11 02:44:35', '', 0, 'http://9zero7films.dev/?p=38', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (39, 1, '2014-01-17 10:03:40', '2014-01-17 10:03:40', '', 'Article Eight', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2014-01-17 10:03:40', '2014-01-17 10:03:40', '', 38, 'http://9zero7films.dev/2014/01/38-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (40, 1, '2015-08-09 10:03:49', '2015-08-09 10:03:49', '', 'Article Nine', '', 'publish', 'closed', 'closed', '', 'article-nine', '', '', '2015-09-11 02:44:29', '2015-09-11 02:44:29', '', 0, 'http://9zero7films.dev/?p=40', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (41, 1, '2014-01-17 10:03:49', '2014-01-17 10:03:49', '', 'Article Nine', '', 'inherit', 'open', 'open', '', '40-revision-v1', '', '', '2014-01-17 10:03:49', '2014-01-17 10:03:49', '', 40, 'http://9zero7films.dev/2014/01/40-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (42, 1, '2015-08-10 10:03:57', '2015-08-10 10:03:57', '', 'Article Ten', '', 'publish', 'closed', 'closed', '', 'article-ten', '', '', '2015-09-11 02:44:23', '2015-09-11 02:44:23', '', 0, 'http://9zero7films.dev/?p=42', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (43, 1, '2014-01-17 10:03:57', '2014-01-17 10:03:57', '', 'Article Ten', '', 'inherit', 'open', 'open', '', '42-revision-v1', '', '', '2014-01-17 10:03:57', '2014-01-17 10:03:57', '', 42, 'http://9zero7films.dev/2014/01/42-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (44, 1, '2015-08-11 10:04:07', '2015-08-11 10:04:07', '', 'Article Eleven', '', 'publish', 'closed', 'closed', '', 'article-eleven', '', '', '2015-09-11 02:44:16', '2015-09-11 02:44:16', '', 0, 'http://9zero7films.dev/?p=44', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (45, 1, '2014-01-17 10:04:07', '2014-01-17 10:04:07', '', 'Article Eleven', '', 'inherit', 'open', 'open', '', '44-revision-v1', '', '', '2014-01-17 10:04:07', '2014-01-17 10:04:07', '', 44, 'http://9zero7films.dev/2014/01/44-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (46, 1, '2015-08-12 10:04:16', '2015-08-12 10:04:16', '', 'Article Twelve', '', 'publish', 'closed', 'closed', '', 'article-twelve', '', '', '2015-09-11 02:44:09', '2015-09-11 02:44:09', '', 0, 'http://9zero7films.dev/?p=46', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (47, 1, '2014-01-17 10:04:16', '2014-01-17 10:04:16', '', 'Article Twelve', '', 'inherit', 'open', 'open', '', '46-revision-v1', '', '', '2014-01-17 10:04:16', '2014-01-17 10:04:16', '', 46, 'http://9zero7films.dev/2014/01/46-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (49, 1, '2014-01-17 10:16:50', '2014-01-17 10:16:50', '', 'Contact Info', '', 'publish', 'closed', 'closed', '', 'acf_contact-info', '', '', '2014-01-31 06:20:28', '2014-01-31 06:20:28', '', 0, 'http://9zero7films.dev/?post_type=acf&#038;p=49', 1, 'acf', '', 0) ; 
INSERT INTO `wp_posts` VALUES (50, 1, '2014-01-17 10:17:05', '2014-01-17 10:17:05', '', 'Social Media', '', 'publish', 'closed', 'closed', '', 'acf_social-media', '', '', '2014-01-17 10:24:23', '2014-01-17 10:24:23', '', 0, 'http://9zero7films.dev/?post_type=acf&#038;p=50', 1, 'acf', '', 0) ; 
INSERT INTO `wp_posts` VALUES (51, 1, '2014-01-17 10:17:18', '2014-01-17 10:17:18', '', 'Google Tools', '', 'publish', 'closed', 'closed', '', 'acf_google-tools', '', '', '2014-01-31 06:21:49', '2014-01-31 06:21:49', '', 0, 'http://9zero7films.dev/?post_type=acf&#038;p=51', 1, 'acf', '', 0) ; 
INSERT INTO `wp_posts` VALUES (52, 1, '2014-01-18 06:00:24', '2014-01-18 06:00:24', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In adipiscing hendrerit risus vitae tincidunt. Morbi vel ultrices nisi. Etiam quis malesuada nunc. Vivamus in elit et nisi sagittis feugiat. Quisque dictum sapien nec quam consectetur, id ullamcorper arcu consequat. Nulla a ipsum non leo elementum consequat in eu erat. Curabitur ornare risus sed arcu vulputate, id elementum nibh tincidunt. Suspendisse potenti. Praesent lobortis nisi pellentesque lacus pellentesque sagittis. Quisque non imperdiet libero. Nullam bibendum purus at tellus molestie, eget pretium neque vestibulum. Aliquam aliquam varius fermentum.

Phasellus sed lectus mauris. Morbi nec lacinia nunc. Nulla at massa varius, consectetur libero dignissim, vehicula lacus. Mauris dignissim aliquet enim, quis imperdiet orci faucibus a. Phasellus quis tellus eu dui dictum suscipit. Donec venenatis, sem vitae auctor consequat, leo enim consectetur felis, ut mattis nisl dolor sed odio. Quisque tempus odio a aliquet ornare.

Donec feugiat orci eget molestie tristique. Nam suscipit orci vel elit tristique pulvinar. Duis dignissim urna eget erat feugiat commodo id non tellus. Proin ac diam egestas, pellentesque lorem non, vulputate dolor. Suspendisse elit felis, interdum cursus iaculis nec, pellentesque a nibh. Suspendisse blandit quam et nunc venenatis, id tincidunt lorem ornare. Donec pharetra felis nulla, id dignissim tellus feugiat eget. Praesent rutrum nisl a adipiscing elementum. Donec erat nulla, condimentum sed eros non, rutrum egestas orci.', 'About', '', 'inherit', 'open', 'open', '', '12-revision-v1', '', '', '2014-01-18 06:00:24', '2014-01-18 06:00:24', '', 12, 'http://9zero7films.dev/2014/01/12-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (53, 1, '2014-01-18 06:01:42', '2014-01-18 06:01:42', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In adipiscing hendrerit risus vitae tincidunt. Morbi vel ultrices nisi. Etiam quis malesuada nunc. Vivamus in elit et nisi sagittis feugiat. Quisque dictum sapien nec quam consectetur, id ullamcorper arcu consequat. Nulla a ipsum non leo elementum consequat in eu erat. Curabitur ornare risus sed arcu vulputate, id elementum nibh tincidunt. Suspendisse potenti. Praesent lobortis nisi pellentesque lacus pellentesque sagittis. Quisque non imperdiet libero. Nullam bibendum purus at tellus molestie, eget pretium neque vestibulum. Aliquam aliquam varius fermentum.', 'Contact', '', 'inherit', 'open', 'open', '', '16-revision-v1', '', '', '2014-01-18 06:01:42', '2014-01-18 06:01:42', '', 16, 'http://9zero7films.dev/2014/01/16-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (56, 1, '2014-01-31 06:25:30', '2014-01-31 06:25:30', '', 'Article', '', 'publish', 'closed', 'closed', '', 'acf_article', '', '', '2014-01-31 06:25:30', '2014-01-31 06:25:30', '', 0, 'http://9zero7films.dev/?post_type=acf&#038;p=56', 1, 'acf', '', 0) ; 
INSERT INTO `wp_posts` VALUES (60, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:4:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:10:"categories";i:3;s:4:"tags";}s:11:"description";s:0:"";}', 'Article', 'article', 'publish', 'closed', 'closed', '', 'group_53bc19ac2f0b4', '', '', '2015-09-12 03:00:06', '2015-09-12 03:00:06', '', 0, 'http://9zero7films.dev/?post_type=acf-field-group&#038;p=60', 1, 'acf-field-group', '', 0) ; 
INSERT INTO `wp_posts` VALUES (62, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:31:"acf-options-contact-information";}}}s:8:"position";s:6:"normal";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Contact Information', 'contact-information', 'publish', 'closed', 'closed', '', 'group_53bc19ac3f464', '', '', '2015-09-11 19:46:12', '2015-09-11 19:46:12', '', 0, 'http://9zero7films.dev/?post_type=acf-field-group&#038;p=62', 1, 'acf-field-group', '', 0) ; 
INSERT INTO `wp_posts` VALUES (63, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Street', 'contact_street', 'publish', 'open', 'open', '', 'field_52eb3ffd2a2f5', '', '', '2015-09-11 19:43:04', '2015-09-11 19:43:04', '', 62, 'http://9zero7films.dev/?post_type=acf-field&#038;p=63', 1, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (64, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";i:0;s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'City', 'contact_city', 'publish', 'open', 'open', '', 'field_52eb40202a2f6', '', '', '2015-09-07 08:01:12', '2015-09-07 08:01:12', '', 62, 'http://9zero7films.dev/?post_type=acf-field&#038;p=64', 3, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (65, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:14:{s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:51:{s:7:"Alabama";s:7:"Alabama";s:6:"Alaska";s:6:"Alaska";s:7:"Arizona";s:7:"Arizona";s:8:"Arkansas";s:8:"Arkansas";s:10:"California";s:10:"California";s:8:"Colorado";s:8:"Colorado";s:11:"Connecticut";s:11:"Connecticut";s:8:"Delaware";s:8:"Delaware";s:4:"D.C.";s:20:"District Of Columbia";s:7:"Florida";s:7:"Florida";s:7:"Georgia";s:7:"Georgia";s:6:"Hawaii";s:6:"Hawaii";s:5:"Idaho";s:5:"Idaho";s:8:"Illinois";s:8:"Illinois";s:7:"Indiana";s:7:"Indiana";s:4:"Iowa";s:4:"Iowa";s:6:"Kansas";s:6:"Kansas";s:8:"Kentucky";s:8:"Kentucky";s:9:"Louisiana";s:9:"Louisiana";s:5:"Maine";s:5:"Maine";s:8:"Maryland";s:8:"Maryland";s:13:"Massachusetts";s:13:"Massachusetts";s:8:"Michigan";s:8:"Michigan";s:9:"Minnesota";s:9:"Minnesota";s:11:"Mississippi";s:11:"Mississippi";s:8:"Missouri";s:8:"Missouri";s:7:"Montana";s:7:"Montana";s:8:"Nebraska";s:8:"Nebraska";s:6:"Nevada";s:6:"Nevada";s:13:"New Hampshire";s:13:"New Hampshire";s:10:"New Jersey";s:10:"New Jersey";s:10:"New Mexico";s:10:"New Mexico";s:8:"New York";s:8:"New York";s:14:"North Carolina";s:14:"North Carolina";s:12:"North Dakota";s:12:"North Dakota";s:4:"Ohio";s:4:"Ohio";s:8:"Oklahoma";s:8:"Oklahoma";s:6:"Oregon";s:6:"Oregon";s:12:"Pennsylvania";s:12:"Pennsylvania";s:12:"Rhode Island";s:12:"Rhode Island";s:14:"South Carolina";s:14:"South Carolina";s:12:"South Dakota";s:12:"South Dakota";s:9:"Tennessee";s:9:"Tennessee";s:5:"Texas";s:5:"Texas";s:4:"Utah";s:4:"Utah";s:7:"Vermont";s:7:"Vermont";s:8:"Virginia";s:8:"Virginia";s:10:"Washington";s:10:"Washington";s:13:"West Virginia";s:13:"West Virginia";s:9:"Wisconsin";s:9:"Wisconsin";s:7:"Wyoming";s:7:"Wyoming";}s:13:"default_value";a:0:{}s:10:"allow_null";i:0;s:8:"multiple";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:11:"placeholder";s:0:"";s:8:"disabled";i:0;s:8:"readonly";i:0;}', 'State', 'contact_state', 'publish', 'open', 'open', '', 'field_52eb402a2a2f7', '', '', '2015-09-11 19:46:12', '2015-09-11 19:46:12', '', 62, 'http://9zero7films.dev/?post_type=acf-field&#038;p=65', 4, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (66, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";i:0;s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Zipcode', 'contact_zipcode', 'publish', 'open', 'open', '', 'field_52eb406f2a2f8', '', '', '2015-09-07 08:01:12', '2015-09-07 08:01:12', '', 62, 'http://9zero7films.dev/?post_type=acf-field&#038;p=66', 5, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (67, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";i:0;s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Phone', 'contact_phone', 'publish', 'open', 'open', '', 'field_52eb40812a2f9', '', '', '2015-09-07 08:01:12', '2015-09-07 08:01:12', '', 62, 'http://9zero7films.dev/?post_type=acf-field&#038;p=67', 6, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (68, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:9:{s:4:"type";s:5:"email";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Email', 'contact_email', 'publish', 'open', 'open', '', 'field_52eb40902a2fa', '', '', '2015-09-07 08:01:12', '2015-09-07 08:01:12', '', 62, 'http://9zero7films.dev/?post_type=acf-field&#038;p=68', 7, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (69, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:6:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:24:"acf-options-google-tools";}}}s:8:"position";s:6:"normal";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";}', 'Google Tools', 'google-tools', 'publish', 'closed', 'closed', '', 'group_53bc19ac54554', '', '', '2014-07-08 16:37:34', '2014-07-08 16:37:34', '', 0, 'http://9zero7films.dev/?post_type=acf-field-group&#038;p=69', 1, 'acf-field-group', '', 0) ; 
INSERT INTO `wp_posts` VALUES (70, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:67:"Add instructions here that better describes what this field offers.";s:8:"required";i:0;s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";i:0;s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Site Verification', 'google_site_verification', 'publish', 'open', 'open', '', 'field_52d9034a109e5', '', '', '2014-07-08 16:17:48', '2014-07-08 16:17:48', '', 69, 'http://9zero7films.dev/?post_type=acf-field&p=70', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (71, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:67:"Add instructions here that better describes what this field offers.";s:8:"required";i:0;s:13:"default_value";s:0:"";s:11:"placeholder";s:12:"UA-XXXXXX-XX";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";i:0;s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Analytics', 'google_analytics', 'publish', 'open', 'open', '', 'field_52d90387109e6', '', '', '2014-07-08 16:17:48', '2014-07-08 16:17:48', '', 69, 'http://9zero7films.dev/?post_type=acf-field&p=71', 1, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (72, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:24:"acf-options-social-media";}}}s:8:"position";s:6:"normal";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Social Media', 'social-media', 'publish', 'closed', 'closed', '', 'group_53bc19ac5d293', '', '', '2015-09-11 19:56:47', '2015-09-11 19:56:47', '', 0, 'http://9zero7films.dev/?post_type=acf-field-group&#038;p=72', 1, 'acf-field-group', '', 0) ; 
INSERT INTO `wp_posts` VALUES (73, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Twitter', 'social_twitter', 'publish', 'open', 'open', '', 'field_52d9041a331f8', '', '', '2015-09-11 19:56:47', '2015-09-11 19:56:47', '', 72, 'http://9zero7films.dev/?post_type=acf-field&#038;p=73', 1, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (74, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Facebook', 'social_facebook', 'publish', 'open', 'open', '', 'field_52d9042c331f9', '', '', '2015-09-11 19:56:47', '2015-09-11 19:56:47', '', 72, 'http://9zero7films.dev/?post_type=acf-field&#038;p=74', 2, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (75, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Instagram', 'social_instagram', 'publish', 'open', 'open', '', 'field_52d9044e331fa', '', '', '2015-09-11 19:56:47', '2015-09-11 19:56:47', '', 72, 'http://9zero7films.dev/?post_type=acf-field&#038;p=75', 4, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (76, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Google Plus', 'social_google_plus', 'publish', 'open', 'open', '', 'field_52d90475331fc', '', '', '2015-09-11 19:56:47', '2015-09-11 19:56:47', '', 72, 'http://9zero7films.dev/?post_type=acf-field&#038;p=76', 3, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (77, 1, '2014-07-08 16:17:48', '2014-07-08 16:17:48', 'a:5:{s:4:"type";s:7:"message";s:12:"instructions";s:0:"";s:8:"required";i:0;s:7:"message";s:67:"Add instructions here that better describes what this field offers.";s:17:"conditional_logic";i:0;}', 'Instructions', '', 'publish', 'open', 'open', '', 'field_52d904bb7e666', '', '', '2014-07-08 16:17:48', '2014-07-08 16:17:48', '', 72, 'http://9zero7films.dev/?post_type=acf-field&p=77', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (79, 1, '2015-09-07 02:27:58', '2015-09-07 02:27:58', '', 'FAQs', '', 'publish', 'closed', 'closed', '', 'faqs', '', '', '2015-09-07 02:29:41', '2015-09-07 02:29:41', '', 0, 'http://9zero7films.dev/?page_id=79', 5, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (80, 1, '2015-09-07 02:27:58', '2015-09-07 02:27:58', '', 'FAQs', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2015-09-07 02:27:58', '2015-09-07 02:27:58', '', 79, 'http://9zero7films.dev/2015/09/79-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (81, 1, '2015-09-07 02:28:19', '2015-09-07 02:28:19', '', 'Sponsors', '', 'publish', 'closed', 'closed', '', 'sponsors', '', '', '2015-09-11 21:04:29', '2015-09-11 21:04:29', '', 0, 'http://9zero7films.dev/?page_id=81', 6, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (82, 1, '2015-09-07 02:28:19', '2015-09-07 02:28:19', '', 'Sponsors', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2015-09-07 02:28:19', '2015-09-07 02:28:19', '', 81, 'http://9zero7films.dev/2015/09/81-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (83, 1, '2015-09-07 02:28:36', '2015-09-07 02:28:36', '', 'Donate', '', 'publish', 'closed', 'closed', '', 'donate', '', '', '2015-09-11 20:39:15', '2015-09-11 20:39:15', '', 0, 'http://9zero7films.dev/?page_id=83', 7, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (84, 1, '2015-09-07 02:28:36', '2015-09-07 02:28:36', '', 'Donate', '', 'inherit', 'closed', 'closed', '', '83-revision-v1', '', '', '2015-09-07 02:28:36', '2015-09-07 02:28:36', '', 83, 'http://9zero7films.dev/2015/09/83-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (85, 1, '2015-09-07 02:29:09', '2015-09-07 02:29:09', '', 'Classes', '', 'publish', 'closed', 'closed', '', 'classes', '', '', '2015-09-07 02:29:09', '2015-09-07 02:29:09', '', 0, 'http://9zero7films.dev/?page_id=85', 3, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (86, 1, '2015-09-07 02:29:09', '2015-09-07 02:29:09', '', 'Classes', '', 'inherit', 'closed', 'closed', '', '85-revision-v1', '', '', '2015-09-07 02:29:09', '2015-09-07 02:29:09', '', 85, 'http://9zero7films.dev/2015/09/85-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (87, 1, '2015-09-07 02:30:59', '2015-09-07 02:30:59', ' ', '', '', 'publish', 'closed', 'closed', '', '87', '', '', '2015-09-11 20:14:00', '2015-09-11 20:14:00', '', 0, 'http://9zero7films.dev/?p=87', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (88, 1, '2015-09-07 02:30:59', '2015-09-07 02:30:59', ' ', '', '', 'publish', 'closed', 'closed', '', '88', '', '', '2015-09-11 20:14:00', '2015-09-11 20:14:00', '', 0, 'http://9zero7films.dev/?p=88', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (89, 1, '2015-09-07 03:51:41', '2015-09-07 03:51:41', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam feugiat lorem at justo pellentesque, ac molestie nisi scelerisque. <a href="http://9zero7films.dev/">http://9zero7films.dev/</a> malesuada eu sapien. Maecenas id pulvinar sapien, sit amet porttitor enim. Pellentesque augue ligula, dapibus id interdum at, tempor ut diam. Aenean elit sapien, vestibulum egestas lorem vitae, ultricies finibus neque.
<ol>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ol>
Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam aliquet, dui vitae eleifend commodo, odio lectus euismod purus, at suscipit urna dui vel urna.
<h2>Sed eget sagittis ex, quis fermentum nibh pellentesque eleifend lectus id lacinia venenatis.</h2>
Suspendisse egestas nisi et fermentum luctus. Mauris sit amet nunc at sem auctor aliquam at a orci. Etiam vel nisi ultricies urna placerat faucibus at vitae diam. Duis sed cursus diam. Maecenas non tempus erat. Sed ut semper ante. <strong>Proin dignissim, est vitae ullamcorper blandit</strong>, erat nulla laoreet erat, quis euismod nulla augue vel velit.

Sed rutrum nibh ut viverra semper. Quisque lobortis ultricies facilisis. Nulla mauris neque, luctus sed sapien vitae, imperdiet laoreet lacus. Vivamus ex lectus, porta a velit a, ullamcorper auctor massa. Aenean vulputate erat at congue efficitur. Nullam varius egestas ex. <em>Fusce imperdiet tellus et luctus suscipit</em>. Nulla ut dui a massa mollis tincidunt. Pellentesque eu sem eu purus pellentesque feugiat non quis est. Nulla pretium, eros et faucibus molestie, nisi justo faucibus lacus, et venenatis ex augue nec nunc. Nunc id nunc massa.
<ul>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ul>
Nulla venenatis condimentum est, sed efficitur purus congue id. Vivamus a malesuada augue. Donec consequat interdum nisi nec laoreet. Morbi ultrices varius dui, vitae pulvinar nibh ornare sed. Donec semper gravida neque scelerisque bibendum. In eu rutrum mi. Quisque luctus tellus ut sem maximus vehicula. Nunc vel varius nisi, vitae venenatis erat. Cras mollis interdum enim, ac pretium ligula feugiat eu. In sed lectus ut ipsum euismod sodales eget sed augue.
<h3>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h3>
Ut mattis non enim quis pretium. Suspendisse blandit mollis libero sit amet commodo. Quisque sagittis iaculis risus congue rhoncus. Mauris fermentum elit sit amet nunc ullamcorper, non iaculis eros suscipit. Ut facilisis accumsan nunc. Vivamus finibus ut erat ut mollis. Quisque sed lacus enim. Nulla facilisi. Suspendisse non faucibus neque. Quisque lacus elit, sodales a laoreet sollicitudin, elementum sit amet tellus. Quisque metus lorem, ornare non aliquam sit amet, gravida et est. Maecenas quis malesuada ante. Mauris ac neque sit amet justo varius pulvinar quis et enim. Proin aliquet eget enim non ornare. Suspendisse cursus risus nec enim suscipit commodo ac a ligula.

Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean congue erat in mauris viverra eleifend in eget nunc. Aliquam orci erat, blandit quis lorem quis, pellentesque placerat justo. Sed arcu nunc, lacinia quis magna vel, tempor tempus urna. In sit amet mi dapibus, consectetur lorem ac, aliquet metus. Morbi faucibus vitae purus sit amet varius.

Etiam ut tincidunt sapien, eu gravida enim Vivamus congue leo tellus, id pellentesque justo finibus at. Maecenas rhoncus magna eget quam bibendum, ut iaculis massa facilisis. Sed sed condimentum tortor, eget tristique mauris. Morbi eu imperdiet nunc. In interdum non ipsum sit amet molestie. Aenean vel eros ornare, ornare elit et, tincidunt quam. Sed ac erat et nulla aliquam euismod eget eget quam. Quisque eget quam ligula. Suspendisse euismod dui vitae euismod tincidunt. Morbi accumsan purus sit amet mattis laoreet.

Suspendisse vitae nibh elementum sapien cursus hendrerit. Mauris varius tortor maximus, gravida lorem nec, commodo massa. Pellentesque malesuada erat quis lacus aliquet lacinia. Quisque vel est a augue porta scelerisque vitae vel risus. Pellentesque nec nisl luctus, dapibus orci a, ornare est.
<blockquote>Duis finibus, ante eu laoreet pulvinar, mauris nulla vulputate neque, nec lacinia mauris est in ipsum. Proin vestibulum blandit odio a pharetra. Pellentesque sed nulla ut arcu vestibulum facilisis. Ut vitae congue risus. Quisque mattis leo non ornare viverra. Aliquam eget massa neque. Cras nec placerat magna.</blockquote>
Duis eu pellentesque neque, non ullamcorper lectus. Etiam ut tellus congue turpis bibendum accumsan. Etiam non condimentum neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean tempus ipsum purus, vel consequat sapien feugiat ac. Maecenas vestibulum est vel arcu vestibulum, a tempor nulla maximus. Vivamus hendrerit dolor consequat dignissim dignissim.
<h5>Maecenas eu fringilla nisl, nec hendrerit est. Maecenas quis nibh eget ipsum bibendum facilisis.</h5>
Proin dapibus diam eget rhoncus efficitur. Duis mollis ante at bibendum pharetra. Praesent ultricies mollis accumsan. Nunc feugiat quis velit eget commodo. Praesent ultricies iaculis erat, nec fermentum est pharetra non. Nulla facilisi. Sed sollicitudin mauris ac magna scelerisque vulputate. Etiam sit amet nisi vel eros finibus sodales. Nullam egestas fringilla eros a aliquet. Mauris et mollis erat, in eleifend turpis.

Vivamus sit amet neque ut arcu maximus gravida. Mauris sodales quam vel finibus auctor. Vestibulum eget nulla turpis. Cras eros augue, semper nec malesuada vel, elementum sed sem. Aenean ac maximus ex, mattis dictum enim. Sed ultrices leo in tellus iaculis imperdiet. Morbi auctor arcu nec elit interdum dapibus. Integer sed leo odio. Aliquam nec ultricies risus, vel porta lectus. Sed accumsan placerat leo, at aliquam felis rhoncus aliquam. Curabitur in sodales massa. Aenean dui est, commodo ac venenatis et, aliquam eu neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse interdum enim quis volutpat sollicitudin. Morbi bibendum est non egestas rhoncus. Cras tempor sagittis nibh sit amet pharetra.

Quisque sagittis, libero in sagittis imperdiet, magna felis tincidunt erat, sit amet sagittis libero risus sed diam. Etiam vestibulum non purus in gravida. Nulla facilisi. Nunc lectus purus, gravida quis ligula vehicula, pulvinar venenatis nibh. Aenean hendrerit eleifend lacus, vel ultrices nisi ultricies eget. Mauris neque quam, laoreet varius maximus id, auctor sit amet ante. Maecenas sed felis sit amet risus varius rutrum nec eu enim. Ut commodo sollicitudin purus ut auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras volutpat tristique neque sit amet pulvinar. Cras sed sem ac dolor ornare sagittis. Morbi augue augue, gravida vitae mi sit amet, ornare tempor libero. Donec sagittis fermentum magna eget aliquam. Etiam fermentum mi a lacinia varius.

Morbi venenatis velit non interdum bibendum. Phasellus iaculis ornare elementum. Vivamus ac imperdiet ligula, eget ultrices diam. Vivamus sed tincidunt turpis. Integer eu auctor eros. Nullam finibus laoreet venenatis. Nunc ac sem cursus, faucibus sem a, aliquam turpis. Praesent bibendum magna vitae pulvinar fermentum. Mauris at sollicitudin orci, sed tempus leo. Fusce quis magna tristique, eleifend metus sed, sodales sapien. Suspendisse sit amet massa consequat nulla lacinia sagittis.

In ullamcorper ac eros eu efficitur. Donec a orci orci. Suspendisse egestas lacus in risus feugiat, eget maximus mauris condimentum. Duis ut ante et diam feugiat tincidunt. Morbi nec velit vitae sapien elementum sagittis. Fusce sed luctus massa, quis mollis dolor. Suspendisse facilisis orci et maximus feugiat. Sed quis congue erat. Cras porta efficitur magna, dictum sagittis urna laoreet semper. Etiam ac nunc orci.
<h6>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.</h6>
Vestibulum eget pretium elit. Pellentesque nec tempor augue. In velit ipsum, porttitor et vulputate et, sollicitudin ac mi. Aliquam placerat non magna quis auctor. Sed sagittis nisi vitae lectus semper, id semper quam consequat. Nulla posuere, ex in iaculis ultricies, nulla libero sollicitudin dui, ut tristique orci leo ut tortor. Fusce laoreet tincidunt lacus id posuere. Donec et metus sit amet diam lobortis aliquet. Aenean eget vestibulum mauris. Sed id est lacus. Aenean sed congue diam. Nullam pretium dictum elit non tempus. Suspendisse potenti. Pellentesque mattis lorem vitae dolor porttitor, vitae condimentum magna vulputate. Pellentesque bibendum lorem ut lorem dictum, ut venenatis orci tempus.

Aliquam id augue lobortis, pellentesque leo sit amet, bibendum est. Morbi quis ex nec eros efficitur imperdiet vitae id dolor. Pellentesque et lectus vitae augue pretium lobortis. Fusce ante orci, rutrum non ultrices sit amet, pellentesque vitae lacus. Proin at mattis risus. Suspendisse sem magna, ultrices at lectus at, laoreet lobortis tortor. Fusce viverra vestibulum dui id ultrices. Suspendisse eu rhoncus massa, eget sodales elit. Proin gravida dolor at sapien congue, sed vehicula nisi rutrum.', 'Quisque sagittis libero in sagittis imperdiet magna felis tincidunt erat sit amet sagittis libero risus sed diam', '', 'inherit', 'closed', 'closed', '', '24-autosave-v1', '', '', '2015-09-07 03:51:41', '2015-09-07 03:51:41', '', 24, 'http://9zero7films.dev/2015/09/24-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (90, 1, '2015-09-07 03:04:56', '2015-09-07 03:04:56', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam feugiat lorem at justo pellentesque, ac molestie nisi scelerisque. Praesent ac eros eget erat lacinia sodales malesuada eu sapien. Maecenas id pulvinar sapien, sit amet porttitor enim. Pellentesque augue ligula, dapibus id interdum at, tempor ut diam. Aenean elit sapien, vestibulum egestas lorem vitae, ultricies finibus neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam aliquet, dui vitae eleifend commodo, odio lectus euismod purus, at suscipit urna dui vel urna. Sed eget sagittis ex, quis fermentum nibh. Pellentesque eleifend lectus id lacinia venenatis. Suspendisse egestas nisi et fermentum luctus. Mauris sit amet nunc at sem auctor aliquam at a orci. Etiam vel nisi ultricies urna placerat faucibus at vitae diam. Duis sed cursus diam. Maecenas non tempus erat. Sed ut semper ante. Proin dignissim, est vitae ullamcorper blandit, erat nulla laoreet erat, quis euismod nulla augue vel velit.

Sed rutrum nibh ut viverra semper. Quisque lobortis ultricies facilisis. Nulla mauris neque, luctus sed sapien vitae, imperdiet laoreet lacus. Vivamus ex lectus, porta a velit a, ullamcorper auctor massa. Aenean vulputate erat at congue efficitur. Nullam varius egestas ex. Fusce imperdiet tellus et luctus suscipit. Nulla ut dui a massa mollis tincidunt. Pellentesque eu sem eu purus pellentesque feugiat non quis est. Nulla pretium, eros et faucibus molestie, nisi justo faucibus lacus, et venenatis ex augue nec nunc. Nunc id nunc massa.

Nulla venenatis condimentum est, sed efficitur purus congue id. Vivamus a malesuada augue. Donec consequat interdum nisi nec laoreet. Morbi ultrices varius dui, vitae pulvinar nibh ornare sed. Donec semper gravida neque scelerisque bibendum. In eu rutrum mi. Quisque luctus tellus ut sem maximus vehicula. Nunc vel varius nisi, vitae venenatis erat. Cras mollis interdum enim, ac pretium ligula feugiat eu. In sed lectus ut ipsum euismod sodales eget sed augue.

Ut mattis non enim quis pretium. Suspendisse blandit mollis libero sit amet commodo. Quisque sagittis iaculis risus congue rhoncus. Mauris fermentum elit sit amet nunc ullamcorper, non iaculis eros suscipit. Ut facilisis accumsan nunc. Vivamus finibus ut erat ut mollis. Quisque sed lacus enim. Nulla facilisi. Suspendisse non faucibus neque. Quisque lacus elit, sodales a laoreet sollicitudin, elementum sit amet tellus. Quisque metus lorem, ornare non aliquam sit amet, gravida et est. Maecenas quis malesuada ante. Mauris ac neque sit amet justo varius pulvinar quis et enim. Proin aliquet eget enim non ornare. Suspendisse cursus risus nec enim suscipit commodo ac a ligula.

Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean congue erat in mauris viverra eleifend in eget nunc. Aliquam orci erat, blandit quis lorem quis, pellentesque placerat justo. Sed arcu nunc, lacinia quis magna vel, tempor tempus urna. In sit amet mi dapibus, consectetur lorem ac, aliquet metus. Morbi faucibus vitae purus sit amet varius.

Etiam ut tincidunt sapien, eu gravida enim. Vivamus congue leo tellus, id pellentesque justo finibus at. Maecenas rhoncus magna eget quam bibendum, ut iaculis massa facilisis. Sed sed condimentum tortor, eget tristique mauris. Morbi eu imperdiet nunc. In interdum non ipsum sit amet molestie. Aenean vel eros ornare, ornare elit et, tincidunt quam. Sed ac erat et nulla aliquam euismod eget eget quam. Quisque eget quam ligula. Suspendisse euismod dui vitae euismod tincidunt. Morbi accumsan purus sit amet mattis laoreet.

Suspendisse vitae nibh elementum sapien cursus hendrerit. Mauris varius tortor maximus, gravida lorem nec, commodo massa. Pellentesque malesuada erat quis lacus aliquet lacinia. Quisque vel est a augue porta scelerisque vitae vel risus. Pellentesque nec nisl luctus, dapibus orci a, ornare est. Duis finibus, ante eu laoreet pulvinar, mauris nulla vulputate neque, nec lacinia mauris est in ipsum. Proin vestibulum blandit odio a pharetra. Pellentesque sed nulla ut arcu vestibulum facilisis. Ut vitae congue risus. Quisque mattis leo non ornare viverra. Aliquam eget massa neque. Cras nec placerat magna.

Duis eu pellentesque neque, non ullamcorper lectus. Etiam ut tellus congue turpis bibendum accumsan. Etiam non condimentum neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean tempus ipsum purus, vel consequat sapien feugiat ac. Maecenas vestibulum est vel arcu vestibulum, a tempor nulla maximus. Vivamus hendrerit dolor consequat dignissim dignissim.

Maecenas eu fringilla nisl, nec hendrerit est. Maecenas quis nibh eget ipsum bibendum facilisis. Proin dapibus diam eget rhoncus efficitur. Duis mollis ante at bibendum pharetra. Praesent ultricies mollis accumsan. Nunc feugiat quis velit eget commodo. Praesent ultricies iaculis erat, nec fermentum est pharetra non. Nulla facilisi. Sed sollicitudin mauris ac magna scelerisque vulputate. Etiam sit amet nisi vel eros finibus sodales. Nullam egestas fringilla eros a aliquet. Mauris et mollis erat, in eleifend turpis.

Vivamus sit amet neque ut arcu maximus gravida. Mauris sodales quam vel finibus auctor. Vestibulum eget nulla turpis. Cras eros augue, semper nec malesuada vel, elementum sed sem. Aenean ac maximus ex, mattis dictum enim. Sed ultrices leo in tellus iaculis imperdiet. Morbi auctor arcu nec elit interdum dapibus. Integer sed leo odio. Aliquam nec ultricies risus, vel porta lectus. Sed accumsan placerat leo, at aliquam felis rhoncus aliquam. Curabitur in sodales massa. Aenean dui est, commodo ac venenatis et, aliquam eu neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse interdum enim quis volutpat sollicitudin. Morbi bibendum est non egestas rhoncus. Cras tempor sagittis nibh sit amet pharetra.

Quisque sagittis, libero in sagittis imperdiet, magna felis tincidunt erat, sit amet sagittis libero risus sed diam. Etiam vestibulum non purus in gravida. Nulla facilisi. Nunc lectus purus, gravida quis ligula vehicula, pulvinar venenatis nibh. Aenean hendrerit eleifend lacus, vel ultrices nisi ultricies eget. Mauris neque quam, laoreet varius maximus id, auctor sit amet ante. Maecenas sed felis sit amet risus varius rutrum nec eu enim. Ut commodo sollicitudin purus ut auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras volutpat tristique neque sit amet pulvinar. Cras sed sem ac dolor ornare sagittis. Morbi augue augue, gravida vitae mi sit amet, ornare tempor libero. Donec sagittis fermentum magna eget aliquam. Etiam fermentum mi a lacinia varius.

Morbi venenatis velit non interdum bibendum. Phasellus iaculis ornare elementum. Vivamus ac imperdiet ligula, eget ultrices diam. Vivamus sed tincidunt turpis. Integer eu auctor eros. Nullam finibus laoreet venenatis. Nunc ac sem cursus, faucibus sem a, aliquam turpis. Praesent bibendum magna vitae pulvinar fermentum. Mauris at sollicitudin orci, sed tempus leo. Fusce quis magna tristique, eleifend metus sed, sodales sapien. Suspendisse sit amet massa consequat nulla lacinia sagittis.

In ullamcorper ac eros eu efficitur. Donec a orci orci. Suspendisse egestas lacus in risus feugiat, eget maximus mauris condimentum. Duis ut ante et diam feugiat tincidunt. Morbi nec velit vitae sapien elementum sagittis. Fusce sed luctus massa, quis mollis dolor. Suspendisse facilisis orci et maximus feugiat. Sed quis congue erat. Cras porta efficitur magna, dictum sagittis urna laoreet semper. Etiam ac nunc orci.

Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum eget pretium elit. Pellentesque nec tempor augue. In velit ipsum, porttitor et vulputate et, sollicitudin ac mi. Aliquam placerat non magna quis auctor. Sed sagittis nisi vitae lectus semper, id semper quam consequat. Nulla posuere, ex in iaculis ultricies, nulla libero sollicitudin dui, ut tristique orci leo ut tortor. Fusce laoreet tincidunt lacus id posuere. Donec et metus sit amet diam lobortis aliquet. Aenean eget vestibulum mauris. Sed id est lacus. Aenean sed congue diam. Nullam pretium dictum elit non tempus. Suspendisse potenti. Pellentesque mattis lorem vitae dolor porttitor, vitae condimentum magna vulputate. Pellentesque bibendum lorem ut lorem dictum, ut venenatis orci tempus.

Aliquam id augue lobortis, pellentesque leo sit amet, bibendum est. Morbi quis ex nec eros efficitur imperdiet vitae id dolor. Pellentesque et lectus vitae augue pretium lobortis. Fusce ante orci, rutrum non ultrices sit amet, pellentesque vitae lacus. Proin at mattis risus. Suspendisse sem magna, ultrices at lectus at, laoreet lobortis tortor. Fusce viverra vestibulum dui id ultrices. Suspendisse eu rhoncus massa, eget sodales elit. Proin gravida dolor at sapien congue, sed vehicula nisi rutrum.', 'Article One', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2015-09-07 03:04:56', '2015-09-07 03:04:56', '', 24, 'http://9zero7films.dev/2015/09/24-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (91, 1, '2015-09-07 03:06:47', '2015-09-07 03:06:47', '<h1>Pellentesque eu sem eu purus pellentesque feugiat non quis est</h1>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam feugiat lorem at justo pellentesque, ac molestie nisi scelerisque. Praesent ac eros eget erat lacinia sodales malesuada eu sapien. Maecenas id pulvinar sapien, sit amet porttitor enim. Pellentesque augue ligula, dapibus id interdum at, tempor ut diam. Aenean elit sapien, vestibulum egestas lorem vitae, ultricies finibus neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam aliquet, dui vitae eleifend commodo, odio lectus euismod purus, at suscipit urna dui vel urna. Sed eget sagittis ex, quis fermentum nibh. Pellentesque eleifend lectus id lacinia venenatis. Suspendisse egestas nisi et fermentum luctus. Mauris sit amet nunc at sem auctor aliquam at a orci. Etiam vel nisi ultricies urna placerat faucibus at vitae diam. Duis sed cursus diam. Maecenas non tempus erat. Sed ut semper ante. Proin dignissim, est vitae ullamcorper blandit, erat nulla laoreet erat, quis euismod nulla augue vel velit.

Sed rutrum nibh ut viverra semper. Quisque lobortis ultricies facilisis. Nulla mauris neque, luctus sed sapien vitae, imperdiet laoreet lacus. Vivamus ex lectus, porta a velit a, ullamcorper auctor massa. Aenean vulputate erat at congue efficitur. Nullam varius egestas ex. Fusce imperdiet tellus et luctus suscipit. Nulla ut dui a massa mollis tincidunt. Pellentesque eu sem eu purus pellentesque feugiat non quis est. Nulla pretium, eros et faucibus molestie, nisi justo faucibus lacus, et venenatis ex augue nec nunc. Nunc id nunc massa.

Nulla venenatis condimentum est, sed efficitur purus congue id. Vivamus a malesuada augue. Donec consequat interdum nisi nec laoreet. Morbi ultrices varius dui, vitae pulvinar nibh ornare sed. Donec semper gravida neque scelerisque bibendum. In eu rutrum mi. Quisque luctus tellus ut sem maximus vehicula. Nunc vel varius nisi, vitae venenatis erat. Cras mollis interdum enim, ac pretium ligula feugiat eu. In sed lectus ut ipsum euismod sodales eget sed augue.

Ut mattis non enim quis pretium. Suspendisse blandit mollis libero sit amet commodo. Quisque sagittis iaculis risus congue rhoncus. Mauris fermentum elit sit amet nunc ullamcorper, non iaculis eros suscipit. Ut facilisis accumsan nunc. Vivamus finibus ut erat ut mollis. Quisque sed lacus enim. Nulla facilisi. Suspendisse non faucibus neque. Quisque lacus elit, sodales a laoreet sollicitudin, elementum sit amet tellus. Quisque metus lorem, ornare non aliquam sit amet, gravida et est. Maecenas quis malesuada ante. Mauris ac neque sit amet justo varius pulvinar quis et enim. Proin aliquet eget enim non ornare. Suspendisse cursus risus nec enim suscipit commodo ac a ligula.

Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean congue erat in mauris viverra eleifend in eget nunc. Aliquam orci erat, blandit quis lorem quis, pellentesque placerat justo. Sed arcu nunc, lacinia quis magna vel, tempor tempus urna. In sit amet mi dapibus, consectetur lorem ac, aliquet metus. Morbi faucibus vitae purus sit amet varius.

Etiam ut tincidunt sapien, eu gravida enim. Vivamus congue leo tellus, id pellentesque justo finibus at. Maecenas rhoncus magna eget quam bibendum, ut iaculis massa facilisis. Sed sed condimentum tortor, eget tristique mauris. Morbi eu imperdiet nunc. In interdum non ipsum sit amet molestie. Aenean vel eros ornare, ornare elit et, tincidunt quam. Sed ac erat et nulla aliquam euismod eget eget quam. Quisque eget quam ligula. Suspendisse euismod dui vitae euismod tincidunt. Morbi accumsan purus sit amet mattis laoreet.

Suspendisse vitae nibh elementum sapien cursus hendrerit. Mauris varius tortor maximus, gravida lorem nec, commodo massa. Pellentesque malesuada erat quis lacus aliquet lacinia. Quisque vel est a augue porta scelerisque vitae vel risus. Pellentesque nec nisl luctus, dapibus orci a, ornare est. Duis finibus, ante eu laoreet pulvinar, mauris nulla vulputate neque, nec lacinia mauris est in ipsum. Proin vestibulum blandit odio a pharetra. Pellentesque sed nulla ut arcu vestibulum facilisis. Ut vitae congue risus. Quisque mattis leo non ornare viverra. Aliquam eget massa neque. Cras nec placerat magna.

Duis eu pellentesque neque, non ullamcorper lectus. Etiam ut tellus congue turpis bibendum accumsan. Etiam non condimentum neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean tempus ipsum purus, vel consequat sapien feugiat ac. Maecenas vestibulum est vel arcu vestibulum, a tempor nulla maximus. Vivamus hendrerit dolor consequat dignissim dignissim.

Maecenas eu fringilla nisl, nec hendrerit est. Maecenas quis nibh eget ipsum bibendum facilisis. Proin dapibus diam eget rhoncus efficitur. Duis mollis ante at bibendum pharetra. Praesent ultricies mollis accumsan. Nunc feugiat quis velit eget commodo. Praesent ultricies iaculis erat, nec fermentum est pharetra non. Nulla facilisi. Sed sollicitudin mauris ac magna scelerisque vulputate. Etiam sit amet nisi vel eros finibus sodales. Nullam egestas fringilla eros a aliquet. Mauris et mollis erat, in eleifend turpis.

Vivamus sit amet neque ut arcu maximus gravida. Mauris sodales quam vel finibus auctor. Vestibulum eget nulla turpis. Cras eros augue, semper nec malesuada vel, elementum sed sem. Aenean ac maximus ex, mattis dictum enim. Sed ultrices leo in tellus iaculis imperdiet. Morbi auctor arcu nec elit interdum dapibus. Integer sed leo odio. Aliquam nec ultricies risus, vel porta lectus. Sed accumsan placerat leo, at aliquam felis rhoncus aliquam. Curabitur in sodales massa. Aenean dui est, commodo ac venenatis et, aliquam eu neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse interdum enim quis volutpat sollicitudin. Morbi bibendum est non egestas rhoncus. Cras tempor sagittis nibh sit amet pharetra.

Quisque sagittis, libero in sagittis imperdiet, magna felis tincidunt erat, sit amet sagittis libero risus sed diam. Etiam vestibulum non purus in gravida. Nulla facilisi. Nunc lectus purus, gravida quis ligula vehicula, pulvinar venenatis nibh. Aenean hendrerit eleifend lacus, vel ultrices nisi ultricies eget. Mauris neque quam, laoreet varius maximus id, auctor sit amet ante. Maecenas sed felis sit amet risus varius rutrum nec eu enim. Ut commodo sollicitudin purus ut auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras volutpat tristique neque sit amet pulvinar. Cras sed sem ac dolor ornare sagittis. Morbi augue augue, gravida vitae mi sit amet, ornare tempor libero. Donec sagittis fermentum magna eget aliquam. Etiam fermentum mi a lacinia varius.

Morbi venenatis velit non interdum bibendum. Phasellus iaculis ornare elementum. Vivamus ac imperdiet ligula, eget ultrices diam. Vivamus sed tincidunt turpis. Integer eu auctor eros. Nullam finibus laoreet venenatis. Nunc ac sem cursus, faucibus sem a, aliquam turpis. Praesent bibendum magna vitae pulvinar fermentum. Mauris at sollicitudin orci, sed tempus leo. Fusce quis magna tristique, eleifend metus sed, sodales sapien. Suspendisse sit amet massa consequat nulla lacinia sagittis.

In ullamcorper ac eros eu efficitur. Donec a orci orci. Suspendisse egestas lacus in risus feugiat, eget maximus mauris condimentum. Duis ut ante et diam feugiat tincidunt. Morbi nec velit vitae sapien elementum sagittis. Fusce sed luctus massa, quis mollis dolor. Suspendisse facilisis orci et maximus feugiat. Sed quis congue erat. Cras porta efficitur magna, dictum sagittis urna laoreet semper. Etiam ac nunc orci.

Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum eget pretium elit. Pellentesque nec tempor augue. In velit ipsum, porttitor et vulputate et, sollicitudin ac mi. Aliquam placerat non magna quis auctor. Sed sagittis nisi vitae lectus semper, id semper quam consequat. Nulla posuere, ex in iaculis ultricies, nulla libero sollicitudin dui, ut tristique orci leo ut tortor. Fusce laoreet tincidunt lacus id posuere. Donec et metus sit amet diam lobortis aliquet. Aenean eget vestibulum mauris. Sed id est lacus. Aenean sed congue diam. Nullam pretium dictum elit non tempus. Suspendisse potenti. Pellentesque mattis lorem vitae dolor porttitor, vitae condimentum magna vulputate. Pellentesque bibendum lorem ut lorem dictum, ut venenatis orci tempus.

Aliquam id augue lobortis, pellentesque leo sit amet, bibendum est. Morbi quis ex nec eros efficitur imperdiet vitae id dolor. Pellentesque et lectus vitae augue pretium lobortis. Fusce ante orci, rutrum non ultrices sit amet, pellentesque vitae lacus. Proin at mattis risus. Suspendisse sem magna, ultrices at lectus at, laoreet lobortis tortor. Fusce viverra vestibulum dui id ultrices. Suspendisse eu rhoncus massa, eget sodales elit. Proin gravida dolor at sapien congue, sed vehicula nisi rutrum.', 'Article One', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2015-09-07 03:06:47', '2015-09-07 03:06:47', '', 24, 'http://9zero7films.dev/2015/09/24-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (92, 1, '2015-09-07 03:19:59', '2015-09-07 03:19:59', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam feugiat lorem at justo pellentesque, ac molestie nisi scelerisque. <a href="http://9zero7films.dev/">http://9zero7films.dev/</a> malesuada eu sapien. Maecenas id pulvinar sapien, sit amet porttitor enim. Pellentesque augue ligula, dapibus id interdum at, tempor ut diam. Aenean elit sapien, vestibulum egestas lorem vitae, ultricies finibus neque.
<ol>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ol>
Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam aliquet, dui vitae eleifend commodo, odio lectus euismod purus, at suscipit urna dui vel urna.
<h2>Sed eget sagittis ex, quis fermentum nibh pellentesque eleifend lectus id lacinia venenatis.</h2>
Suspendisse egestas nisi et fermentum luctus. Mauris sit amet nunc at sem auctor aliquam at a orci. Etiam vel nisi ultricies urna placerat faucibus at vitae diam. Duis sed cursus diam. Maecenas non tempus erat. Sed ut semper ante. <strong>Proin dignissim, est vitae ullamcorper blandit</strong>, erat nulla laoreet erat, quis euismod nulla augue vel velit.

Sed rutrum nibh ut viverra semper. Quisque lobortis ultricies facilisis. Nulla mauris neque, luctus sed sapien vitae, imperdiet laoreet lacus. Vivamus ex lectus, porta a velit a, ullamcorper auctor massa. Aenean vulputate erat at congue efficitur. Nullam varius egestas ex. <em>Fusce imperdiet tellus et luctus suscipit</em>. Nulla ut dui a massa mollis tincidunt. Pellentesque eu sem eu purus pellentesque feugiat non quis est. Nulla pretium, eros et faucibus molestie, nisi justo faucibus lacus, et venenatis ex augue nec nunc. Nunc id nunc massa.
<ul>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ul>
Nulla venenatis condimentum est, sed efficitur purus congue id. Vivamus a malesuada augue. Donec consequat interdum nisi nec laoreet. Morbi ultrices varius dui, vitae pulvinar nibh ornare sed. Donec semper gravida neque scelerisque bibendum. In eu rutrum mi. Quisque luctus tellus ut sem maximus vehicula. Nunc vel varius nisi, vitae venenatis erat. Cras mollis interdum enim, ac pretium ligula feugiat eu. In sed lectus ut ipsum euismod sodales eget sed augue.
<h3>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h3>
Ut mattis non enim quis pretium. Suspendisse blandit mollis libero sit amet commodo. Quisque sagittis iaculis risus congue rhoncus. Mauris fermentum elit sit amet nunc ullamcorper, non iaculis eros suscipit. Ut facilisis accumsan nunc. Vivamus finibus ut erat ut mollis. Quisque sed lacus enim. Nulla facilisi. Suspendisse non faucibus neque. Quisque lacus elit, sodales a laoreet sollicitudin, elementum sit amet tellus. Quisque metus lorem, ornare non aliquam sit amet, gravida et est. Maecenas quis malesuada ante. Mauris ac neque sit amet justo varius pulvinar quis et enim. Proin aliquet eget enim non ornare. Suspendisse cursus risus nec enim suscipit commodo ac a ligula.

Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean congue erat in mauris viverra eleifend in eget nunc. Aliquam orci erat, blandit quis lorem quis, pellentesque placerat justo. Sed arcu nunc, lacinia quis magna vel, tempor tempus urna. In sit amet mi dapibus, consectetur lorem ac, aliquet metus. Morbi faucibus vitae purus sit amet varius.
<h4>Etiam ut tincidunt sapien, eu gravida enim.</h4>
Vivamus congue leo tellus, id pellentesque justo finibus at. Maecenas rhoncus magna eget quam bibendum, ut iaculis massa facilisis. Sed sed condimentum tortor, eget tristique mauris. Morbi eu imperdiet nunc. In interdum non ipsum sit amet molestie. Aenean vel eros ornare, ornare elit et, tincidunt quam. Sed ac erat et nulla aliquam euismod eget eget quam. Quisque eget quam ligula. Suspendisse euismod dui vitae euismod tincidunt. Morbi accumsan purus sit amet mattis laoreet.

Suspendisse vitae nibh elementum sapien cursus hendrerit. Mauris varius tortor maximus, gravida lorem nec, commodo massa. Pellentesque malesuada erat quis lacus aliquet lacinia. Quisque vel est a augue porta scelerisque vitae vel risus. Pellentesque nec nisl luctus, dapibus orci a, ornare est.
<blockquote>Duis finibus, ante eu laoreet pulvinar, mauris nulla vulputate neque, nec lacinia mauris est in ipsum. Proin vestibulum blandit odio a pharetra. Pellentesque sed nulla ut arcu vestibulum facilisis. Ut vitae congue risus. Quisque mattis leo non ornare viverra. Aliquam eget massa neque. Cras nec placerat magna.</blockquote>
Duis eu pellentesque neque, non ullamcorper lectus. Etiam ut tellus congue turpis bibendum accumsan. Etiam non condimentum neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean tempus ipsum purus, vel consequat sapien feugiat ac. Maecenas vestibulum est vel arcu vestibulum, a tempor nulla maximus. Vivamus hendrerit dolor consequat dignissim dignissim.

Maecenas eu fringilla nisl, nec hendrerit est. Maecenas quis nibh eget ipsum bibendum facilisis. Proin dapibus diam eget rhoncus efficitur. Duis mollis ante at bibendum pharetra. Praesent ultricies mollis accumsan. Nunc feugiat quis velit eget commodo. Praesent ultricies iaculis erat, nec fermentum est pharetra non. Nulla facilisi. Sed sollicitudin mauris ac magna scelerisque vulputate. Etiam sit amet nisi vel eros finibus sodales. Nullam egestas fringilla eros a aliquet. Mauris et mollis erat, in eleifend turpis.

Vivamus sit amet neque ut arcu maximus gravida. Mauris sodales quam vel finibus auctor. Vestibulum eget nulla turpis. Cras eros augue, semper nec malesuada vel, elementum sed sem. Aenean ac maximus ex, mattis dictum enim. Sed ultrices leo in tellus iaculis imperdiet. Morbi auctor arcu nec elit interdum dapibus. Integer sed leo odio. Aliquam nec ultricies risus, vel porta lectus. Sed accumsan placerat leo, at aliquam felis rhoncus aliquam. Curabitur in sodales massa. Aenean dui est, commodo ac venenatis et, aliquam eu neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse interdum enim quis volutpat sollicitudin. Morbi bibendum est non egestas rhoncus. Cras tempor sagittis nibh sit amet pharetra.

Quisque sagittis, libero in sagittis imperdiet, magna felis tincidunt erat, sit amet sagittis libero risus sed diam. Etiam vestibulum non purus in gravida. Nulla facilisi. Nunc lectus purus, gravida quis ligula vehicula, pulvinar venenatis nibh. Aenean hendrerit eleifend lacus, vel ultrices nisi ultricies eget. Mauris neque quam, laoreet varius maximus id, auctor sit amet ante. Maecenas sed felis sit amet risus varius rutrum nec eu enim. Ut commodo sollicitudin purus ut auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras volutpat tristique neque sit amet pulvinar. Cras sed sem ac dolor ornare sagittis. Morbi augue augue, gravida vitae mi sit amet, ornare tempor libero. Donec sagittis fermentum magna eget aliquam. Etiam fermentum mi a lacinia varius.

Morbi venenatis velit non interdum bibendum. Phasellus iaculis ornare elementum. Vivamus ac imperdiet ligula, eget ultrices diam. Vivamus sed tincidunt turpis. Integer eu auctor eros. Nullam finibus laoreet venenatis. Nunc ac sem cursus, faucibus sem a, aliquam turpis. Praesent bibendum magna vitae pulvinar fermentum. Mauris at sollicitudin orci, sed tempus leo. Fusce quis magna tristique, eleifend metus sed, sodales sapien. Suspendisse sit amet massa consequat nulla lacinia sagittis.

In ullamcorper ac eros eu efficitur. Donec a orci orci. Suspendisse egestas lacus in risus feugiat, eget maximus mauris condimentum. Duis ut ante et diam feugiat tincidunt. Morbi nec velit vitae sapien elementum sagittis. Fusce sed luctus massa, quis mollis dolor. Suspendisse facilisis orci et maximus feugiat. Sed quis congue erat. Cras porta efficitur magna, dictum sagittis urna laoreet semper. Etiam ac nunc orci.

Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum eget pretium elit. Pellentesque nec tempor augue. In velit ipsum, porttitor et vulputate et, sollicitudin ac mi. Aliquam placerat non magna quis auctor. Sed sagittis nisi vitae lectus semper, id semper quam consequat. Nulla posuere, ex in iaculis ultricies, nulla libero sollicitudin dui, ut tristique orci leo ut tortor. Fusce laoreet tincidunt lacus id posuere. Donec et metus sit amet diam lobortis aliquet. Aenean eget vestibulum mauris. Sed id est lacus. Aenean sed congue diam. Nullam pretium dictum elit non tempus. Suspendisse potenti. Pellentesque mattis lorem vitae dolor porttitor, vitae condimentum magna vulputate. Pellentesque bibendum lorem ut lorem dictum, ut venenatis orci tempus.

Aliquam id augue lobortis, pellentesque leo sit amet, bibendum est. Morbi quis ex nec eros efficitur imperdiet vitae id dolor. Pellentesque et lectus vitae augue pretium lobortis. Fusce ante orci, rutrum non ultrices sit amet, pellentesque vitae lacus. Proin at mattis risus. Suspendisse sem magna, ultrices at lectus at, laoreet lobortis tortor. Fusce viverra vestibulum dui id ultrices. Suspendisse eu rhoncus massa, eget sodales elit. Proin gravida dolor at sapien congue, sed vehicula nisi rutrum.', 'Quisque sagittis libero in sagittis imperdiet magna felis tincidunt erat sit amet sagittis libero risus sed diam', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2015-09-07 03:19:59', '2015-09-07 03:19:59', '', 24, 'http://9zero7films.dev/2015/09/24-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (93, 1, '2015-09-07 03:21:09', '2015-09-07 03:21:09', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam feugiat lorem at justo pellentesque, ac molestie nisi scelerisque. <a href="http://9zero7films.dev/">http://9zero7films.dev/</a> malesuada eu sapien. Maecenas id pulvinar sapien, sit amet porttitor enim. Pellentesque augue ligula, dapibus id interdum at, tempor ut diam. Aenean elit sapien, vestibulum egestas lorem vitae, ultricies finibus neque.
<ol>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ol>
Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam aliquet, dui vitae eleifend commodo, odio lectus euismod purus, at suscipit urna dui vel urna.
<h2>Sed eget sagittis ex, quis fermentum nibh pellentesque eleifend lectus id lacinia venenatis.</h2>
Suspendisse egestas nisi et fermentum luctus. Mauris sit amet nunc at sem auctor aliquam at a orci. Etiam vel nisi ultricies urna placerat faucibus at vitae diam. Duis sed cursus diam. Maecenas non tempus erat. Sed ut semper ante. <strong>Proin dignissim, est vitae ullamcorper blandit</strong>, erat nulla laoreet erat, quis euismod nulla augue vel velit.

Sed rutrum nibh ut viverra semper. Quisque lobortis ultricies facilisis. Nulla mauris neque, luctus sed sapien vitae, imperdiet laoreet lacus. Vivamus ex lectus, porta a velit a, ullamcorper auctor massa. Aenean vulputate erat at congue efficitur. Nullam varius egestas ex. <em>Fusce imperdiet tellus et luctus suscipit</em>. Nulla ut dui a massa mollis tincidunt. Pellentesque eu sem eu purus pellentesque feugiat non quis est. Nulla pretium, eros et faucibus molestie, nisi justo faucibus lacus, et venenatis ex augue nec nunc. Nunc id nunc massa.
<ul>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ul>
Nulla venenatis condimentum est, sed efficitur purus congue id. Vivamus a malesuada augue. Donec consequat interdum nisi nec laoreet. Morbi ultrices varius dui, vitae pulvinar nibh ornare sed. Donec semper gravida neque scelerisque bibendum. In eu rutrum mi. Quisque luctus tellus ut sem maximus vehicula. Nunc vel varius nisi, vitae venenatis erat. Cras mollis interdum enim, ac pretium ligula feugiat eu. In sed lectus ut ipsum euismod sodales eget sed augue.
<h3>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h3>
Ut mattis non enim quis pretium. Suspendisse blandit mollis libero sit amet commodo. Quisque sagittis iaculis risus congue rhoncus. Mauris fermentum elit sit amet nunc ullamcorper, non iaculis eros suscipit. Ut facilisis accumsan nunc. Vivamus finibus ut erat ut mollis. Quisque sed lacus enim. Nulla facilisi. Suspendisse non faucibus neque. Quisque lacus elit, sodales a laoreet sollicitudin, elementum sit amet tellus. Quisque metus lorem, ornare non aliquam sit amet, gravida et est. Maecenas quis malesuada ante. Mauris ac neque sit amet justo varius pulvinar quis et enim. Proin aliquet eget enim non ornare. Suspendisse cursus risus nec enim suscipit commodo ac a ligula.

Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean congue erat in mauris viverra eleifend in eget nunc. Aliquam orci erat, blandit quis lorem quis, pellentesque placerat justo. Sed arcu nunc, lacinia quis magna vel, tempor tempus urna. In sit amet mi dapibus, consectetur lorem ac, aliquet metus. Morbi faucibus vitae purus sit amet varius.
<h4>Etiam ut tincidunt sapien, eu gravida enim.</h4>
Vivamus congue leo tellus, id pellentesque justo finibus at. Maecenas rhoncus magna eget quam bibendum, ut iaculis massa facilisis. Sed sed condimentum tortor, eget tristique mauris. Morbi eu imperdiet nunc. In interdum non ipsum sit amet molestie. Aenean vel eros ornare, ornare elit et, tincidunt quam. Sed ac erat et nulla aliquam euismod eget eget quam. Quisque eget quam ligula. Suspendisse euismod dui vitae euismod tincidunt. Morbi accumsan purus sit amet mattis laoreet.

Suspendisse vitae nibh elementum sapien cursus hendrerit. Mauris varius tortor maximus, gravida lorem nec, commodo massa. Pellentesque malesuada erat quis lacus aliquet lacinia. Quisque vel est a augue porta scelerisque vitae vel risus. Pellentesque nec nisl luctus, dapibus orci a, ornare est.
<blockquote>Duis finibus, ante eu laoreet pulvinar, mauris nulla vulputate neque, nec lacinia mauris est in ipsum. Proin vestibulum blandit odio a pharetra. Pellentesque sed nulla ut arcu vestibulum facilisis. Ut vitae congue risus. Quisque mattis leo non ornare viverra. Aliquam eget massa neque. Cras nec placerat magna.</blockquote>
Duis eu pellentesque neque, non ullamcorper lectus. Etiam ut tellus congue turpis bibendum accumsan. Etiam non condimentum neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean tempus ipsum purus, vel consequat sapien feugiat ac. Maecenas vestibulum est vel arcu vestibulum, a tempor nulla maximus. Vivamus hendrerit dolor consequat dignissim dignissim.
<h5>Maecenas eu fringilla nisl, nec hendrerit est. Maecenas quis nibh eget ipsum bibendum facilisis.</h5>
Proin dapibus diam eget rhoncus efficitur. Duis mollis ante at bibendum pharetra. Praesent ultricies mollis accumsan. Nunc feugiat quis velit eget commodo. Praesent ultricies iaculis erat, nec fermentum est pharetra non. Nulla facilisi. Sed sollicitudin mauris ac magna scelerisque vulputate. Etiam sit amet nisi vel eros finibus sodales. Nullam egestas fringilla eros a aliquet. Mauris et mollis erat, in eleifend turpis.

Vivamus sit amet neque ut arcu maximus gravida. Mauris sodales quam vel finibus auctor. Vestibulum eget nulla turpis. Cras eros augue, semper nec malesuada vel, elementum sed sem. Aenean ac maximus ex, mattis dictum enim. Sed ultrices leo in tellus iaculis imperdiet. Morbi auctor arcu nec elit interdum dapibus. Integer sed leo odio. Aliquam nec ultricies risus, vel porta lectus. Sed accumsan placerat leo, at aliquam felis rhoncus aliquam. Curabitur in sodales massa. Aenean dui est, commodo ac venenatis et, aliquam eu neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse interdum enim quis volutpat sollicitudin. Morbi bibendum est non egestas rhoncus. Cras tempor sagittis nibh sit amet pharetra.

Quisque sagittis, libero in sagittis imperdiet, magna felis tincidunt erat, sit amet sagittis libero risus sed diam. Etiam vestibulum non purus in gravida. Nulla facilisi. Nunc lectus purus, gravida quis ligula vehicula, pulvinar venenatis nibh. Aenean hendrerit eleifend lacus, vel ultrices nisi ultricies eget. Mauris neque quam, laoreet varius maximus id, auctor sit amet ante. Maecenas sed felis sit amet risus varius rutrum nec eu enim. Ut commodo sollicitudin purus ut auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras volutpat tristique neque sit amet pulvinar. Cras sed sem ac dolor ornare sagittis. Morbi augue augue, gravida vitae mi sit amet, ornare tempor libero. Donec sagittis fermentum magna eget aliquam. Etiam fermentum mi a lacinia varius.

Morbi venenatis velit non interdum bibendum. Phasellus iaculis ornare elementum. Vivamus ac imperdiet ligula, eget ultrices diam. Vivamus sed tincidunt turpis. Integer eu auctor eros. Nullam finibus laoreet venenatis. Nunc ac sem cursus, faucibus sem a, aliquam turpis. Praesent bibendum magna vitae pulvinar fermentum. Mauris at sollicitudin orci, sed tempus leo. Fusce quis magna tristique, eleifend metus sed, sodales sapien. Suspendisse sit amet massa consequat nulla lacinia sagittis.

In ullamcorper ac eros eu efficitur. Donec a orci orci. Suspendisse egestas lacus in risus feugiat, eget maximus mauris condimentum. Duis ut ante et diam feugiat tincidunt. Morbi nec velit vitae sapien elementum sagittis. Fusce sed luctus massa, quis mollis dolor. Suspendisse facilisis orci et maximus feugiat. Sed quis congue erat. Cras porta efficitur magna, dictum sagittis urna laoreet semper. Etiam ac nunc orci.
<h6>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.</h6>
Vestibulum eget pretium elit. Pellentesque nec tempor augue. In velit ipsum, porttitor et vulputate et, sollicitudin ac mi. Aliquam placerat non magna quis auctor. Sed sagittis nisi vitae lectus semper, id semper quam consequat. Nulla posuere, ex in iaculis ultricies, nulla libero sollicitudin dui, ut tristique orci leo ut tortor. Fusce laoreet tincidunt lacus id posuere. Donec et metus sit amet diam lobortis aliquet. Aenean eget vestibulum mauris. Sed id est lacus. Aenean sed congue diam. Nullam pretium dictum elit non tempus. Suspendisse potenti. Pellentesque mattis lorem vitae dolor porttitor, vitae condimentum magna vulputate. Pellentesque bibendum lorem ut lorem dictum, ut venenatis orci tempus.

Aliquam id augue lobortis, pellentesque leo sit amet, bibendum est. Morbi quis ex nec eros efficitur imperdiet vitae id dolor. Pellentesque et lectus vitae augue pretium lobortis. Fusce ante orci, rutrum non ultrices sit amet, pellentesque vitae lacus. Proin at mattis risus. Suspendisse sem magna, ultrices at lectus at, laoreet lobortis tortor. Fusce viverra vestibulum dui id ultrices. Suspendisse eu rhoncus massa, eget sodales elit. Proin gravida dolor at sapien congue, sed vehicula nisi rutrum.', 'Quisque sagittis libero in sagittis imperdiet magna felis tincidunt erat sit amet sagittis libero risus sed diam', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2015-09-07 03:21:09', '2015-09-07 03:21:09', '', 24, 'http://9zero7films.dev/2015/09/24-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (94, 1, '2015-09-07 03:51:54', '2015-09-07 03:51:54', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam feugiat lorem at justo pellentesque, ac molestie nisi scelerisque. <a href="http://9zero7films.dev/">http://9zero7films.dev/</a> malesuada eu sapien. Maecenas id pulvinar sapien, sit amet porttitor enim. Pellentesque augue ligula, dapibus id interdum at, tempor ut diam. Aenean elit sapien, vestibulum egestas lorem vitae, ultricies finibus neque.
<ol>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ol>
Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam aliquet, dui vitae eleifend commodo, odio lectus euismod purus, at suscipit urna dui vel urna.
<h2>Sed eget sagittis ex, quis fermentum nibh pellentesque eleifend lectus id lacinia venenatis.</h2>
Suspendisse egestas nisi et fermentum luctus. Mauris sit amet nunc at sem auctor aliquam at a orci. Etiam vel nisi ultricies urna placerat faucibus at vitae diam. Duis sed cursus diam. Maecenas non tempus erat. Sed ut semper ante. <strong>Proin dignissim, est vitae ullamcorper blandit</strong>, erat nulla laoreet erat, quis euismod nulla augue vel velit.

Sed rutrum nibh ut viverra semper. Quisque lobortis ultricies facilisis. Nulla mauris neque, luctus sed sapien vitae, imperdiet laoreet lacus. Vivamus ex lectus, porta a velit a, ullamcorper auctor massa. Aenean vulputate erat at congue efficitur. Nullam varius egestas ex. <em>Fusce imperdiet tellus et luctus suscipit</em>. Nulla ut dui a massa mollis tincidunt. Pellentesque eu sem eu purus pellentesque feugiat non quis est. Nulla pretium, eros et faucibus molestie, nisi justo faucibus lacus, et venenatis ex augue nec nunc. Nunc id nunc massa.
<ul>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ul>
Nulla venenatis condimentum est, sed efficitur purus congue id. Vivamus a malesuada augue. Donec consequat interdum nisi nec laoreet. Morbi ultrices varius dui, vitae pulvinar nibh ornare sed. Donec semper gravida neque scelerisque bibendum. In eu rutrum mi. Quisque luctus tellus ut sem maximus vehicula. Nunc vel varius nisi, vitae venenatis erat. Cras mollis interdum enim, ac pretium ligula feugiat eu. In sed lectus ut ipsum euismod sodales eget sed augue.
<h3>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h3>
Ut mattis non enim quis pretium. Suspendisse blandit mollis libero sit amet commodo. Quisque sagittis iaculis risus congue rhoncus. Mauris fermentum elit sit amet nunc ullamcorper, non iaculis eros suscipit. Ut facilisis accumsan nunc. Vivamus finibus ut erat ut mollis. Quisque sed lacus enim. Nulla facilisi. Suspendisse non faucibus neque. Quisque lacus elit, sodales a laoreet sollicitudin, elementum sit amet tellus. Quisque metus lorem, ornare non aliquam sit amet, gravida et est. Maecenas quis malesuada ante. Mauris ac neque sit amet justo varius pulvinar quis et enim. Proin aliquet eget enim non ornare. Suspendisse cursus risus nec enim suscipit commodo ac a ligula.

Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean congue erat in mauris viverra eleifend in eget nunc. Aliquam orci erat, blandit quis lorem quis, pellentesque placerat justo. Sed arcu nunc, lacinia quis magna vel, tempor tempus urna. In sit amet mi dapibus, consectetur lorem ac, aliquet metus. Morbi faucibus vitae purus sit amet varius.

Etiam ut tincidunt sapien, eu gravida enim vivamus congue leo tellus, id pellentesque justo finibus at. Maecenas rhoncus magna eget quam bibendum, ut iaculis massa facilisis. Sed sed condimentum tortor, eget tristique mauris. Morbi eu imperdiet nunc. In interdum non ipsum sit amet molestie. Aenean vel eros ornare, ornare elit et, tincidunt quam. Sed ac erat et nulla aliquam euismod eget eget quam. Quisque eget quam ligula. Suspendisse euismod dui vitae euismod tincidunt. Morbi accumsan purus sit amet mattis laoreet.

Suspendisse vitae nibh elementum sapien cursus hendrerit. Mauris varius tortor maximus, gravida lorem nec, commodo massa. Pellentesque malesuada erat quis lacus aliquet lacinia. Quisque vel est a augue porta scelerisque vitae vel risus. Pellentesque nec nisl luctus, dapibus orci a, ornare est.
<blockquote>Duis finibus, ante eu laoreet pulvinar, mauris nulla vulputate neque, nec lacinia mauris est in ipsum. Proin vestibulum blandit odio a pharetra. Pellentesque sed nulla ut arcu vestibulum facilisis. Ut vitae congue risus. Quisque mattis leo non ornare viverra. Aliquam eget massa neque. Cras nec placerat magna.</blockquote>
Duis eu pellentesque neque, non ullamcorper lectus. Etiam ut tellus congue turpis bibendum accumsan. Etiam non condimentum neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean tempus ipsum purus, vel consequat sapien feugiat ac. Maecenas vestibulum est vel arcu vestibulum, a tempor nulla maximus. Vivamus hendrerit dolor consequat dignissim dignissim.

Maecenas eu fringilla nisl, nec hendrerit est. Maecenas quis nibh eget ipsum bibendum facilisis. Proin dapibus diam eget rhoncus efficitur. Duis mollis ante at bibendum pharetra. Praesent ultricies mollis accumsan. Nunc feugiat quis velit eget commodo. Praesent ultricies iaculis erat, nec fermentum est pharetra non. Nulla facilisi. Sed sollicitudin mauris ac magna scelerisque vulputate. Etiam sit amet nisi vel eros finibus sodales. Nullam egestas fringilla eros a aliquet. Mauris et mollis erat, in eleifend turpis.

Vivamus sit amet neque ut arcu maximus gravida. Mauris sodales quam vel finibus auctor. Vestibulum eget nulla turpis. Cras eros augue, semper nec malesuada vel, elementum sed sem. Aenean ac maximus ex, mattis dictum enim. Sed ultrices leo in tellus iaculis imperdiet. Morbi auctor arcu nec elit interdum dapibus. Integer sed leo odio. Aliquam nec ultricies risus, vel porta lectus. Sed accumsan placerat leo, at aliquam felis rhoncus aliquam. Curabitur in sodales massa. Aenean dui est, commodo ac venenatis et, aliquam eu neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse interdum enim quis volutpat sollicitudin. Morbi bibendum est non egestas rhoncus. Cras tempor sagittis nibh sit amet pharetra.

Quisque sagittis, libero in sagittis imperdiet, magna felis tincidunt erat, sit amet sagittis libero risus sed diam. Etiam vestibulum non purus in gravida. Nulla facilisi. Nunc lectus purus, gravida quis ligula vehicula, pulvinar venenatis nibh. Aenean hendrerit eleifend lacus, vel ultrices nisi ultricies eget. Mauris neque quam, laoreet varius maximus id, auctor sit amet ante. Maecenas sed felis sit amet risus varius rutrum nec eu enim. Ut commodo sollicitudin purus ut auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras volutpat tristique neque sit amet pulvinar. Cras sed sem ac dolor ornare sagittis. Morbi augue augue, gravida vitae mi sit amet, ornare tempor libero. Donec sagittis fermentum magna eget aliquam. Etiam fermentum mi a lacinia varius.

Morbi venenatis velit non interdum bibendum. Phasellus iaculis ornare elementum. Vivamus ac imperdiet ligula, eget ultrices diam. Vivamus sed tincidunt turpis. Integer eu auctor eros. Nullam finibus laoreet venenatis. Nunc ac sem cursus, faucibus sem a, aliquam turpis. Praesent bibendum magna vitae pulvinar fermentum. Mauris at sollicitudin orci, sed tempus leo. Fusce quis magna tristique, eleifend metus sed, sodales sapien. Suspendisse sit amet massa consequat nulla lacinia sagittis.

In ullamcorper ac eros eu efficitur. Donec a orci orci. Suspendisse egestas lacus in risus feugiat, eget maximus mauris condimentum. Duis ut ante et diam feugiat tincidunt. Morbi nec velit vitae sapien elementum sagittis. Fusce sed luctus massa, quis mollis dolor. Suspendisse facilisis orci et maximus feugiat. Sed quis congue erat. Cras porta efficitur magna, dictum sagittis urna laoreet semper. Etiam ac nunc orci.
<h6>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.</h6>
Vestibulum eget pretium elit. Pellentesque nec tempor augue. In velit ipsum, porttitor et vulputate et, sollicitudin ac mi. Aliquam placerat non magna quis auctor. Sed sagittis nisi vitae lectus semper, id semper quam consequat. Nulla posuere, ex in iaculis ultricies, nulla libero sollicitudin dui, ut tristique orci leo ut tortor. Fusce laoreet tincidunt lacus id posuere. Donec et metus sit amet diam lobortis aliquet. Aenean eget vestibulum mauris. Sed id est lacus. Aenean sed congue diam. Nullam pretium dictum elit non tempus. Suspendisse potenti. Pellentesque mattis lorem vitae dolor porttitor, vitae condimentum magna vulputate. Pellentesque bibendum lorem ut lorem dictum, ut venenatis orci tempus.

Aliquam id augue lobortis, pellentesque leo sit amet, bibendum est. Morbi quis ex nec eros efficitur imperdiet vitae id dolor. Pellentesque et lectus vitae augue pretium lobortis. Fusce ante orci, rutrum non ultrices sit amet, pellentesque vitae lacus. Proin at mattis risus. Suspendisse sem magna, ultrices at lectus at, laoreet lobortis tortor. Fusce viverra vestibulum dui id ultrices. Suspendisse eu rhoncus massa, eget sodales elit. Proin gravida dolor at sapien congue, sed vehicula nisi rutrum.', 'Quisque sagittis libero in sagittis imperdiet magna felis tincidunt erat sit amet sagittis libero risus sed diam', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2015-09-07 03:51:54', '2015-09-07 03:51:54', '', 24, 'http://9zero7films.dev/2015/09/24-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (95, 1, '2015-09-07 04:52:04', '2015-09-07 04:52:04', '<ol>

	<li><label for="name">Name</label>[text name id:name]</li>

	<li><label for="email-address">Email Address <span class="required">*</span></label>[email* email-address id:email-address]</li>

	<li><label for="subject">Subject</label>[select subject id:subject include_blank "Subject Item One" "Subject Item Two" "Subject Item Three"]</li>

	<li><label for="message">Message <span class="required">*</span></label>[textarea* message id:message]</li>

</ol>

<div class="submit">[submit "Send Message"]</div>
[your-subject]
[your-name] <wordpress@9zero7films.dev>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on 9ZERO7 Films (http://9zero7films.dev)
jlcolema@me.com
Reply-To: [your-email]




[your-subject]
9ZERO7 Films <wordpress@9zero7films.dev>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on 9ZERO7 Films (http://9zero7films.dev)
[your-email]
Reply-To: jlcolema@me.com



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill in the required field.
This input is too long.
This input is too short.
Your entered code is incorrect.
Number format seems invalid.
This number is too small.
This number is too large.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.
Your answer is not correct.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2015-09-07 06:09:32', '2015-09-07 06:09:32', '', 0, 'http://9zero7films.dev/?post_type=wpcf7_contact_form&#038;p=95', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (96, 1, '2015-09-07 04:54:48', '2015-09-07 04:54:48', '<ol>

	<li><label for="name">Name <span class="required">*</span></label>[text* name id:name placeholder "Name"]</li>

	<li><label for="email-address">Email Address <span class="required">*</span></label>[email* email-address id:email-address placeholder "Email Address"]</li>

</ol>

<div class="submit">[submit "Sign Up"]</div>
Newsletter Signup
[name] <wordpress@9zero7films.dev>
From: [name] <[email-address]>


--

This e-mail was sent from a contact form on 9ZERO7 Films.
jlcolema@me.com
Reply-To: [name]




[your-subject]
9ZERO7 Films <wordpress@9zero7films.dev>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on 9ZERO7 Films (http://9zero7films.dev)
[your-email]
Reply-To: jlcolema@me.com



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill in the required field.
This input is too long.
This input is too short.
Your entered code is incorrect.
Number format seems invalid.
This number is too small.
This number is too large.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.
Your answer is not correct.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.', 'Newsletter', '', 'publish', 'closed', 'closed', '', 'contact_copy', '', '', '2015-09-12 01:48:32', '2015-09-12 01:48:32', '', 0, 'http://9zero7films.dev/?post_type=wpcf7_contact_form&#038;p=96', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (97, 1, '2015-09-07 04:55:26', '2015-09-07 04:55:26', '<ol>

	<li><label for="name">Name</label>[text name id:name]</li>

	<li><label for="email-address">Email Address <span class="required">*</span></label>[email* email-address id:email-address]</li>

</ol>

<div class="submit">[submit "Send"]</div>
[your-subject]
[your-name] <wordpress@9zero7films.dev>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on 9ZERO7 Films (http://9zero7films.dev)
jlcolema@me.com
Reply-To: [your-email]




[your-subject]
9ZERO7 Films <wordpress@9zero7films.dev>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on 9ZERO7 Films (http://9zero7films.dev)
[your-email]
Reply-To: jlcolema@me.com



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill in the required field.
This input is too long.
This input is too short.
Your entered code is incorrect.
Number format seems invalid.
This number is too small.
This number is too large.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.
Your answer is not correct.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.', 'Class', '', 'publish', 'closed', 'closed', '', 'contact_copy-2', '', '', '2015-09-07 06:10:30', '2015-09-07 06:10:30', '', 0, 'http://9zero7films.dev/?post_type=wpcf7_contact_form&#038;p=97', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (98, 1, '2015-09-07 04:55:45', '2015-09-07 04:55:45', '<ol>

	<li><label for="company-name">Company Name</label>[text name id:company-name]</li>

	<li><label for="primary-contact">Primary Contact</label>[text name id:primary-contact]</li>

	<li><label for="phone-number">Phone Number <span class="required">*</span></label>[tel* phone-number id:phone-number]</li>

	<li><label for="email-address">Email Address <span class="required">*</span></label>[email* email-address id:email-address]</li>

</ol>

<div class="submit">[submit "Send"]</div>
[your-subject]
[your-name] <wordpress@9zero7films.dev>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on 9ZERO7 Films (http://9zero7films.dev)
jlcolema@me.com
Reply-To: [your-email]




[your-subject]
9ZERO7 Films <wordpress@9zero7films.dev>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on 9ZERO7 Films (http://9zero7films.dev)
[your-email]
Reply-To: jlcolema@me.com



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill in the required field.
This input is too long.
This input is too short.
Your entered code is incorrect.
Number format seems invalid.
This number is too small.
This number is too large.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.
Your answer is not correct.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.', 'Sponsor', '', 'publish', 'closed', 'closed', '', 'class_copy', '', '', '2015-09-07 06:13:54', '2015-09-07 06:13:54', '', 0, 'http://9zero7films.dev/?post_type=wpcf7_contact_form&#038;p=98', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (99, 1, '2015-09-07 07:17:32', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-09-07 07:17:32', '0000-00-00 00:00:00', '', 0, 'http://9zero7films.dev/?p=99', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (100, 1, '2015-09-07 07:17:48', '2015-09-07 07:17:48', ' ', '', '', 'publish', 'closed', 'closed', '', '100', '', '', '2015-09-07 07:18:43', '2015-09-07 07:18:43', '', 0, 'http://9zero7films.dev/?p=100', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (101, 1, '2015-09-07 07:17:48', '2015-09-07 07:17:48', ' ', '', '', 'publish', 'closed', 'closed', '', '101', '', '', '2015-09-07 07:18:44', '2015-09-07 07:18:44', '', 0, 'http://9zero7films.dev/?p=101', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (102, 1, '2015-09-07 07:17:48', '2015-09-07 07:17:48', ' ', '', '', 'publish', 'closed', 'closed', '', '102', '', '', '2015-09-07 07:18:44', '2015-09-07 07:18:44', '', 0, 'http://9zero7films.dev/?p=102', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (103, 1, '2015-09-07 07:17:48', '2015-09-07 07:17:48', ' ', '', '', 'publish', 'closed', 'closed', '', '103', '', '', '2015-09-07 07:18:44', '2015-09-07 07:18:44', '', 0, 'http://9zero7films.dev/?p=103', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (104, 1, '2015-09-07 07:17:49', '2015-09-07 07:17:49', ' ', '', '', 'publish', 'closed', 'closed', '', '104', '', '', '2015-09-07 07:18:44', '2015-09-07 07:18:44', '', 0, 'http://9zero7films.dev/?p=104', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (105, 1, '2015-09-07 07:17:49', '2015-09-07 07:17:49', ' ', '', '', 'publish', 'closed', 'closed', '', '105', '', '', '2015-09-07 07:18:44', '2015-09-07 07:18:44', '', 0, 'http://9zero7films.dev/?p=105', 6, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (106, 1, '2015-09-07 07:17:49', '2015-09-07 07:17:49', ' ', '', '', 'publish', 'closed', 'closed', '', '106', '', '', '2015-09-07 07:18:44', '2015-09-07 07:18:44', '', 0, 'http://9zero7films.dev/?p=106', 7, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (111, 1, '2015-09-07 08:00:00', '2015-09-07 08:00:00', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Studio', 'contact_studio', 'publish', 'closed', 'closed', '', 'field_55ed43dd6efb1', '', '', '2015-09-11 19:43:04', '2015-09-11 19:43:04', '', 62, 'http://9zero7films.dev/?post_type=acf-field&#038;p=111', 2, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (112, 1, '2015-09-07 08:01:12', '2015-09-07 08:01:12', 'a:9:{s:4:"type";s:10:"google_map";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:10:"center_lat";s:0:"";s:10:"center_lng";s:0:"";s:4:"zoom";s:0:"";s:6:"height";s:0:"";}', 'Map', 'contact_map', 'publish', 'closed', 'closed', '', 'field_55ed4426dada3', '', '', '2015-09-07 08:01:12', '2015-09-07 08:01:12', '', 62, 'http://9zero7films.dev/?post_type=acf-field&p=112', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (113, 1, '2015-09-07 09:36:20', '2015-09-07 09:36:20', '', 'Class One', '', 'publish', 'closed', 'closed', '', 'class-one', '', '', '2015-09-11 02:10:47', '2015-09-11 02:10:47', '', 0, 'http://9zero7films.dev/?post_type=class&#038;p=113', 0, 'class', '', 0) ; 
INSERT INTO `wp_posts` VALUES (114, 1, '2015-09-10 20:27:44', '2015-09-10 20:27:44', ' ', '', '', 'publish', 'closed', 'closed', '', '114', '', '', '2015-09-11 20:14:00', '2015-09-11 20:14:00', '', 0, 'http://9zero7films.dev/?p=114', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (115, 1, '2015-09-10 20:46:57', '2015-09-10 20:46:57', 'a:12:{s:4:"type";s:8:"textarea";s:12:"instructions";s:60:"A nice, short, descriptive paragraph of the overall article.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";i:4;s:9:"new_lines";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Excerpt', 'article_excerpt', 'publish', 'closed', 'closed', '', 'field_55f1e92e49b8f', '', '', '2015-09-12 03:00:06', '2015-09-12 03:00:06', '', 60, 'http://9zero7films.dev/?post_type=acf-field&#038;p=115', 1, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (116, 1, '2015-09-10 20:46:57', '2015-09-10 20:46:57', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'Content', 'article_content', 'publish', 'closed', 'closed', '', 'field_55f1e9b549b90', '', '', '2015-09-12 03:00:06', '2015-09-12 03:00:06', '', 60, 'http://9zero7films.dev/?post_type=acf-field&#038;p=116', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (117, 1, '2015-09-10 20:46:57', '2015-09-10 20:46:57', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"55f1e9c64dcfe";s:13:"default_value";s:0:"";s:4:"tabs";s:6:"visual";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:0;}', 'Text', 'article_text', 'publish', 'closed', 'closed', '', 'field_55f1e9ef49b91', '', '', '2015-09-10 20:58:01', '2015-09-10 20:58:01', '', 116, 'http://9zero7films.dev/?post_type=acf-field&#038;p=117', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (118, 1, '2015-09-10 20:46:57', '2015-09-10 20:46:57', 'a:16:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"55f1ea6b49b92";s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:13:"gif, jpg, png";}', 'Image', 'article_image', 'publish', 'closed', 'closed', '', 'field_55f1ea8149b93', '', '', '2015-09-10 20:46:57', '2015-09-10 20:46:57', '', 116, 'http://9zero7films.dev/?post_type=acf-field&p=118', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (119, 1, '2015-09-10 20:46:57', '2015-09-10 20:46:57', 'a:15:{s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"55f1ea6b49b92";s:7:"choices";a:3:{s:10:"Full Width";s:10:"Full Width";s:10:"Float Left";s:10:"Float Left";s:11:"Float Right";s:11:"Float Right";}s:13:"default_value";a:0:{}s:10:"allow_null";i:0;s:8:"multiple";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:11:"placeholder";s:0:"";s:8:"disabled";i:0;s:8:"readonly";i:0;}', 'Alignment', 'article_image_alignment', 'publish', 'closed', 'closed', '', 'field_55f1ead349b94', '', '', '2015-09-10 20:46:57', '2015-09-10 20:46:57', '', 116, 'http://9zero7films.dev/?post_type=acf-field&p=119', 1, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (120, 1, '2015-09-10 20:46:57', '2015-09-10 20:46:57', 'a:8:{s:4:"type";s:6:"oembed";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"55f1eb6849b95";s:5:"width";s:0:"";s:6:"height";s:0:"";}', 'Video', 'article_video', 'publish', 'closed', 'closed', '', 'field_55f1eb8549b96', '', '', '2015-09-10 20:46:57', '2015-09-10 20:46:57', '', 116, 'http://9zero7films.dev/?post_type=acf-field&p=120', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (121, 1, '2015-09-10 20:46:57', '2015-09-10 20:46:57', 'a:15:{s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"55f1eb6849b95";s:7:"choices";a:3:{s:10:"Full Width";s:10:"Full Width";s:10:"Float Left";s:10:"Float Left";s:11:"Float Right";s:11:"Float Right";}s:13:"default_value";a:0:{}s:10:"allow_null";i:0;s:8:"multiple";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:11:"placeholder";s:0:"";s:8:"disabled";i:0;s:8:"readonly";i:0;}', 'Alignment', 'article_video_alignment', 'publish', 'closed', 'closed', '', 'field_55f1eba549b97', '', '', '2015-09-10 20:46:57', '2015-09-10 20:46:57', '', 116, 'http://9zero7films.dev/?post_type=acf-field&p=121', 1, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (122, 1, '2015-09-10 20:46:57', '2015-09-10 20:46:57', 'a:13:{s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"parent_layout";s:13:"55f1ebd749b98";s:9:"post_type";a:1:{i:0;s:11:"testimonial";}s:8:"taxonomy";a:0:{}s:7:"filters";a:1:{i:0;s:6:"search";}s:8:"elements";s:0:"";s:3:"min";s:0:"";s:3:"max";i:1;s:13:"return_format";s:6:"object";}', 'Testimonial', 'article_testimonial', 'publish', 'closed', 'closed', '', 'field_55f1ebf149b99', '', '', '2015-09-10 20:46:57', '2015-09-10 20:46:57', '', 116, 'http://9zero7films.dev/?post_type=acf-field&p=122', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (123, 1, '2015-09-10 20:47:30', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-09-10 20:47:30', '0000-00-00 00:00:00', '', 0, 'http://9zero7films.dev/?p=123', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (124, 1, '2015-09-10 20:47:54', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-09-10 20:47:54', '0000-00-00 00:00:00', '', 0, 'http://9zero7films.dev/?p=124', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (125, 1, '2015-09-10 20:49:12', '2015-09-10 20:49:12', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:49:"A size of 520px W &times; 360px H is recommended.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:3:"jpg";}', 'Thumbnail', 'article_thumbnail', 'publish', 'closed', 'closed', '', 'field_55f1eca1428f9', '', '', '2015-09-12 02:57:08', '2015-09-12 02:57:08', '', 60, 'http://9zero7films.dev/?post_type=acf-field&#038;p=125', 3, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (126, 1, '2015-09-10 20:49:30', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-09-10 20:49:30', '0000-00-00 00:00:00', '', 0, 'http://9zero7films.dev/?p=126', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (127, 1, '2015-09-10 20:50:44', '2015-09-10 20:50:44', 'a:13:{s:4:"type";s:8:"taxonomy";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:8:"taxonomy";s:8:"category";s:10:"field_type";s:8:"checkbox";s:10:"allow_null";i:1;s:8:"add_term";i:1;s:10:"save_terms";i:1;s:10:"load_terms";i:1;s:13:"return_format";s:2:"id";s:8:"multiple";i:0;}', 'Categories', 'article_categories', 'publish', 'closed', 'closed', '', 'field_55f1ece32ad0d', '', '', '2015-09-12 02:57:08', '2015-09-12 02:57:08', '', 60, 'http://9zero7films.dev/?post_type=acf-field&#038;p=127', 2, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (128, 1, '2015-09-10 20:50:51', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-09-10 20:50:51', '0000-00-00 00:00:00', '', 0, 'http://9zero7films.dev/?p=128', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (129, 1, '2015-09-10 20:51:59', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-09-10 20:51:59', '0000-00-00 00:00:00', '', 0, 'http://9zero7films.dev/?p=129', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (130, 1, '2015-09-10 20:52:33', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-09-10 20:52:33', '0000-00-00 00:00:00', '', 0, 'http://9zero7films.dev/?p=130', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (131, 1, '2015-09-10 20:53:11', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-09-10 20:53:11', '0000-00-00 00:00:00', '', 0, 'http://9zero7films.dev/?p=131', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (132, 1, '2015-09-10 20:54:18', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-09-10 20:54:18', '0000-00-00 00:00:00', '', 0, 'http://9zero7films.dev/?p=132', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (133, 1, '2015-09-10 20:56:33', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-09-10 20:56:33', '0000-00-00 00:00:00', '', 0, 'http://9zero7films.dev/?p=133', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (134, 1, '2015-09-10 20:57:24', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-09-10 20:57:24', '0000-00-00 00:00:00', '', 0, 'http://9zero7films.dev/?p=134', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (135, 1, '2015-08-13 21:09:55', '2015-08-13 21:09:55', '', 'Article Thirteen', '', 'publish', 'closed', 'closed', '', 'article-thirteen', '', '', '2015-09-11 02:44:02', '2015-09-11 02:44:02', '', 0, 'http://9zero7films.dev/?p=135', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (136, 1, '2015-09-10 21:02:52', '2015-09-10 21:02:52', '', '', '', 'inherit', 'closed', 'closed', '', 'article-image-float-left', '', '', '2015-09-10 21:03:04', '2015-09-10 21:03:04', '', 135, 'http://9zero7films.dev/wp-content/uploads/article-image-float-left.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (137, 1, '2015-09-10 21:05:10', '2015-09-10 21:05:10', '', '', '', 'inherit', 'closed', 'closed', '', 'article-image-float-right', '', '', '2015-09-10 21:05:14', '2015-09-10 21:05:14', '', 135, 'http://9zero7films.dev/wp-content/uploads/article-image-float-right.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (138, 1, '2015-09-10 21:08:31', '2015-09-10 21:08:31', '', 'article-thumbnail', '', 'inherit', 'closed', 'closed', '', 'article-thumbnail', '', '', '2015-09-10 21:08:59', '2015-09-10 21:08:59', '', 135, 'http://9zero7films.dev/wp-content/uploads/article-thumbnail.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (139, 1, '2015-09-10 21:09:55', '2015-09-10 21:09:55', '', '', '', 'inherit', 'closed', 'closed', '', '135-revision-v1', '', '', '2015-09-10 21:09:55', '2015-09-10 21:09:55', '', 135, 'http://9zero7films.dev/2015/09/135-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (140, 1, '2015-09-10 21:10:34', '2015-09-10 21:10:34', '', 'Example Article One', '', 'inherit', 'closed', 'closed', '', '135-revision-v1', '', '', '2015-09-10 21:10:34', '2015-09-10 21:10:34', '', 135, 'http://9zero7films.dev/2015/09/135-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (141, 1, '2015-09-10 21:11:15', '2015-09-10 21:11:15', '', 'article-image-full-width', '', 'inherit', 'closed', 'closed', '', 'article-image-full-width', '', '', '2015-09-10 21:11:15', '2015-09-10 21:11:15', '', 135, 'http://9zero7films.dev/wp-content/uploads/article-image-full-width.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (142, 1, '2015-09-10 21:11:29', '2015-09-10 21:11:29', '', 'Example Article One', '', 'inherit', 'closed', 'closed', '', '135-revision-v1', '', '', '2015-09-10 21:11:29', '2015-09-10 21:11:29', '', 135, 'http://9zero7films.dev/2015/09/135-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (143, 1, '2015-09-10 21:13:10', '2015-09-10 21:13:10', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"class";}}}s:8:"position";s:6:"normal";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Class', 'class', 'publish', 'closed', 'closed', '', 'group_55f1f25618cc5', '', '', '2015-09-10 21:13:10', '2015-09-10 21:13:10', '', 0, 'http://9zero7films.dev/?post_type=acf-field-group&#038;p=143', 1, 'acf-field-group', '', 0) ; 
INSERT INTO `wp_posts` VALUES (144, 1, '2015-09-10 21:13:32', '2015-09-10 21:13:32', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:3:"faq";}}}s:8:"position";s:6:"normal";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'FAQ', 'faq', 'publish', 'closed', 'closed', '', 'group_55f1f26ccd2fc', '', '', '2015-09-11 21:13:41', '2015-09-11 21:13:41', '', 0, 'http://9zero7films.dev/?post_type=acf-field-group&#038;p=144', 1, 'acf-field-group', '', 0) ; 
INSERT INTO `wp_posts` VALUES (145, 1, '2015-09-10 21:13:51', '2015-09-10 21:13:51', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:7:"sponsor";}}}s:8:"position";s:6:"normal";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Sponsor', 'sponsor', 'publish', 'closed', 'closed', '', 'group_55f1f282cab79', '', '', '2015-09-10 21:23:44', '2015-09-10 21:23:44', '', 0, 'http://9zero7films.dev/?post_type=acf-field-group&#038;p=145', 1, 'acf-field-group', '', 0) ; 
INSERT INTO `wp_posts` VALUES (146, 1, '2015-09-10 21:14:14', '2015-09-10 21:14:14', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:11:"testimonial";}}}s:8:"position";s:6:"normal";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Testimonial', 'testimonial', 'publish', 'closed', 'closed', '', 'group_55f1f29822023', '', '', '2015-09-10 21:22:02', '2015-09-10 21:22:02', '', 0, 'http://9zero7films.dev/?post_type=acf-field-group&#038;p=146', 1, 'acf-field-group', '', 0) ; 
INSERT INTO `wp_posts` VALUES (147, 1, '2015-09-10 21:17:58', '2015-09-10 21:17:58', 'a:12:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Quote', 'testimonial_quote', 'publish', 'closed', 'closed', '', 'field_55f1f2d0b6d9f', '', '', '2015-09-10 21:22:02', '2015-09-10 21:22:02', '', 146, 'http://9zero7films.dev/?post_type=acf-field&#038;p=147', 1, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (148, 1, '2015-09-10 21:17:58', '2015-09-10 21:17:58', 'a:14:{s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:4:{s:7:"Student";s:7:"Student";s:6:"Parent";s:6:"Parent";s:7:"Sponsor";s:7:"Sponsor";s:5:"Donor";s:5:"Donor";}s:13:"default_value";a:0:{}s:10:"allow_null";i:1;s:8:"multiple";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:11:"placeholder";s:0:"";s:8:"disabled";i:0;s:8:"readonly";i:0;}', 'Title', 'testimonial_title', 'publish', 'closed', 'closed', '', 'field_55f1f31db6da0', '', '', '2015-09-10 21:21:04', '2015-09-10 21:21:04', '', 146, 'http://9zero7films.dev/?post_type=acf-field&#038;p=148', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (149, 1, '2015-09-10 21:21:43', '2015-09-10 21:21:43', '', 'Jane Appleseed', '', 'publish', 'closed', 'closed', '', 'jane-appleseed', '', '', '2015-09-10 21:21:43', '2015-09-10 21:21:43', '', 0, 'http://9zero7films.dev/?post_type=testimonial&#038;p=149', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (150, 1, '2015-09-10 21:22:57', '2015-09-10 21:22:57', '', 'Example Article One', '', 'inherit', 'closed', 'closed', '', '135-revision-v1', '', '', '2015-09-10 21:22:57', '2015-09-10 21:22:57', '', 135, 'http://9zero7films.dev/2015/09/135-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (151, 1, '2015-09-10 21:23:44', '2015-09-10 21:23:44', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'URL', 'sponsor_url', 'publish', 'closed', 'closed', '', 'field_55f1f4cad113a', '', '', '2015-09-10 21:23:44', '2015-09-10 21:23:44', '', 145, 'http://9zero7films.dev/?post_type=acf-field&p=151', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (152, 1, '2015-09-10 21:24:04', '2015-09-10 21:24:04', '', 'Sponsor One', '', 'publish', 'closed', 'closed', '', 'sponsor-one', '', '', '2015-09-10 21:24:04', '2015-09-10 21:24:04', '', 0, 'http://9zero7films.dev/?post_type=sponsor&#038;p=152', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (153, 1, '2015-09-10 21:24:19', '2015-09-10 21:24:19', '', 'Sponsor Two', '', 'publish', 'closed', 'closed', '', 'sponsor-two', '', '', '2015-09-10 21:24:19', '2015-09-10 21:24:19', '', 0, 'http://9zero7films.dev/?post_type=sponsor&#038;p=153', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (154, 1, '2015-09-10 21:24:32', '2015-09-10 21:24:32', '', 'Sponsor Three', '', 'publish', 'closed', 'closed', '', 'sponsor-three', '', '', '2015-09-11 21:09:20', '2015-09-11 21:09:20', '', 0, 'http://9zero7films.dev/?post_type=sponsor&#038;p=154', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (155, 1, '2015-09-10 21:24:59', '2015-09-10 21:24:59', '', 'Sponsor Four', '', 'publish', 'closed', 'closed', '', 'sponsor-four', '', '', '2015-09-10 21:24:59', '2015-09-10 21:24:59', '', 0, 'http://9zero7films.dev/?post_type=sponsor&#038;p=155', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (156, 1, '2015-09-10 21:25:14', '2015-09-10 21:25:14', '', 'Sponsor Five', '', 'publish', 'closed', 'closed', '', 'sponsor-five', '', '', '2015-09-10 21:25:14', '2015-09-10 21:25:14', '', 0, 'http://9zero7films.dev/?post_type=sponsor&#038;p=156', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (157, 1, '2015-09-10 21:25:34', '2015-09-10 21:25:34', '', 'Sponsor Six', '', 'publish', 'closed', 'closed', '', 'sponsor-six', '', '', '2015-09-10 21:25:34', '2015-09-10 21:25:34', '', 0, 'http://9zero7films.dev/?post_type=sponsor&#038;p=157', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (158, 1, '2015-09-10 21:25:50', '2015-09-10 21:25:50', '', 'Sponsor Seven', '', 'publish', 'closed', 'closed', '', 'sponsor-seven', '', '', '2015-09-10 21:25:50', '2015-09-10 21:25:50', '', 0, 'http://9zero7films.dev/?post_type=sponsor&#038;p=158', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (159, 1, '2015-09-10 21:26:04', '2015-09-10 21:26:04', '', 'Sponsor Eight', '', 'publish', 'closed', 'closed', '', 'sponsor-eight', '', '', '2015-09-10 21:26:04', '2015-09-10 21:26:04', '', 0, 'http://9zero7films.dev/?post_type=sponsor&#038;p=159', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (160, 1, '2015-09-10 21:26:20', '2015-09-10 21:26:20', '', 'Sponsor Nine', '', 'publish', 'closed', 'closed', '', 'sponsor-nine', '', '', '2015-09-10 21:26:20', '2015-09-10 21:26:20', '', 0, 'http://9zero7films.dev/?post_type=sponsor&#038;p=160', 0, 'sponsor', '', 0) ; 
INSERT INTO `wp_posts` VALUES (161, 1, '2015-09-10 21:50:40', '2015-09-10 21:50:40', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"81";}}}s:8:"position";s:6:"normal";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:1:{i:0;s:11:"the_content";}s:11:"description";s:0:"";}', 'Sponsors', 'sponsors', 'publish', 'closed', 'closed', '', 'group_55f1facd0b2e2', '', '', '2015-09-11 21:04:04', '2015-09-11 21:04:04', '', 0, 'http://9zero7films.dev/?post_type=acf-field-group&#038;p=161', 1, 'acf-field-group', '', 0) ; 
INSERT INTO `wp_posts` VALUES (163, 1, '2015-09-11 02:08:35', '2015-09-11 02:08:35', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam feugiat lorem at justo pellentesque, ac molestie nisi scelerisque. <a href="http://9zero7films.dev/">http://9zero7films.dev/</a> malesuada eu sapien. Maecenas id pulvinar sapien, sit amet porttitor enim. Pellentesque augue ligula, dapibus id interdum at, tempor ut diam. Aenean elit sapien, vestibulum egestas lorem vitae, ultricies finibus neque.
<ol>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ol>
Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam aliquet, dui vitae eleifend commodo, odio lectus euismod purus, at suscipit urna dui vel urna.
<h2>Sed eget sagittis ex, quis fermentum nibh pellentesque eleifend lectus id lacinia venenatis.</h2>
Suspendisse egestas nisi et fermentum luctus. Mauris sit amet nunc at sem auctor aliquam at a orci. Etiam vel nisi ultricies urna placerat faucibus at vitae diam. Duis sed cursus diam. Maecenas non tempus erat. Sed ut semper ante. <strong>Proin dignissim, est vitae ullamcorper blandit</strong>, erat nulla laoreet erat, quis euismod nulla augue vel velit.

Sed rutrum nibh ut viverra semper. Quisque lobortis ultricies facilisis. Nulla mauris neque, luctus sed sapien vitae, imperdiet laoreet lacus. Vivamus ex lectus, porta a velit a, ullamcorper auctor massa. Aenean vulputate erat at congue efficitur. Nullam varius egestas ex. <em>Fusce imperdiet tellus et luctus suscipit</em>. Nulla ut dui a massa mollis tincidunt. Pellentesque eu sem eu purus pellentesque feugiat non quis est. Nulla pretium, eros et faucibus molestie, nisi justo faucibus lacus, et venenatis ex augue nec nunc. Nunc id nunc massa.
<ul>
	<li>Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus.</li>
	<li>Quisque eget quam ligula.</li>
	<li>Vivamus a malesuada augue.</li>
</ul>
Nulla venenatis condimentum est, sed efficitur purus congue id. Vivamus a malesuada augue. Donec consequat interdum nisi nec laoreet. Morbi ultrices varius dui, vitae pulvinar nibh ornare sed. Donec semper gravida neque scelerisque bibendum. In eu rutrum mi. Quisque luctus tellus ut sem maximus vehicula. Nunc vel varius nisi, vitae venenatis erat. Cras mollis interdum enim, ac pretium ligula feugiat eu. In sed lectus ut ipsum euismod sodales eget sed augue.
<h3>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</h3>
Ut mattis non enim quis pretium. Suspendisse blandit mollis libero sit amet commodo. Quisque sagittis iaculis risus congue rhoncus. Mauris fermentum elit sit amet nunc ullamcorper, non iaculis eros suscipit. Ut facilisis accumsan nunc. Vivamus finibus ut erat ut mollis. Quisque sed lacus enim. Nulla facilisi. Suspendisse non faucibus neque. Quisque lacus elit, sodales a laoreet sollicitudin, elementum sit amet tellus. Quisque metus lorem, ornare non aliquam sit amet, gravida et est. Maecenas quis malesuada ante. Mauris ac neque sit amet justo varius pulvinar quis et enim. Proin aliquet eget enim non ornare. Suspendisse cursus risus nec enim suscipit commodo ac a ligula.

Suspendisse ligula felis, pellentesque in leo vitae, bibendum sagittis metus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean congue erat in mauris viverra eleifend in eget nunc. Aliquam orci erat, blandit quis lorem quis, pellentesque placerat justo. Sed arcu nunc, lacinia quis magna vel, tempor tempus urna. In sit amet mi dapibus, consectetur lorem ac, aliquet metus. Morbi faucibus vitae purus sit amet varius.

Etiam ut tincidunt sapien, eu gravida enim vivamus congue leo tellus, id pellentesque justo finibus at. Maecenas rhoncus magna eget quam bibendum, ut iaculis massa facilisis. Sed sed condimentum tortor, eget tristique mauris. Morbi eu imperdiet nunc. In interdum non ipsum sit amet molestie. Aenean vel eros ornare, ornare elit et, tincidunt quam. Sed ac erat et nulla aliquam euismod eget eget quam. Quisque eget quam ligula. Suspendisse euismod dui vitae euismod tincidunt. Morbi accumsan purus sit amet mattis laoreet.

Suspendisse vitae nibh elementum sapien cursus hendrerit. Mauris varius tortor maximus, gravida lorem nec, commodo massa. Pellentesque malesuada erat quis lacus aliquet lacinia. Quisque vel est a augue porta scelerisque vitae vel risus. Pellentesque nec nisl luctus, dapibus orci a, ornare est.
<blockquote>Duis finibus, ante eu laoreet pulvinar, mauris nulla vulputate neque, nec lacinia mauris est in ipsum. Proin vestibulum blandit odio a pharetra. Pellentesque sed nulla ut arcu vestibulum facilisis. Ut vitae congue risus. Quisque mattis leo non ornare viverra. Aliquam eget massa neque. Cras nec placerat magna.</blockquote>
Duis eu pellentesque neque, non ullamcorper lectus. Etiam ut tellus congue turpis bibendum accumsan. Etiam non condimentum neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean tempus ipsum purus, vel consequat sapien feugiat ac. Maecenas vestibulum est vel arcu vestibulum, a tempor nulla maximus. Vivamus hendrerit dolor consequat dignissim dignissim.

Maecenas eu fringilla nisl, nec hendrerit est. Maecenas quis nibh eget ipsum bibendum facilisis. Proin dapibus diam eget rhoncus efficitur. Duis mollis ante at bibendum pharetra. Praesent ultricies mollis accumsan. Nunc feugiat quis velit eget commodo. Praesent ultricies iaculis erat, nec fermentum est pharetra non. Nulla facilisi. Sed sollicitudin mauris ac magna scelerisque vulputate. Etiam sit amet nisi vel eros finibus sodales. Nullam egestas fringilla eros a aliquet. Mauris et mollis erat, in eleifend turpis.

Vivamus sit amet neque ut arcu maximus gravida. Mauris sodales quam vel finibus auctor. Vestibulum eget nulla turpis. Cras eros augue, semper nec malesuada vel, elementum sed sem. Aenean ac maximus ex, mattis dictum enim. Sed ultrices leo in tellus iaculis imperdiet. Morbi auctor arcu nec elit interdum dapibus. Integer sed leo odio. Aliquam nec ultricies risus, vel porta lectus. Sed accumsan placerat leo, at aliquam felis rhoncus aliquam. Curabitur in sodales massa. Aenean dui est, commodo ac venenatis et, aliquam eu neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse interdum enim quis volutpat sollicitudin. Morbi bibendum est non egestas rhoncus. Cras tempor sagittis nibh sit amet pharetra.

Quisque sagittis, libero in sagittis imperdiet, magna felis tincidunt erat, sit amet sagittis libero risus sed diam. Etiam vestibulum non purus in gravida. Nulla facilisi. Nunc lectus purus, gravida quis ligula vehicula, pulvinar venenatis nibh. Aenean hendrerit eleifend lacus, vel ultrices nisi ultricies eget. Mauris neque quam, laoreet varius maximus id, auctor sit amet ante. Maecenas sed felis sit amet risus varius rutrum nec eu enim. Ut commodo sollicitudin purus ut auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras volutpat tristique neque sit amet pulvinar. Cras sed sem ac dolor ornare sagittis. Morbi augue augue, gravida vitae mi sit amet, ornare tempor libero. Donec sagittis fermentum magna eget aliquam. Etiam fermentum mi a lacinia varius.

Morbi venenatis velit non interdum bibendum. Phasellus iaculis ornare elementum. Vivamus ac imperdiet ligula, eget ultrices diam. Vivamus sed tincidunt turpis. Integer eu auctor eros. Nullam finibus laoreet venenatis. Nunc ac sem cursus, faucibus sem a, aliquam turpis. Praesent bibendum magna vitae pulvinar fermentum. Mauris at sollicitudin orci, sed tempus leo. Fusce quis magna tristique, eleifend metus sed, sodales sapien. Suspendisse sit amet massa consequat nulla lacinia sagittis.

In ullamcorper ac eros eu efficitur. Donec a orci orci. Suspendisse egestas lacus in risus feugiat, eget maximus mauris condimentum. Duis ut ante et diam feugiat tincidunt. Morbi nec velit vitae sapien elementum sagittis. Fusce sed luctus massa, quis mollis dolor. Suspendisse facilisis orci et maximus feugiat. Sed quis congue erat. Cras porta efficitur magna, dictum sagittis urna laoreet semper. Etiam ac nunc orci.
<h6>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.</h6>
Vestibulum eget pretium elit. Pellentesque nec tempor augue. In velit ipsum, porttitor et vulputate et, sollicitudin ac mi. Aliquam placerat non magna quis auctor. Sed sagittis nisi vitae lectus semper, id semper quam consequat. Nulla posuere, ex in iaculis ultricies, nulla libero sollicitudin dui, ut tristique orci leo ut tortor. Fusce laoreet tincidunt lacus id posuere. Donec et metus sit amet diam lobortis aliquet. Aenean eget vestibulum mauris. Sed id est lacus. Aenean sed congue diam. Nullam pretium dictum elit non tempus. Suspendisse potenti. Pellentesque mattis lorem vitae dolor porttitor, vitae condimentum magna vulputate. Pellentesque bibendum lorem ut lorem dictum, ut venenatis orci tempus.

Aliquam id augue lobortis, pellentesque leo sit amet, bibendum est. Morbi quis ex nec eros efficitur imperdiet vitae id dolor. Pellentesque et lectus vitae augue pretium lobortis. Fusce ante orci, rutrum non ultrices sit amet, pellentesque vitae lacus. Proin at mattis risus. Suspendisse sem magna, ultrices at lectus at, laoreet lobortis tortor. Fusce viverra vestibulum dui id ultrices. Suspendisse eu rhoncus massa, eget sodales elit. Proin gravida dolor at sapien congue, sed vehicula nisi rutrum.', 'Article One', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2015-09-11 02:08:35', '2015-09-11 02:08:35', '', 24, 'http://9zero7films.dev/2015/09/24-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (164, 1, '2015-09-11 02:09:50', '2015-09-11 02:09:50', '', 'Article Thirteen', '', 'inherit', 'closed', 'closed', '', '135-revision-v1', '', '', '2015-09-11 02:09:50', '2015-09-11 02:09:50', '', 135, 'http://9zero7films.dev/2015/09/135-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (165, 1, '2015-08-14 02:10:07', '2015-08-14 02:10:07', '', 'Article Fourteen', '', 'publish', 'closed', 'closed', '', 'article-fourteen', '', '', '2015-09-11 21:39:21', '2015-09-11 21:39:21', '', 0, 'http://9zero7films.dev/?p=165', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (166, 1, '2015-09-11 02:10:07', '2015-09-11 02:10:07', '', 'Article Fourteen', '', 'inherit', 'closed', 'closed', '', '165-revision-v1', '', '', '2015-09-11 02:10:07', '2015-09-11 02:10:07', '', 165, 'http://9zero7films.dev/2015/09/165-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (167, 1, '2015-08-15 02:10:23', '2015-08-15 02:10:23', '', 'Article Fifteen', '', 'publish', 'closed', 'closed', '', 'article-fifteen', '', '', '2015-09-12 03:09:28', '2015-09-12 03:09:28', '', 0, 'http://9zero7films.dev/?p=167', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (168, 1, '2015-09-11 02:10:23', '2015-09-11 02:10:23', '', 'Article Fifteen', '', 'inherit', 'closed', 'closed', '', '167-revision-v1', '', '', '2015-09-11 02:10:23', '2015-09-11 02:10:23', '', 167, 'http://9zero7films.dev/2015/09/167-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (169, 1, '2015-09-11 02:10:58', '2015-09-11 02:10:58', '', 'Class Two', '', 'publish', 'closed', 'closed', '', 'class-two', '', '', '2015-09-11 02:10:58', '2015-09-11 02:10:58', '', 0, 'http://9zero7films.dev/?post_type=class&#038;p=169', 0, 'class', '', 0) ; 
INSERT INTO `wp_posts` VALUES (170, 1, '2015-09-11 02:11:12', '2015-09-11 02:11:12', '', 'Class Three', '', 'publish', 'closed', 'closed', '', 'class-three', '', '', '2015-09-11 02:11:12', '2015-09-11 02:11:12', '', 0, 'http://9zero7films.dev/?post_type=class&#038;p=170', 0, 'class', '', 0) ; 
INSERT INTO `wp_posts` VALUES (171, 1, '2015-09-11 02:11:39', '2015-09-11 02:11:39', '', 'Teaching Philosophy', '', 'publish', 'closed', 'closed', '', 'teaching-philosophy', '', '', '2015-09-11 21:14:24', '2015-09-11 21:14:24', '', 0, 'http://9zero7films.dev/?post_type=faq&#038;p=171', 0, 'faq', '', 0) ; 
INSERT INTO `wp_posts` VALUES (172, 1, '2015-09-11 02:11:53', '2015-09-11 02:11:53', '', 'Teaching Style', '', 'publish', 'closed', 'closed', '', 'teaching-style', '', '', '2015-09-11 21:15:10', '2015-09-11 21:15:10', '', 0, 'http://9zero7films.dev/?post_type=faq&#038;p=172', 1, 'faq', '', 0) ; 
INSERT INTO `wp_posts` VALUES (173, 1, '2015-09-11 02:12:11', '2015-09-11 02:12:11', '', 'Benefits of Documentary Films', '', 'publish', 'closed', 'closed', '', 'benefits-of-documentary-films', '', '', '2015-09-11 21:16:18', '2015-09-11 21:16:18', '', 0, 'http://9zero7films.dev/?post_type=faq&#038;p=173', 2, 'faq', '', 0) ; 
INSERT INTO `wp_posts` VALUES (174, 1, '2015-09-11 02:12:43', '2015-09-11 02:12:43', '', 'Johnny Appleseed', '', 'publish', 'closed', 'closed', '', 'johnny-appleseed', '', '', '2015-09-11 02:12:43', '2015-09-11 02:12:43', '', 0, 'http://9zero7films.dev/?post_type=testimonial&#038;p=174', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (175, 1, '2015-09-11 02:13:07', '2015-09-11 02:13:07', '', 'Julie Appleseed', '', 'publish', 'closed', 'closed', '', 'julie-appleseed', '', '', '2015-09-11 02:13:07', '2015-09-11 02:13:07', '', 0, 'http://9zero7films.dev/?post_type=testimonial&#038;p=175', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (176, 1, '2015-09-11 03:21:51', '2015-09-11 03:21:51', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"10";}}}s:8:"position";s:6:"normal";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:1:{i:0;s:11:"the_content";}s:11:"description";s:0:"";}', 'Home', 'home', 'publish', 'closed', 'closed', '', 'group_55f248b8c4e3e', '', '', '2015-09-11 03:45:29', '2015-09-11 03:45:29', '', 0, 'http://9zero7films.dev/?post_type=acf-field-group&#038;p=176', 1, 'acf-field-group', '', 0) ; 
INSERT INTO `wp_posts` VALUES (177, 1, '2015-09-11 03:30:09', '2015-09-11 03:30:09', '', 'home-hero', '', 'inherit', 'closed', 'closed', '', 'home-hero', '', '', '2015-09-11 03:30:09', '2015-09-11 03:30:09', '', 0, 'http://9zero7films.dev/wp-content/uploads/home-hero.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (178, 1, '2015-09-11 03:39:41', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-09-11 03:39:41', '0000-00-00 00:00:00', '', 0, 'http://9zero7films.dev/?page_id=178', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (179, 1, '2015-09-11 03:43:24', '2015-09-11 03:43:24', 'a:7:{s:4:"type";s:7:"message";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"message";s:0:"";s:8:"esc_html";i:0;}', 'Hero', '', 'publish', 'closed', 'closed', '', 'field_55f24927d9c9c', '', '', '2015-09-11 03:43:24', '2015-09-11 03:43:24', '', 176, 'http://9zero7films.dev/?post_type=acf-field&p=179', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (180, 1, '2015-09-11 03:44:33', '2015-09-11 03:44:33', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:49:"A size of 900px W &times; 506px H is recommended.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:13:"gif, jpg, png";}', 'Image', 'home_hero_image', 'publish', 'closed', 'closed', '', 'field_55f24de7e586e', '', '', '2015-09-11 03:44:33', '2015-09-11 03:44:33', '', 176, 'http://9zero7films.dev/?post_type=acf-field&p=180', 1, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (181, 1, '2015-09-11 19:56:47', '2015-09-11 19:56:47', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Vimeo', 'social_vimeo', 'publish', 'closed', 'closed', '', 'field_55f331bbb72b7', '', '', '2015-09-11 19:56:47', '2015-09-11 19:56:47', '', 72, 'http://9zero7films.dev/?post_type=acf-field&p=181', 5, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (182, 1, '2015-09-11 19:56:47', '2015-09-11 19:56:47', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'YouTube', 'social_youtube', 'publish', 'closed', 'closed', '', 'field_55f331c9b72b8', '', '', '2015-09-11 19:56:47', '2015-09-11 19:56:47', '', 72, 'http://9zero7films.dev/?post_type=acf-field&p=182', 6, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (183, 1, '2015-09-11 20:07:40', '2015-09-11 20:07:40', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:22:"acf-options-newsletter";}}}s:8:"position";s:6:"normal";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Newsletter', 'newsletter', 'publish', 'closed', 'closed', '', 'group_55f3347815ab2', '', '', '2015-09-11 20:12:48', '2015-09-11 20:12:48', '', 0, 'http://9zero7films.dev/?post_type=acf-field-group&#038;p=183', 1, 'acf-field-group', '', 0) ; 
INSERT INTO `wp_posts` VALUES (184, 1, '2015-09-11 20:09:53', '2015-09-11 20:09:53', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Headline', 'newsletter_headline', 'publish', 'closed', 'closed', '', 'field_55f334ae9bd30', '', '', '2015-09-11 20:09:53', '2015-09-11 20:09:53', '', 183, 'http://9zero7films.dev/?post_type=acf-field&p=184', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (185, 1, '2015-09-11 20:09:53', '2015-09-11 20:09:53', 'a:12:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";i:4;s:9:"new_lines";s:7:"wpautop";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Description', 'newsletter_description', 'publish', 'closed', 'closed', '', 'field_55f334ca9bd31', '', '', '2015-09-11 20:12:48', '2015-09-11 20:12:48', '', 183, 'http://9zero7films.dev/?post_type=acf-field&#038;p=185', 1, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (186, 1, '2015-09-11 20:38:20', '2015-09-11 20:38:20', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"83";}}}s:8:"position";s:6:"normal";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:1:{i:0;s:11:"the_content";}s:11:"description";s:0:"";}', 'Donate', 'donate', 'publish', 'closed', 'closed', '', 'group_55f33b1f5666a', '', '', '2015-09-11 20:57:19', '2015-09-11 20:57:19', '', 0, 'http://9zero7films.dev/?post_type=acf-field-group&#038;p=186', 1, 'acf-field-group', '', 0) ; 
INSERT INTO `wp_posts` VALUES (187, 1, '2015-09-11 20:38:20', '2015-09-11 20:38:20', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:6:"visual";s:7:"toolbar";s:5:"basic";s:12:"media_upload";i:0;}', 'Content', 'donate_content', 'publish', 'closed', 'closed', '', 'field_55f33b3bb883b', '', '', '2015-09-11 20:38:20', '2015-09-11 20:38:20', '', 186, 'http://9zero7films.dev/?post_type=acf-field&p=187', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (188, 1, '2015-09-11 20:38:20', '2015-09-11 20:38:20', 'a:9:{s:4:"type";s:8:"checkbox";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:4:{s:4:"Visa";s:4:"Visa";s:10:"MasterCard";s:10:"MasterCard";s:16:"American Express";s:16:"American Express";s:8:"Discover";s:8:"Discover";}s:13:"default_value";a:0:{}s:6:"layout";s:8:"vertical";s:6:"toggle";i:0;}', 'Accepted Cards', 'donate_accepted_cards', 'publish', 'closed', 'closed', '', 'field_55f33b77b883c', '', '', '2015-09-11 20:57:18', '2015-09-11 20:57:18', '', 186, 'http://9zero7films.dev/?post_type=acf-field&#038;p=188', 1, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (189, 1, '2015-09-11 20:39:15', '2015-09-11 20:39:15', '', 'Donate', '', 'inherit', 'closed', 'closed', '', '83-revision-v1', '', '', '2015-09-11 20:39:15', '2015-09-11 20:39:15', '', 83, 'http://9zero7films.dev/2015/09/83-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (190, 1, '2015-09-11 21:00:12', '2015-09-11 21:00:12', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"16";}}}s:8:"position";s:6:"normal";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:1:{i:0;s:11:"the_content";}s:11:"description";s:0:"";}', 'Contact', 'contact', 'publish', 'closed', 'closed', '', 'group_55f340afaad2b', '', '', '2015-09-11 21:00:12', '2015-09-11 21:00:12', '', 0, 'http://9zero7films.dev/?post_type=acf-field-group&#038;p=190', 1, 'acf-field-group', '', 0) ; 
INSERT INTO `wp_posts` VALUES (191, 1, '2015-09-11 21:00:12', '2015-09-11 21:00:12', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:6:"visual";s:7:"toolbar";s:5:"basic";s:12:"media_upload";i:0;}', 'Content', 'contact_content', 'publish', 'closed', 'closed', '', 'field_55f340c5500ff', '', '', '2015-09-11 21:00:12', '2015-09-11 21:00:12', '', 190, 'http://9zero7films.dev/?post_type=acf-field&p=191', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (192, 1, '2015-09-11 21:00:39', '2015-09-11 21:00:39', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In adipiscing hendrerit risus vitae tincidunt. Morbi vel ultrices nisi. Etiam quis malesuada nunc. Vivamus in elit et nisi sagittis feugiat. Quisque dictum sapien nec quam consectetur, id ullamcorper arcu consequat. Nulla a ipsum non leo elementum consequat in eu erat. Curabitur ornare risus sed arcu vulputate, id elementum nibh tincidunt. Suspendisse potenti. Praesent lobortis nisi pellentesque lacus pellentesque sagittis. Quisque non imperdiet libero. Nullam bibendum purus at tellus molestie, eget pretium neque vestibulum. Aliquam aliquam varius fermentum.', 'Contact', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2015-09-11 21:00:39', '2015-09-11 21:00:39', '', 16, 'http://9zero7films.dev/2015/09/16-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (193, 1, '2015-09-11 21:03:14', '2015-09-11 21:03:14', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:6:"visual";s:7:"toolbar";s:5:"basic";s:12:"media_upload";i:0;}', 'Content', 'sponsors_content', 'publish', 'closed', 'closed', '', 'field_55f3415b1542c', '', '', '2015-09-11 21:03:14', '2015-09-11 21:03:14', '', 161, 'http://9zero7films.dev/?post_type=acf-field&p=193', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (194, 1, '2015-09-11 21:04:29', '2015-09-11 21:04:29', '', 'Sponsors', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2015-09-11 21:04:29', '2015-09-11 21:04:29', '', 81, 'http://9zero7films.dev/2015/09/81-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (195, 1, '2015-09-11 21:13:40', '2015-09-11 21:13:40', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Question', 'faq_question', 'publish', 'closed', 'closed', '', 'field_55f343cf09257', '', '', '2015-09-11 21:13:40', '2015-09-11 21:13:40', '', 144, 'http://9zero7films.dev/?post_type=acf-field&p=195', 0, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (196, 1, '2015-09-11 21:13:41', '2015-09-11 21:13:41', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:6:"visual";s:7:"toolbar";s:5:"basic";s:12:"media_upload";i:0;}', 'Answer', 'faq_answer', 'publish', 'closed', 'closed', '', 'field_55f343ea09258', '', '', '2015-09-11 21:13:41', '2015-09-11 21:13:41', '', 144, 'http://9zero7films.dev/?post_type=acf-field&p=196', 1, 'acf-field', '', 0) ; 
INSERT INTO `wp_posts` VALUES (197, 1, '2015-09-11 21:39:02', '2015-09-11 21:39:02', '', 'Article Fifteen', '', 'inherit', 'closed', 'closed', '', '167-revision-v1', '', '', '2015-09-11 21:39:02', '2015-09-11 21:39:02', '', 167, 'http://9zero7films.dev/2015/09/167-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (198, 1, '2015-09-11 21:39:21', '2015-09-11 21:39:21', '', 'Article Fourteen', '', 'inherit', 'closed', 'closed', '', '165-revision-v1', '', '', '2015-09-11 21:39:21', '2015-09-11 21:39:21', '', 165, 'http://9zero7films.dev/2015/09/165-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (199, 1, '2015-09-11 21:40:13', '2015-09-11 21:40:13', '', 'Article Fifteen', '', 'inherit', 'closed', 'closed', '', '167-revision-v1', '', '', '2015-09-11 21:40:13', '2015-09-11 21:40:13', '', 167, 'http://9zero7films.dev/2015/09/167-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (200, 1, '2015-09-11 22:01:15', '2015-09-11 22:01:15', '', 'Article Fifteen', '', 'inherit', 'closed', 'closed', '', '167-revision-v1', '', '', '2015-09-11 22:01:15', '2015-09-11 22:01:15', '', 167, 'http://9zero7films.dev/2015/09/167-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (201, 1, '2015-09-12 01:40:51', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-09-12 01:40:51', '0000-00-00 00:00:00', '', 0, 'http://9zero7films.dev/?p=201', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (203, 1, '2015-09-12 03:09:28', '2015-09-12 03:09:28', '', 'Article Fifteen', '', 'inherit', 'closed', 'closed', '', '167-revision-v1', '', '', '2015-09-12 03:09:28', '2015-09-12 03:09:28', '', 167, 'http://9zero7films.dev/2015/09/167-revision-v1/', 0, 'revision', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_form (1 records)
#
 
INSERT INTO `wp_rg_form` VALUES (1, 'Contact', '2014-01-17 10:06:19', 1, 0) ;
#
# End of data contents of table wp_rg_form
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext,
  `entries_grid_meta` longtext,
  `confirmations` longtext,
  `notifications` longtext,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_form_meta (1 records)
#
 
INSERT INTO `wp_rg_form_meta` VALUES (1, 'a:36:{s:5:"title";s:7:"Contact";s:11:"description";s:0:"";s:14:"labelPlacement";s:9:"top_label";s:20:"descriptionPlacement";s:5:"below";s:6:"button";a:3:{s:4:"type";s:4:"text";s:4:"text";s:4:"Send";s:8:"imageUrl";s:0:"";}s:6:"fields";a:6:{i:0;a:58:{s:10:"adminLabel";s:0:"";s:9:"adminOnly";s:0:"";s:17:"allowsPrepopulate";b:0;s:12:"defaultValue";s:0:"";s:11:"description";s:0:"";s:7:"content";s:0:"";s:8:"cssClass";s:0:"";s:12:"errorMessage";s:0:"";s:2:"id";i:1;s:9:"inputName";s:0:"";s:10:"isRequired";b:0;s:5:"label";s:4:"Name";s:12:"noDuplicates";s:0:"";s:4:"size";s:6:"medium";s:4:"type";s:4:"name";s:19:"postCustomFieldName";s:0:"";s:20:"displayAllCategories";b:0;s:14:"displayCaption";s:0:"";s:18:"displayDescription";s:0:"";s:12:"displayTitle";s:0:"";s:9:"inputType";s:0:"";s:8:"rangeMin";s:0:"";s:8:"rangeMax";s:0:"";s:16:"calendarIconType";s:0:"";s:15:"calendarIconUrl";s:0:"";s:8:"dateType";s:0:"";s:10:"dateFormat";s:0:"";s:11:"phoneFormat";s:0:"";s:11:"addressType";s:0:"";s:14:"defaultCountry";s:0:"";s:15:"defaultProvince";s:0:"";s:12:"defaultState";s:0:"";s:12:"hideAddress2";s:0:"";s:11:"hideCountry";s:0:"";s:9:"hideState";s:0:"";s:6:"inputs";N;s:10:"nameFormat";s:6:"simple";s:17:"allowedExtensions";s:0:"";s:11:"captchaType";s:0:"";s:10:"pageNumber";i:1;s:12:"captchaTheme";s:0:"";s:17:"simpleCaptchaSize";s:0:"";s:22:"simpleCaptchaFontColor";s:0:"";s:28:"simpleCaptchaBackgroundColor";s:0:"";s:17:"failed_validation";s:0:"";s:12:"productField";s:0:"";s:19:"enablePasswordInput";s:0:"";s:9:"maxLength";s:0:"";s:11:"enablePrice";s:0:"";s:9:"basePrice";s:0:"";s:18:"calculationFormula";s:0:"";s:19:"calculationRounding";s:0:"";s:17:"enableCalculation";s:0:"";s:15:"disableQuantity";b:0;s:9:"inputMask";b:0;s:14:"inputMaskValue";s:0:"";s:6:"formId";i:1;s:20:"descriptionPlacement";s:5:"below";}i:1;a:58:{s:10:"adminLabel";s:0:"";s:9:"adminOnly";s:0:"";s:17:"allowsPrepopulate";b:0;s:12:"defaultValue";s:0:"";s:11:"description";s:0:"";s:7:"content";s:0:"";s:8:"cssClass";s:0:"";s:12:"errorMessage";s:0:"";s:2:"id";i:2;s:9:"inputName";s:0:"";s:10:"isRequired";b:1;s:5:"label";s:5:"Email";s:12:"noDuplicates";s:0:"";s:4:"size";s:6:"medium";s:4:"type";s:5:"email";s:19:"postCustomFieldName";s:0:"";s:20:"displayAllCategories";b:0;s:14:"displayCaption";s:0:"";s:18:"displayDescription";s:0:"";s:12:"displayTitle";s:0:"";s:9:"inputType";s:0:"";s:8:"rangeMin";s:0:"";s:8:"rangeMax";s:0:"";s:16:"calendarIconType";s:0:"";s:15:"calendarIconUrl";s:0:"";s:8:"dateType";s:0:"";s:10:"dateFormat";s:0:"";s:11:"phoneFormat";s:0:"";s:11:"addressType";s:0:"";s:14:"defaultCountry";s:0:"";s:15:"defaultProvince";s:0:"";s:12:"defaultState";s:0:"";s:12:"hideAddress2";s:0:"";s:11:"hideCountry";s:0:"";s:9:"hideState";s:0:"";s:6:"inputs";N;s:10:"nameFormat";s:0:"";s:17:"allowedExtensions";s:0:"";s:11:"captchaType";s:0:"";s:10:"pageNumber";i:1;s:12:"captchaTheme";s:0:"";s:17:"simpleCaptchaSize";s:0:"";s:22:"simpleCaptchaFontColor";s:0:"";s:28:"simpleCaptchaBackgroundColor";s:0:"";s:17:"failed_validation";s:0:"";s:12:"productField";s:0:"";s:19:"enablePasswordInput";s:0:"";s:9:"maxLength";s:0:"";s:11:"enablePrice";s:0:"";s:9:"basePrice";s:0:"";s:18:"calculationFormula";s:0:"";s:19:"calculationRounding";s:0:"";s:17:"enableCalculation";s:0:"";s:15:"disableQuantity";b:0;s:9:"inputMask";b:0;s:14:"inputMaskValue";s:0:"";s:6:"formId";i:1;s:20:"descriptionPlacement";s:5:"below";}i:2;a:52:{s:10:"adminLabel";s:0:"";s:9:"adminOnly";s:0:"";s:17:"allowsPrepopulate";s:0:"";s:12:"defaultValue";s:0:"";s:11:"description";s:0:"";s:7:"content";s:0:"";s:8:"cssClass";s:0:"";s:12:"errorMessage";s:0:"";s:2:"id";i:5;s:9:"inputName";s:0:"";s:10:"isRequired";b:0;s:5:"label";s:5:"Phone";s:12:"noDuplicates";s:0:"";s:4:"size";s:6:"medium";s:4:"type";s:5:"phone";s:19:"postCustomFieldName";s:0:"";s:20:"displayAllCategories";s:0:"";s:14:"displayCaption";s:0:"";s:18:"displayDescription";s:0:"";s:12:"displayTitle";s:0:"";s:9:"inputType";s:0:"";s:8:"rangeMin";s:0:"";s:8:"rangeMax";s:0:"";s:16:"calendarIconType";s:0:"";s:15:"calendarIconUrl";s:0:"";s:8:"dateType";s:0:"";s:10:"dateFormat";s:0:"";s:11:"phoneFormat";s:8:"standard";s:11:"addressType";s:0:"";s:14:"defaultCountry";s:0:"";s:15:"defaultProvince";s:0:"";s:12:"defaultState";s:0:"";s:12:"hideAddress2";s:0:"";s:11:"hideCountry";s:0:"";s:9:"hideState";s:0:"";s:6:"inputs";N;s:10:"nameFormat";s:0:"";s:17:"allowedExtensions";s:0:"";s:11:"captchaType";s:0:"";s:10:"pageNumber";i:1;s:12:"captchaTheme";s:0:"";s:17:"simpleCaptchaSize";s:0:"";s:22:"simpleCaptchaFontColor";s:0:"";s:28:"simpleCaptchaBackgroundColor";s:0:"";s:17:"failed_validation";s:0:"";s:12:"productField";s:0:"";s:19:"enablePasswordInput";s:0:"";s:9:"maxLength";s:0:"";s:11:"enablePrice";s:0:"";s:9:"basePrice";s:0:"";s:6:"formId";i:1;s:20:"descriptionPlacement";s:5:"below";}i:3;a:60:{s:10:"adminLabel";s:0:"";s:9:"adminOnly";s:0:"";s:17:"allowsPrepopulate";b:0;s:12:"defaultValue";s:0:"";s:11:"description";s:0:"";s:7:"content";s:0:"";s:8:"cssClass";s:0:"";s:12:"errorMessage";s:0:"";s:2:"id";i:3;s:9:"inputName";s:0:"";s:10:"isRequired";b:0;s:5:"label";s:7:"Subject";s:12:"noDuplicates";s:0:"";s:4:"size";s:6:"medium";s:4:"type";s:6:"select";s:19:"postCustomFieldName";s:0:"";s:20:"displayAllCategories";b:0;s:14:"displayCaption";s:0:"";s:18:"displayDescription";s:0:"";s:12:"displayTitle";s:0:"";s:9:"inputType";s:0:"";s:8:"rangeMin";s:0:"";s:8:"rangeMax";s:0:"";s:16:"calendarIconType";s:0:"";s:15:"calendarIconUrl";s:0:"";s:8:"dateType";s:0:"";s:10:"dateFormat";s:0:"";s:11:"phoneFormat";s:0:"";s:11:"addressType";s:0:"";s:14:"defaultCountry";s:0:"";s:15:"defaultProvince";s:0:"";s:12:"defaultState";s:0:"";s:12:"hideAddress2";s:0:"";s:11:"hideCountry";s:0:"";s:9:"hideState";s:0:"";s:6:"inputs";N;s:10:"nameFormat";s:0:"";s:17:"allowedExtensions";s:0:"";s:11:"captchaType";s:0:"";s:10:"pageNumber";i:1;s:12:"captchaTheme";s:0:"";s:17:"simpleCaptchaSize";s:0:"";s:22:"simpleCaptchaFontColor";s:0:"";s:28:"simpleCaptchaBackgroundColor";s:0:"";s:17:"failed_validation";s:0:"";s:12:"productField";s:0:"";s:19:"enablePasswordInput";s:0:"";s:9:"maxLength";s:0:"";s:11:"enablePrice";s:0:"";s:9:"basePrice";s:0:"";s:7:"choices";a:3:{i:0;a:4:{s:4:"text";s:12:"First Choice";s:5:"value";s:12:"First Choice";s:10:"isSelected";b:0;s:5:"price";s:0:"";}i:1;a:4:{s:4:"text";s:13:"Second Choice";s:5:"value";s:13:"Second Choice";s:10:"isSelected";b:0;s:5:"price";s:0:"";}i:2;a:4:{s:4:"text";s:12:"Third Choice";s:5:"value";s:12:"Third Choice";s:10:"isSelected";b:0;s:5:"price";s:0:"";}}s:18:"calculationFormula";s:0:"";s:19:"calculationRounding";s:0:"";s:17:"enableCalculation";s:0:"";s:15:"disableQuantity";b:0;s:9:"inputMask";b:0;s:14:"inputMaskValue";s:0:"";s:16:"enableEnhancedUI";i:1;s:6:"formId";i:1;s:20:"descriptionPlacement";s:5:"below";}i:4;a:19:{s:2:"id";i:6;s:5:"label";s:4:"Date";s:10:"adminLabel";s:0:"";s:4:"type";s:4:"date";s:10:"isRequired";b:0;s:4:"size";s:6:"medium";s:12:"errorMessage";s:0:"";s:6:"inputs";N;s:18:"calculationFormula";s:0:"";s:19:"calculationRounding";s:0:"";s:17:"enableCalculation";s:0:"";s:15:"disableQuantity";b:0;s:20:"displayAllCategories";b:0;s:9:"inputMask";b:0;s:14:"inputMaskValue";s:0:"";s:8:"dateType";s:10:"datepicker";s:16:"calendarIconType";s:4:"none";s:15:"calendarIconUrl";s:0:"";s:17:"allowsPrepopulate";b:0;}i:5;a:58:{s:10:"adminLabel";s:0:"";s:9:"adminOnly";s:0:"";s:17:"allowsPrepopulate";b:0;s:12:"defaultValue";s:0:"";s:11:"description";s:0:"";s:7:"content";s:0:"";s:8:"cssClass";s:0:"";s:12:"errorMessage";s:0:"";s:2:"id";i:4;s:9:"inputName";s:0:"";s:10:"isRequired";b:1;s:5:"label";s:7:"Message";s:12:"noDuplicates";s:0:"";s:4:"size";s:6:"medium";s:4:"type";s:8:"textarea";s:19:"postCustomFieldName";s:0:"";s:20:"displayAllCategories";b:0;s:14:"displayCaption";s:0:"";s:18:"displayDescription";s:0:"";s:12:"displayTitle";s:0:"";s:9:"inputType";s:0:"";s:8:"rangeMin";s:0:"";s:8:"rangeMax";s:0:"";s:16:"calendarIconType";s:0:"";s:15:"calendarIconUrl";s:0:"";s:8:"dateType";s:0:"";s:10:"dateFormat";s:0:"";s:11:"phoneFormat";s:0:"";s:11:"addressType";s:0:"";s:14:"defaultCountry";s:0:"";s:15:"defaultProvince";s:0:"";s:12:"defaultState";s:0:"";s:12:"hideAddress2";s:0:"";s:11:"hideCountry";s:0:"";s:9:"hideState";s:0:"";s:6:"inputs";N;s:10:"nameFormat";s:0:"";s:17:"allowedExtensions";s:0:"";s:11:"captchaType";s:0:"";s:10:"pageNumber";i:1;s:12:"captchaTheme";s:0:"";s:17:"simpleCaptchaSize";s:0:"";s:22:"simpleCaptchaFontColor";s:0:"";s:28:"simpleCaptchaBackgroundColor";s:0:"";s:17:"failed_validation";s:0:"";s:12:"productField";s:0:"";s:19:"enablePasswordInput";s:0:"";s:9:"maxLength";s:0:"";s:11:"enablePrice";s:0:"";s:9:"basePrice";s:0:"";s:18:"calculationFormula";s:0:"";s:19:"calculationRounding";s:0:"";s:17:"enableCalculation";s:0:"";s:15:"disableQuantity";b:0;s:9:"inputMask";b:0;s:14:"inputMaskValue";s:0:"";s:6:"formId";i:1;s:20:"descriptionPlacement";s:5:"below";}}s:2:"id";i:1;s:13:"notifications";a:1:{s:13:"52d9009b30fab";a:7:{s:2:"id";s:13:"52d9009b30fab";s:2:"to";s:13:"{admin_email}";s:4:"name";s:18:"Admin Notification";s:5:"event";s:15:"form_submission";s:6:"toType";s:5:"email";s:7:"subject";s:32:"New submission from {form_title}";s:7:"message";s:12:"{all_fields}";}}s:13:"confirmations";a:1:{s:13:"52d9009b31447";a:8:{s:2:"id";s:13:"52d9009b31447";s:4:"name";s:20:"Default Confirmation";s:9:"isDefault";b:1;s:4:"type";s:7:"message";s:7:"message";s:64:"Thanks for contacting us! We will get in touch with you shortly.";s:3:"url";s:0:"";s:6:"pageId";s:0:"";s:11:"queryString";s:0:"";}}s:22:"useCurrentUserAsAuthor";b:1;s:26:"postContentTemplateEnabled";b:0;s:24:"postTitleTemplateEnabled";b:0;s:17:"postTitleTemplate";s:0:"";s:19:"postContentTemplate";s:0:"";s:14:"lastPageButton";N;s:10:"pagination";N;s:17:"firstPageCssClass";N;s:8:"cssClass";s:0:"";s:14:"enableHoneypot";s:0:"";s:15:"enableAnimation";s:0:"";s:12:"limitEntries";s:0:"";s:17:"limitEntriesCount";s:0:"";s:18:"limitEntriesPeriod";s:0:"";s:19:"limitEntriesMessage";s:0:"";s:12:"scheduleForm";s:0:"";s:13:"scheduleStart";s:0:"";s:17:"scheduleStartHour";s:0:"";s:19:"scheduleStartMinute";s:0:"";s:17:"scheduleStartAmpm";s:0:"";s:11:"scheduleEnd";s:0:"";s:15:"scheduleEndHour";s:0:"";s:17:"scheduleEndMinute";s:0:"";s:15:"scheduleEndAmpm";s:0:"";s:15:"scheduleMessage";s:0:"";s:12:"requireLogin";s:0:"";s:19:"requireLoginMessage";s:0:"";}', NULL, 'a:1:{s:13:"52d9009b31447";a:8:{s:2:"id";s:13:"52d9009b31447";s:4:"name";s:20:"Default Confirmation";s:9:"isDefault";b:1;s:4:"type";s:7:"message";s:7:"message";s:64:"Thanks for contacting us! We will get in touch with you shortly.";s:3:"url";s:0:"";s:6:"pageId";s:0:"";s:11:"queryString";s:0:"";}}', 'a:1:{s:13:"52d9009b30fab";a:7:{s:2:"id";s:13:"52d9009b30fab";s:2:"to";s:13:"{admin_email}";s:4:"name";s:18:"Admin Notification";s:5:"event";s:15:"form_submission";s:6:"toType";s:5:"email";s:7:"subject";s:32:"New submission from {form_title}";s:7:"message";s:12:"{all_fields}";}}') ;
#
# End of data contents of table wp_rg_form_meta
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_form_view (0 records)
#

#
# End of data contents of table wp_rg_form_view
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) NOT NULL,
  `source_url` varchar(200) NOT NULL DEFAULT '',
  `user_agent` varchar(250) NOT NULL DEFAULT '',
  `currency` varchar(5) DEFAULT NULL,
  `payment_status` varchar(15) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `transaction_id` varchar(50) DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `payment_method` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_lead (0 records)
#

#
# End of data contents of table wp_rg_lead
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_lead_detail (0 records)
#

#
# End of data contents of table wp_rg_lead_detail
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_lead_detail_long (0 records)
#

#
# End of data contents of table wp_rg_lead_detail_long
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`),
  KEY `lead_id` (`lead_id`),
  KEY `form_id_meta_key` (`form_id`,`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_lead_meta (0 records)
#

#
# End of data contents of table wp_rg_lead_meta
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext,
  `note_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_lead_notes (0 records)
#

#
# End of data contents of table wp_rg_lead_notes
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_term_relationships (131 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (20, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (21, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (22, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (24, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (24, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (24, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (24, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (24, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (26, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (26, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (26, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (26, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (26, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (28, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (28, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (28, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (28, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (28, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (30, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (30, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (30, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (30, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (30, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (32, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (32, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (32, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (32, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (32, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (34, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (34, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (34, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (34, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (34, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (36, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (36, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (36, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (36, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (36, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (38, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (38, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (38, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (38, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (38, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (40, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (40, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (40, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (40, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (40, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (42, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (42, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (42, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (42, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (42, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (44, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (44, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (44, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (44, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (44, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (46, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (46, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (46, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (46, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (46, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (87, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (88, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (100, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (101, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (102, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (103, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (104, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (105, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (106, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (114, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (135, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (135, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (135, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (135, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (135, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (135, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (135, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (139, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (139, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (139, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (139, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (140, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (140, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (140, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (140, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (142, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (142, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (142, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (142, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (150, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (150, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (150, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (150, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (165, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (165, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (165, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (165, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (165, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (167, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (167, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (167, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (167, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (167, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (197, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (197, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (197, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (197, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (197, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (198, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (198, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (198, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (198, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (198, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (199, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (199, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (199, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (199, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (199, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (200, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (200, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (200, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (200, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (200, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (203, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (203, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (203, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (203, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (203, 11, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_term_taxonomy (12 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'nav_menu', '', 0, 6) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'nav_menu', '', 0, 7) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'category', '', 0, 15) ; 
INSERT INTO `wp_term_taxonomy` VALUES (5, 5, 'category', '', 0, 15) ; 
INSERT INTO `wp_term_taxonomy` VALUES (6, 6, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (7, 7, 'category', '', 0, 15) ; 
INSERT INTO `wp_term_taxonomy` VALUES (8, 8, 'category', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (9, 9, 'category', '', 0, 15) ; 
INSERT INTO `wp_term_taxonomy` VALUES (10, 10, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (11, 11, 'category', '', 0, 15) ; 
INSERT INTO `wp_term_taxonomy` VALUES (12, 12, 'category', '', 0, 0) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_terms (12 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Primary Navigation', 'primary-navigation', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'Secondary Navigation', 'secondary-navigation', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'Story Development', 'story-development', 0) ; 
INSERT INTO `wp_terms` VALUES (5, 'Script Writing', 'script-writing', 0) ; 
INSERT INTO `wp_terms` VALUES (6, 'Storyboarding', 'storyboarding', 0) ; 
INSERT INTO `wp_terms` VALUES (7, 'Lighting and Sound', 'lighting-and-sound', 0) ; 
INSERT INTO `wp_terms` VALUES (8, 'Set Design', 'set-design', 0) ; 
INSERT INTO `wp_terms` VALUES (9, 'Filming', 'filming', 0) ; 
INSERT INTO `wp_terms` VALUES (10, 'Acting', 'acting', 0) ; 
INSERT INTO `wp_terms` VALUES (11, 'Directing', 'directing', 0) ; 
INSERT INTO `wp_terms` VALUES (12, 'Editing', 'editing', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_usermeta (25 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', 'Joshua') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', 'Coleman') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'joshua') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '0') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '201') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'nav_menu_recently_edited', '2') ; 
INSERT INTO `wp_usermeta` VALUES (21, 1, 'wp_user-settings', 'editor=tinymce&hidetb=1&wplink=1&libraryContent=browse&posts_list_mode=list') ; 
INSERT INTO `wp_usermeta` VALUES (22, 1, 'wp_user-settings-time', '1441939415') ; 
INSERT INTO `wp_usermeta` VALUES (23, 1, 'wpcf7_hide_welcome_panel_on', 'a:1:{i:0;s:5:"4.2.2";}') ; 
INSERT INTO `wp_usermeta` VALUES (24, 1, 'ame_show_hints', 'a:3:{s:17:"ws_sidebar_pro_ad";b:0;s:16:"ws_whats_new_120";b:0;s:24:"ws_hint_menu_permissions";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (25, 1, 'wp_media_library_mode', 'grid') ; 
INSERT INTO `wp_usermeta` VALUES (27, 1, 'closedpostboxes_post', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (28, 1, 'metaboxhidden_post', 'a:21:{i:0;s:11:"categorydiv";i:1;s:16:"tagsdiv-post_tag";i:2;s:23:"acf-group_55f340afaad2b";i:3;s:23:"acf-group_55f33b1f5666a";i:4;s:23:"acf-group_55f3347815ab2";i:5;s:23:"acf-group_55f248b8c4e3e";i:6;s:23:"acf-group_55f1facd0b2e2";i:7;s:23:"acf-group_55f1f29822023";i:8;s:23:"acf-group_55f1f282cab79";i:9;s:23:"acf-group_55f1f26ccd2fc";i:10;s:23:"acf-group_55f1f25618cc5";i:11;s:23:"acf-group_53bc19ac3f464";i:12;s:23:"acf-group_53bc19ac54554";i:13;s:23:"acf-group_53bc19ac5d293";i:14;s:12:"revisionsdiv";i:15;s:13:"trackbacksdiv";i:16;s:10:"postcustom";i:17;s:16:"commentstatusdiv";i:18;s:11:"commentsdiv";i:19;s:7:"slugdiv";i:20;s:9:"authordiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (29, 1, 'session_tokens', 'a:1:{s:64:"4e407568df28f5914af4d9fed1c4f93622723847c21911e8aa429795cf0355d9";a:4:{s:10:"expiration";i:1442520633;s:2:"ip";s:3:"::1";s:2:"ua";s:114:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11) AppleWebKit/601.1.56 (KHTML, like Gecko) Version/9.0 Safari/601.1.56";s:5:"login";i:1442347833;}}') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://9zero7films.dev MySQL database backup
#
# Generated: Tuesday 15. September 2015 20:11 UTC
# Hostname: localhost
# Database: `9zero7films`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'joshua', '$P$B5iKSu74I9Z1bNzu2GHqQDISrOXiWU0', 'joshua', 'jlcolema@me.com', '', '2014-01-17 06:39:23', '', 0, 'Joshua Coleman') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

